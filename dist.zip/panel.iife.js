(function() {
  "use strict";
  /**
  * @vue/shared v3.5.38
  * (c) 2018-present Yuxi (Evan) You and Vue contributors
  * @license MIT
  **/
  // @__NO_SIDE_EFFECTS__
  function makeMap(str) {
    const map = /* @__PURE__ */ Object.create(null);
    for (const key of str.split(",")) map[key] = 1;
    return (val) => val in map;
  }
  const EMPTY_OBJ = {};
  const EMPTY_ARR = [];
  const NOOP = () => {
  };
  const NO = () => false;
  const isOn = (key) => key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && // uppercase letter
  (key.charCodeAt(2) > 122 || key.charCodeAt(2) < 97);
  const isModelListener = (key) => key.startsWith("onUpdate:");
  const extend = Object.assign;
  const remove = (arr, el) => {
    const i = arr.indexOf(el);
    if (i > -1) {
      arr.splice(i, 1);
    }
  };
  const hasOwnProperty$1 = Object.prototype.hasOwnProperty;
  const hasOwn = (val, key) => hasOwnProperty$1.call(val, key);
  const isArray = Array.isArray;
  const isMap = (val) => toTypeString(val) === "[object Map]";
  const isSet = (val) => toTypeString(val) === "[object Set]";
  const isDate = (val) => toTypeString(val) === "[object Date]";
  const isFunction = (val) => typeof val === "function";
  const isString = (val) => typeof val === "string";
  const isSymbol = (val) => typeof val === "symbol";
  const isObject = (val) => val !== null && typeof val === "object";
  const isPromise = (val) => {
    return (isObject(val) || isFunction(val)) && isFunction(val.then) && isFunction(val.catch);
  };
  const objectToString = Object.prototype.toString;
  const toTypeString = (value) => objectToString.call(value);
  const toRawType = (value) => {
    return toTypeString(value).slice(8, -1);
  };
  const isPlainObject = (val) => toTypeString(val) === "[object Object]";
  const isIntegerKey = (key) => isString(key) && key !== "NaN" && key[0] !== "-" && "" + parseInt(key, 10) === key;
  const isReservedProp = /* @__PURE__ */ makeMap(
    // the leading comma is intentional so empty string "" is also included
    ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
  );
  const cacheStringFunction = (fn) => {
    const cache = /* @__PURE__ */ Object.create(null);
    return (str) => {
      const hit = cache[str];
      return hit || (cache[str] = fn(str));
    };
  };
  const camelizeRE = /-\w/g;
  const camelize = cacheStringFunction(
    (str) => {
      return str.replace(camelizeRE, (c) => c.slice(1).toUpperCase());
    }
  );
  const hyphenateRE = /\B([A-Z])/g;
  const hyphenate = cacheStringFunction(
    (str) => str.replace(hyphenateRE, "-$1").toLowerCase()
  );
  const capitalize = cacheStringFunction((str) => {
    return str.charAt(0).toUpperCase() + str.slice(1);
  });
  const toHandlerKey = cacheStringFunction(
    (str) => {
      const s = str ? `on${capitalize(str)}` : ``;
      return s;
    }
  );
  const hasChanged = (value, oldValue) => !Object.is(value, oldValue);
  const invokeArrayFns = (fns, ...arg) => {
    for (let i = 0; i < fns.length; i++) {
      fns[i](...arg);
    }
  };
  const def = (obj, key, value, writable = false) => {
    Object.defineProperty(obj, key, {
      configurable: true,
      enumerable: false,
      writable,
      value
    });
  };
  const looseToNumber = (val) => {
    const n = parseFloat(val);
    return isNaN(n) ? val : n;
  };
  let _globalThis;
  const getGlobalThis = () => {
    return _globalThis || (_globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {});
  };
  function normalizeStyle(value) {
    if (isArray(value)) {
      const res = {};
      for (let i = 0; i < value.length; i++) {
        const item = value[i];
        const normalized = isString(item) ? parseStringStyle(item) : normalizeStyle(item);
        if (normalized) {
          for (const key in normalized) {
            res[key] = normalized[key];
          }
        }
      }
      return res;
    } else if (isString(value) || isObject(value)) {
      return value;
    }
  }
  const listDelimiterRE = /;(?![^(]*\))/g;
  const propertyDelimiterRE = /:([^]+)/;
  const styleCommentRE = /\/\*[^]*?\*\//g;
  function parseStringStyle(cssText) {
    const ret = {};
    cssText.replace(styleCommentRE, "").split(listDelimiterRE).forEach((item) => {
      if (item) {
        const tmp = item.split(propertyDelimiterRE);
        tmp.length > 1 && (ret[tmp[0].trim()] = tmp[1].trim());
      }
    });
    return ret;
  }
  function normalizeClass(value) {
    let res = "";
    if (isString(value)) {
      res = value;
    } else if (isArray(value)) {
      for (let i = 0; i < value.length; i++) {
        const normalized = normalizeClass(value[i]);
        if (normalized) {
          res += normalized + " ";
        }
      }
    } else if (isObject(value)) {
      for (const name in value) {
        if (value[name]) {
          res += name + " ";
        }
      }
    }
    return res.trim();
  }
  const specialBooleanAttrs = `itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly`;
  const isSpecialBooleanAttr = /* @__PURE__ */ makeMap(specialBooleanAttrs);
  function includeBooleanAttr(value) {
    return !!value || value === "";
  }
  function looseCompareArrays(a, b) {
    if (a.length !== b.length) return false;
    let equal = true;
    for (let i = 0; equal && i < a.length; i++) {
      equal = looseEqual(a[i], b[i]);
    }
    return equal;
  }
  function looseEqual(a, b) {
    if (a === b) return true;
    let aValidType = isDate(a);
    let bValidType = isDate(b);
    if (aValidType || bValidType) {
      return aValidType && bValidType ? a.getTime() === b.getTime() : false;
    }
    aValidType = isSymbol(a);
    bValidType = isSymbol(b);
    if (aValidType || bValidType) {
      return a === b;
    }
    aValidType = isArray(a);
    bValidType = isArray(b);
    if (aValidType || bValidType) {
      return aValidType && bValidType ? looseCompareArrays(a, b) : false;
    }
    aValidType = isObject(a);
    bValidType = isObject(b);
    if (aValidType || bValidType) {
      if (!aValidType || !bValidType) {
        return false;
      }
      const aKeysCount = Object.keys(a).length;
      const bKeysCount = Object.keys(b).length;
      if (aKeysCount !== bKeysCount) {
        return false;
      }
      for (const key in a) {
        const aHasKey = a.hasOwnProperty(key);
        const bHasKey = b.hasOwnProperty(key);
        if (aHasKey && !bHasKey || !aHasKey && bHasKey || !looseEqual(a[key], b[key])) {
          return false;
        }
      }
    }
    return String(a) === String(b);
  }
  function looseIndexOf(arr, val) {
    return arr.findIndex((item) => looseEqual(item, val));
  }
  const isRef$1 = (val) => {
    return !!(val && val["__v_isRef"] === true);
  };
  const toDisplayString = (val) => {
    return isString(val) ? val : val == null ? "" : isArray(val) || isObject(val) && (val.toString === objectToString || !isFunction(val.toString)) ? isRef$1(val) ? toDisplayString(val.value) : JSON.stringify(val, replacer, 2) : String(val);
  };
  const replacer = (_key, val) => {
    if (isRef$1(val)) {
      return replacer(_key, val.value);
    } else if (isMap(val)) {
      return {
        [`Map(${val.size})`]: [...val.entries()].reduce(
          (entries, [key, val2], i) => {
            entries[stringifySymbol(key, i) + " =>"] = val2;
            return entries;
          },
          {}
        )
      };
    } else if (isSet(val)) {
      return {
        [`Set(${val.size})`]: [...val.values()].map((v) => stringifySymbol(v))
      };
    } else if (isSymbol(val)) {
      return stringifySymbol(val);
    } else if (isObject(val) && !isArray(val) && !isPlainObject(val)) {
      return String(val);
    }
    return val;
  };
  const stringifySymbol = (v, i = "") => {
    var _a;
    return (
      // Symbol.description in es2019+ so we need to cast here to pass
      // the lib: es2016 check
      isSymbol(v) ? `Symbol(${(_a = v.description) != null ? _a : i})` : v
    );
  };
  /**
  * @vue/reactivity v3.5.38
  * (c) 2018-present Yuxi (Evan) You and Vue contributors
  * @license MIT
  **/
  let activeEffectScope;
  class EffectScope {
    // TODO isolatedDeclarations "__v_skip"
    constructor(detached = false) {
      this.detached = detached;
      this._active = true;
      this._on = 0;
      this.effects = [];
      this.cleanups = [];
      this._isPaused = false;
      this._warnOnRun = true;
      this.__v_skip = true;
      if (!detached && activeEffectScope) {
        if (activeEffectScope.active) {
          this.parent = activeEffectScope;
          this.index = (activeEffectScope.scopes || (activeEffectScope.scopes = [])).push(
            this
          ) - 1;
        } else {
          this._active = false;
          this._warnOnRun = false;
        }
      }
    }
    get active() {
      return this._active;
    }
    pause() {
      if (this._active) {
        this._isPaused = true;
        let i, l;
        if (this.scopes) {
          for (i = 0, l = this.scopes.length; i < l; i++) {
            this.scopes[i].pause();
          }
        }
        for (i = 0, l = this.effects.length; i < l; i++) {
          this.effects[i].pause();
        }
      }
    }
    /**
     * Resumes the effect scope, including all child scopes and effects.
     */
    resume() {
      if (this._active) {
        if (this._isPaused) {
          this._isPaused = false;
          let i, l;
          if (this.scopes) {
            for (i = 0, l = this.scopes.length; i < l; i++) {
              this.scopes[i].resume();
            }
          }
          for (i = 0, l = this.effects.length; i < l; i++) {
            this.effects[i].resume();
          }
        }
      }
    }
    run(fn) {
      if (this._active) {
        const currentEffectScope = activeEffectScope;
        try {
          activeEffectScope = this;
          return fn();
        } finally {
          activeEffectScope = currentEffectScope;
        }
      }
    }
    /**
     * This should only be called on non-detached scopes
     * @internal
     */
    on() {
      if (++this._on === 1) {
        this.prevScope = activeEffectScope;
        activeEffectScope = this;
      }
    }
    /**
     * This should only be called on non-detached scopes
     * @internal
     */
    off() {
      if (this._on > 0 && --this._on === 0) {
        if (activeEffectScope === this) {
          activeEffectScope = this.prevScope;
        } else {
          let current = activeEffectScope;
          while (current) {
            if (current.prevScope === this) {
              current.prevScope = this.prevScope;
              break;
            }
            current = current.prevScope;
          }
        }
        this.prevScope = void 0;
      }
    }
    stop(fromParent) {
      if (this._active) {
        this._active = false;
        let i, l;
        for (i = 0, l = this.effects.length; i < l; i++) {
          this.effects[i].stop();
        }
        this.effects.length = 0;
        for (i = 0, l = this.cleanups.length; i < l; i++) {
          this.cleanups[i]();
        }
        this.cleanups.length = 0;
        if (this.scopes) {
          for (i = 0, l = this.scopes.length; i < l; i++) {
            this.scopes[i].stop(true);
          }
          this.scopes.length = 0;
        }
        if (!this.detached && this.parent && !fromParent) {
          const last = this.parent.scopes.pop();
          if (last && last !== this) {
            this.parent.scopes[this.index] = last;
            last.index = this.index;
          }
        }
        this.parent = void 0;
      }
    }
  }
  function getCurrentScope() {
    return activeEffectScope;
  }
  let activeSub;
  const pausedQueueEffects = /* @__PURE__ */ new WeakSet();
  class ReactiveEffect {
    constructor(fn) {
      this.fn = fn;
      this.deps = void 0;
      this.depsTail = void 0;
      this.flags = 1 | 4;
      this.next = void 0;
      this.cleanup = void 0;
      this.scheduler = void 0;
      if (activeEffectScope) {
        if (activeEffectScope.active) {
          activeEffectScope.effects.push(this);
        } else {
          this.flags &= -2;
        }
      }
    }
    pause() {
      this.flags |= 64;
    }
    resume() {
      if (this.flags & 64) {
        this.flags &= -65;
        if (pausedQueueEffects.has(this)) {
          pausedQueueEffects.delete(this);
          this.trigger();
        }
      }
    }
    /**
     * @internal
     */
    notify() {
      if (this.flags & 2 && !(this.flags & 32)) {
        return;
      }
      if (!(this.flags & 8)) {
        batch(this);
      }
    }
    run() {
      if (!(this.flags & 1)) {
        return this.fn();
      }
      this.flags |= 2;
      cleanupEffect(this);
      prepareDeps(this);
      const prevEffect = activeSub;
      const prevShouldTrack = shouldTrack;
      activeSub = this;
      shouldTrack = true;
      try {
        return this.fn();
      } finally {
        cleanupDeps(this);
        activeSub = prevEffect;
        shouldTrack = prevShouldTrack;
        this.flags &= -3;
      }
    }
    stop() {
      if (this.flags & 1) {
        for (let link = this.deps; link; link = link.nextDep) {
          removeSub(link);
        }
        this.deps = this.depsTail = void 0;
        cleanupEffect(this);
        this.onStop && this.onStop();
        this.flags &= -2;
      }
    }
    trigger() {
      if (this.flags & 64) {
        pausedQueueEffects.add(this);
      } else if (this.scheduler) {
        this.scheduler();
      } else {
        this.runIfDirty();
      }
    }
    /**
     * @internal
     */
    runIfDirty() {
      if (isDirty(this)) {
        this.run();
      }
    }
    get dirty() {
      return isDirty(this);
    }
  }
  let batchDepth = 0;
  let batchedSub;
  let batchedComputed;
  function batch(sub, isComputed = false) {
    sub.flags |= 8;
    if (isComputed) {
      sub.next = batchedComputed;
      batchedComputed = sub;
      return;
    }
    sub.next = batchedSub;
    batchedSub = sub;
  }
  function startBatch() {
    batchDepth++;
  }
  function endBatch() {
    if (--batchDepth > 0) {
      return;
    }
    if (batchedComputed) {
      let e = batchedComputed;
      batchedComputed = void 0;
      while (e) {
        const next = e.next;
        e.next = void 0;
        e.flags &= -9;
        e = next;
      }
    }
    let error;
    while (batchedSub) {
      let e = batchedSub;
      batchedSub = void 0;
      while (e) {
        const next = e.next;
        e.next = void 0;
        e.flags &= -9;
        if (e.flags & 1) {
          try {
            ;
            e.trigger();
          } catch (err) {
            if (!error) error = err;
          }
        }
        e = next;
      }
    }
    if (error) throw error;
  }
  function prepareDeps(sub) {
    for (let link = sub.deps; link; link = link.nextDep) {
      link.version = -1;
      link.prevActiveLink = link.dep.activeLink;
      link.dep.activeLink = link;
    }
  }
  function cleanupDeps(sub) {
    let head;
    let tail = sub.depsTail;
    let link = tail;
    while (link) {
      const prev = link.prevDep;
      if (link.version === -1) {
        if (link === tail) tail = prev;
        removeSub(link);
        removeDep(link);
      } else {
        head = link;
      }
      link.dep.activeLink = link.prevActiveLink;
      link.prevActiveLink = void 0;
      link = prev;
    }
    sub.deps = head;
    sub.depsTail = tail;
  }
  function isDirty(sub) {
    for (let link = sub.deps; link; link = link.nextDep) {
      if (link.dep.version !== link.version || link.dep.computed && (refreshComputed(link.dep.computed) || link.dep.version !== link.version)) {
        return true;
      }
    }
    if (sub._dirty) {
      return true;
    }
    return false;
  }
  function refreshComputed(computed2) {
    if (computed2.flags & 4 && !(computed2.flags & 16)) {
      return;
    }
    computed2.flags &= -17;
    if (computed2.globalVersion === globalVersion) {
      return;
    }
    computed2.globalVersion = globalVersion;
    if (!computed2.isSSR && computed2.flags & 128 && (!computed2.deps && !computed2._dirty || !isDirty(computed2))) {
      return;
    }
    computed2.flags |= 2;
    const dep = computed2.dep;
    const prevSub = activeSub;
    const prevShouldTrack = shouldTrack;
    activeSub = computed2;
    shouldTrack = true;
    try {
      prepareDeps(computed2);
      const value = computed2.fn(computed2._value);
      if (dep.version === 0 || hasChanged(value, computed2._value)) {
        computed2.flags |= 128;
        computed2._value = value;
        dep.version++;
      }
    } catch (err) {
      dep.version++;
      throw err;
    } finally {
      activeSub = prevSub;
      shouldTrack = prevShouldTrack;
      cleanupDeps(computed2);
      computed2.flags &= -3;
    }
  }
  function removeSub(link, soft = false) {
    const { dep, prevSub, nextSub } = link;
    if (prevSub) {
      prevSub.nextSub = nextSub;
      link.prevSub = void 0;
    }
    if (nextSub) {
      nextSub.prevSub = prevSub;
      link.nextSub = void 0;
    }
    if (dep.subs === link) {
      dep.subs = prevSub;
      if (!prevSub && dep.computed) {
        dep.computed.flags &= -5;
        for (let l = dep.computed.deps; l; l = l.nextDep) {
          removeSub(l, true);
        }
      }
    }
    if (!soft && !--dep.sc && dep.map) {
      dep.map.delete(dep.key);
    }
  }
  function removeDep(link) {
    const { prevDep, nextDep } = link;
    if (prevDep) {
      prevDep.nextDep = nextDep;
      link.prevDep = void 0;
    }
    if (nextDep) {
      nextDep.prevDep = prevDep;
      link.nextDep = void 0;
    }
  }
  let shouldTrack = true;
  const trackStack = [];
  function pauseTracking() {
    trackStack.push(shouldTrack);
    shouldTrack = false;
  }
  function resetTracking() {
    const last = trackStack.pop();
    shouldTrack = last === void 0 ? true : last;
  }
  function cleanupEffect(e) {
    const { cleanup } = e;
    e.cleanup = void 0;
    if (cleanup) {
      const prevSub = activeSub;
      activeSub = void 0;
      try {
        cleanup();
      } finally {
        activeSub = prevSub;
      }
    }
  }
  let globalVersion = 0;
  class Link {
    constructor(sub, dep) {
      this.sub = sub;
      this.dep = dep;
      this.version = dep.version;
      this.nextDep = this.prevDep = this.nextSub = this.prevSub = this.prevActiveLink = void 0;
    }
  }
  class Dep {
    // TODO isolatedDeclarations "__v_skip"
    constructor(computed2) {
      this.computed = computed2;
      this.version = 0;
      this.activeLink = void 0;
      this.subs = void 0;
      this.map = void 0;
      this.key = void 0;
      this.sc = 0;
      this.__v_skip = true;
    }
    track(debugInfo) {
      if (!activeSub || !shouldTrack || activeSub === this.computed) {
        return;
      }
      let link = this.activeLink;
      if (link === void 0 || link.sub !== activeSub) {
        link = this.activeLink = new Link(activeSub, this);
        if (!activeSub.deps) {
          activeSub.deps = activeSub.depsTail = link;
        } else {
          link.prevDep = activeSub.depsTail;
          activeSub.depsTail.nextDep = link;
          activeSub.depsTail = link;
        }
        addSub(link);
      } else if (link.version === -1) {
        link.version = this.version;
        if (link.nextDep) {
          const next = link.nextDep;
          next.prevDep = link.prevDep;
          if (link.prevDep) {
            link.prevDep.nextDep = next;
          }
          link.prevDep = activeSub.depsTail;
          link.nextDep = void 0;
          activeSub.depsTail.nextDep = link;
          activeSub.depsTail = link;
          if (activeSub.deps === link) {
            activeSub.deps = next;
          }
        }
      }
      return link;
    }
    trigger(debugInfo) {
      this.version++;
      globalVersion++;
      this.notify(debugInfo);
    }
    notify(debugInfo) {
      startBatch();
      try {
        if (false) ;
        for (let link = this.subs; link; link = link.prevSub) {
          if (link.sub.notify()) {
            ;
            link.sub.dep.notify();
          }
        }
      } finally {
        endBatch();
      }
    }
  }
  function addSub(link) {
    link.dep.sc++;
    if (link.sub.flags & 4) {
      const computed2 = link.dep.computed;
      if (computed2 && !link.dep.subs) {
        computed2.flags |= 4 | 16;
        for (let l = computed2.deps; l; l = l.nextDep) {
          addSub(l);
        }
      }
      const currentTail = link.dep.subs;
      if (currentTail !== link) {
        link.prevSub = currentTail;
        if (currentTail) currentTail.nextSub = link;
      }
      link.dep.subs = link;
    }
  }
  const targetMap = /* @__PURE__ */ new WeakMap();
  const ITERATE_KEY = /* @__PURE__ */ Symbol(
    ""
  );
  const MAP_KEY_ITERATE_KEY = /* @__PURE__ */ Symbol(
    ""
  );
  const ARRAY_ITERATE_KEY = /* @__PURE__ */ Symbol(
    ""
  );
  function track(target, type, key) {
    if (shouldTrack && activeSub) {
      let depsMap = targetMap.get(target);
      if (!depsMap) {
        targetMap.set(target, depsMap = /* @__PURE__ */ new Map());
      }
      let dep = depsMap.get(key);
      if (!dep) {
        depsMap.set(key, dep = new Dep());
        dep.map = depsMap;
        dep.key = key;
      }
      {
        dep.track();
      }
    }
  }
  function trigger(target, type, key, newValue, oldValue, oldTarget) {
    const depsMap = targetMap.get(target);
    if (!depsMap) {
      globalVersion++;
      return;
    }
    const run = (dep) => {
      if (dep) {
        {
          dep.trigger();
        }
      }
    };
    startBatch();
    if (type === "clear") {
      depsMap.forEach(run);
    } else {
      const targetIsArray = isArray(target);
      const isArrayIndex = targetIsArray && isIntegerKey(key);
      if (targetIsArray && key === "length") {
        const newLength = Number(newValue);
        depsMap.forEach((dep, key2) => {
          if (key2 === "length" || key2 === ARRAY_ITERATE_KEY || !isSymbol(key2) && key2 >= newLength) {
            run(dep);
          }
        });
      } else {
        if (key !== void 0 || depsMap.has(void 0)) {
          run(depsMap.get(key));
        }
        if (isArrayIndex) {
          run(depsMap.get(ARRAY_ITERATE_KEY));
        }
        switch (type) {
          case "add":
            if (!targetIsArray) {
              run(depsMap.get(ITERATE_KEY));
              if (isMap(target)) {
                run(depsMap.get(MAP_KEY_ITERATE_KEY));
              }
            } else if (isArrayIndex) {
              run(depsMap.get("length"));
            }
            break;
          case "delete":
            if (!targetIsArray) {
              run(depsMap.get(ITERATE_KEY));
              if (isMap(target)) {
                run(depsMap.get(MAP_KEY_ITERATE_KEY));
              }
            }
            break;
          case "set":
            if (isMap(target)) {
              run(depsMap.get(ITERATE_KEY));
            }
            break;
        }
      }
    }
    endBatch();
  }
  function reactiveReadArray(array) {
    const raw = /* @__PURE__ */ toRaw(array);
    if (raw === array) return raw;
    track(raw, "iterate", ARRAY_ITERATE_KEY);
    return /* @__PURE__ */ isShallow(array) ? raw : raw.map(toReactive);
  }
  function shallowReadArray(arr) {
    track(arr = /* @__PURE__ */ toRaw(arr), "iterate", ARRAY_ITERATE_KEY);
    return arr;
  }
  function toWrapped(target, item) {
    if (/* @__PURE__ */ isReadonly(target)) {
      return /* @__PURE__ */ isReactive(target) ? toReadonly(toReactive(item)) : toReadonly(item);
    }
    return toReactive(item);
  }
  const arrayInstrumentations = {
    __proto__: null,
    [Symbol.iterator]() {
      return iterator(this, Symbol.iterator, (item) => toWrapped(this, item));
    },
    concat(...args) {
      return reactiveReadArray(this).concat(
        ...args.map((x) => isArray(x) ? reactiveReadArray(x) : x)
      );
    },
    entries() {
      return iterator(this, "entries", (value) => {
        value[1] = toWrapped(this, value[1]);
        return value;
      });
    },
    every(fn, thisArg) {
      return apply(this, "every", fn, thisArg, void 0, arguments);
    },
    filter(fn, thisArg) {
      return apply(
        this,
        "filter",
        fn,
        thisArg,
        (v) => v.map((item) => toWrapped(this, item)),
        arguments
      );
    },
    find(fn, thisArg) {
      return apply(
        this,
        "find",
        fn,
        thisArg,
        (item) => toWrapped(this, item),
        arguments
      );
    },
    findIndex(fn, thisArg) {
      return apply(this, "findIndex", fn, thisArg, void 0, arguments);
    },
    findLast(fn, thisArg) {
      return apply(
        this,
        "findLast",
        fn,
        thisArg,
        (item) => toWrapped(this, item),
        arguments
      );
    },
    findLastIndex(fn, thisArg) {
      return apply(this, "findLastIndex", fn, thisArg, void 0, arguments);
    },
    // flat, flatMap could benefit from ARRAY_ITERATE but are not straight-forward to implement
    forEach(fn, thisArg) {
      return apply(this, "forEach", fn, thisArg, void 0, arguments);
    },
    includes(...args) {
      return searchProxy(this, "includes", args);
    },
    indexOf(...args) {
      return searchProxy(this, "indexOf", args);
    },
    join(separator) {
      return reactiveReadArray(this).join(separator);
    },
    // keys() iterator only reads `length`, no optimization required
    lastIndexOf(...args) {
      return searchProxy(this, "lastIndexOf", args);
    },
    map(fn, thisArg) {
      return apply(this, "map", fn, thisArg, void 0, arguments);
    },
    pop() {
      return noTracking(this, "pop");
    },
    push(...args) {
      return noTracking(this, "push", args);
    },
    reduce(fn, ...args) {
      return reduce(this, "reduce", fn, args);
    },
    reduceRight(fn, ...args) {
      return reduce(this, "reduceRight", fn, args);
    },
    shift() {
      return noTracking(this, "shift");
    },
    // slice could use ARRAY_ITERATE but also seems to beg for range tracking
    some(fn, thisArg) {
      return apply(this, "some", fn, thisArg, void 0, arguments);
    },
    splice(...args) {
      return noTracking(this, "splice", args);
    },
    toReversed() {
      return reactiveReadArray(this).toReversed();
    },
    toSorted(comparer) {
      return reactiveReadArray(this).toSorted(comparer);
    },
    toSpliced(...args) {
      return reactiveReadArray(this).toSpliced(...args);
    },
    unshift(...args) {
      return noTracking(this, "unshift", args);
    },
    values() {
      return iterator(this, "values", (item) => toWrapped(this, item));
    }
  };
  function iterator(self2, method, wrapValue) {
    const arr = shallowReadArray(self2);
    const iter = arr[method]();
    if (arr !== self2 && !/* @__PURE__ */ isShallow(self2)) {
      iter._next = iter.next;
      iter.next = () => {
        const result = iter._next();
        if (!result.done) {
          result.value = wrapValue(result.value);
        }
        return result;
      };
    }
    return iter;
  }
  const arrayProto = Array.prototype;
  function apply(self2, method, fn, thisArg, wrappedRetFn, args) {
    const arr = shallowReadArray(self2);
    const needsWrap = arr !== self2 && !/* @__PURE__ */ isShallow(self2);
    const methodFn = arr[method];
    if (methodFn !== arrayProto[method]) {
      const result2 = methodFn.apply(self2, args);
      return needsWrap ? toReactive(result2) : result2;
    }
    let wrappedFn = fn;
    if (arr !== self2) {
      if (needsWrap) {
        wrappedFn = function(item, index) {
          return fn.call(this, toWrapped(self2, item), index, self2);
        };
      } else if (fn.length > 2) {
        wrappedFn = function(item, index) {
          return fn.call(this, item, index, self2);
        };
      }
    }
    const result = methodFn.call(arr, wrappedFn, thisArg);
    return needsWrap && wrappedRetFn ? wrappedRetFn(result) : result;
  }
  function reduce(self2, method, fn, args) {
    const arr = shallowReadArray(self2);
    const needsWrap = arr !== self2 && !/* @__PURE__ */ isShallow(self2);
    let wrappedFn = fn;
    let wrapInitialAccumulator = false;
    if (arr !== self2) {
      if (needsWrap) {
        wrapInitialAccumulator = args.length === 0;
        wrappedFn = function(acc, item, index) {
          if (wrapInitialAccumulator) {
            wrapInitialAccumulator = false;
            acc = toWrapped(self2, acc);
          }
          return fn.call(this, acc, toWrapped(self2, item), index, self2);
        };
      } else if (fn.length > 3) {
        wrappedFn = function(acc, item, index) {
          return fn.call(this, acc, item, index, self2);
        };
      }
    }
    const result = arr[method](wrappedFn, ...args);
    return wrapInitialAccumulator ? toWrapped(self2, result) : result;
  }
  function searchProxy(self2, method, args) {
    const arr = /* @__PURE__ */ toRaw(self2);
    track(arr, "iterate", ARRAY_ITERATE_KEY);
    const res = arr[method](...args);
    if ((res === -1 || res === false) && /* @__PURE__ */ isProxy(args[0])) {
      args[0] = /* @__PURE__ */ toRaw(args[0]);
      return arr[method](...args);
    }
    return res;
  }
  function noTracking(self2, method, args = []) {
    pauseTracking();
    startBatch();
    const res = (/* @__PURE__ */ toRaw(self2))[method].apply(self2, args);
    endBatch();
    resetTracking();
    return res;
  }
  const isNonTrackableKeys = /* @__PURE__ */ makeMap(`__proto__,__v_isRef,__isVue`);
  const builtInSymbols = new Set(
    /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((key) => key !== "arguments" && key !== "caller").map((key) => Symbol[key]).filter(isSymbol)
  );
  function hasOwnProperty(key) {
    if (!isSymbol(key)) key = String(key);
    const obj = /* @__PURE__ */ toRaw(this);
    track(obj, "has", key);
    return obj.hasOwnProperty(key);
  }
  class BaseReactiveHandler {
    constructor(_isReadonly = false, _isShallow = false) {
      this._isReadonly = _isReadonly;
      this._isShallow = _isShallow;
    }
    get(target, key, receiver) {
      if (key === "__v_skip") return target["__v_skip"];
      const isReadonly2 = this._isReadonly, isShallow2 = this._isShallow;
      if (key === "__v_isReactive") {
        return !isReadonly2;
      } else if (key === "__v_isReadonly") {
        return isReadonly2;
      } else if (key === "__v_isShallow") {
        return isShallow2;
      } else if (key === "__v_raw") {
        if (receiver === (isReadonly2 ? isShallow2 ? shallowReadonlyMap : readonlyMap : isShallow2 ? shallowReactiveMap : reactiveMap).get(target) || // receiver is not the reactive proxy, but has the same prototype
        // this means the receiver is a user proxy of the reactive proxy
        Object.getPrototypeOf(target) === Object.getPrototypeOf(receiver)) {
          return target;
        }
        return;
      }
      const targetIsArray = isArray(target);
      if (!isReadonly2) {
        let fn;
        if (targetIsArray && (fn = arrayInstrumentations[key])) {
          return fn;
        }
        if (key === "hasOwnProperty") {
          return hasOwnProperty;
        }
      }
      const res = Reflect.get(
        target,
        key,
        // if this is a proxy wrapping a ref, return methods using the raw ref
        // as receiver so that we don't have to call `toRaw` on the ref in all
        // its class methods
        /* @__PURE__ */ isRef(target) ? target : receiver
      );
      if (isSymbol(key) ? builtInSymbols.has(key) : isNonTrackableKeys(key)) {
        return res;
      }
      if (!isReadonly2) {
        track(target, "get", key);
      }
      if (isShallow2) {
        return res;
      }
      if (/* @__PURE__ */ isRef(res)) {
        const value = targetIsArray && isIntegerKey(key) ? res : res.value;
        return isReadonly2 && isObject(value) ? /* @__PURE__ */ readonly(value) : value;
      }
      if (isObject(res)) {
        return isReadonly2 ? /* @__PURE__ */ readonly(res) : /* @__PURE__ */ reactive(res);
      }
      return res;
    }
  }
  class MutableReactiveHandler extends BaseReactiveHandler {
    constructor(isShallow2 = false) {
      super(false, isShallow2);
    }
    set(target, key, value, receiver) {
      let oldValue = target[key];
      const isArrayWithIntegerKey = isArray(target) && isIntegerKey(key);
      if (!this._isShallow) {
        const isOldValueReadonly = /* @__PURE__ */ isReadonly(oldValue);
        if (!/* @__PURE__ */ isShallow(value) && !/* @__PURE__ */ isReadonly(value)) {
          oldValue = /* @__PURE__ */ toRaw(oldValue);
          value = /* @__PURE__ */ toRaw(value);
        }
        if (!isArrayWithIntegerKey && /* @__PURE__ */ isRef(oldValue) && !/* @__PURE__ */ isRef(value)) {
          if (isOldValueReadonly) {
            return true;
          } else {
            oldValue.value = value;
            return true;
          }
        }
      }
      const hadKey = isArrayWithIntegerKey ? Number(key) < target.length : hasOwn(target, key);
      const result = Reflect.set(
        target,
        key,
        value,
        /* @__PURE__ */ isRef(target) ? target : receiver
      );
      if (target === /* @__PURE__ */ toRaw(receiver)) {
        if (!hadKey) {
          trigger(target, "add", key, value);
        } else if (hasChanged(value, oldValue)) {
          trigger(target, "set", key, value);
        }
      }
      return result;
    }
    deleteProperty(target, key) {
      const hadKey = hasOwn(target, key);
      target[key];
      const result = Reflect.deleteProperty(target, key);
      if (result && hadKey) {
        trigger(target, "delete", key, void 0);
      }
      return result;
    }
    has(target, key) {
      const result = Reflect.has(target, key);
      if (!isSymbol(key) || !builtInSymbols.has(key)) {
        track(target, "has", key);
      }
      return result;
    }
    ownKeys(target) {
      track(
        target,
        "iterate",
        isArray(target) ? "length" : ITERATE_KEY
      );
      return Reflect.ownKeys(target);
    }
  }
  class ReadonlyReactiveHandler extends BaseReactiveHandler {
    constructor(isShallow2 = false) {
      super(true, isShallow2);
    }
    set(target, key) {
      return true;
    }
    deleteProperty(target, key) {
      return true;
    }
  }
  const mutableHandlers = /* @__PURE__ */ new MutableReactiveHandler();
  const readonlyHandlers = /* @__PURE__ */ new ReadonlyReactiveHandler();
  const shallowReactiveHandlers = /* @__PURE__ */ new MutableReactiveHandler(true);
  const shallowReadonlyHandlers = /* @__PURE__ */ new ReadonlyReactiveHandler(true);
  const toShallow = (value) => value;
  const getProto = (v) => Reflect.getPrototypeOf(v);
  function createIterableMethod(method, isReadonly2, isShallow2) {
    return function(...args) {
      const target = this["__v_raw"];
      const rawTarget = /* @__PURE__ */ toRaw(target);
      const targetIsMap = isMap(rawTarget);
      const isPair = method === "entries" || method === Symbol.iterator && targetIsMap;
      const isKeyOnly = method === "keys" && targetIsMap;
      const innerIterator = target[method](...args);
      const wrap = isShallow2 ? toShallow : isReadonly2 ? toReadonly : toReactive;
      !isReadonly2 && track(
        rawTarget,
        "iterate",
        isKeyOnly ? MAP_KEY_ITERATE_KEY : ITERATE_KEY
      );
      return extend(
        // inheriting all iterator properties
        Object.create(innerIterator),
        {
          // iterator protocol
          next() {
            const { value, done } = innerIterator.next();
            return done ? { value, done } : {
              value: isPair ? [wrap(value[0]), wrap(value[1])] : wrap(value),
              done
            };
          }
        }
      );
    };
  }
  function createReadonlyMethod(type) {
    return function(...args) {
      return type === "delete" ? false : type === "clear" ? void 0 : this;
    };
  }
  function createInstrumentations(readonly2, shallow) {
    const instrumentations = {
      get(key) {
        const target = this["__v_raw"];
        const rawTarget = /* @__PURE__ */ toRaw(target);
        const rawKey = /* @__PURE__ */ toRaw(key);
        if (!readonly2) {
          if (hasChanged(key, rawKey)) {
            track(rawTarget, "get", key);
          }
          track(rawTarget, "get", rawKey);
        }
        const { has } = getProto(rawTarget);
        const wrap = shallow ? toShallow : readonly2 ? toReadonly : toReactive;
        if (has.call(rawTarget, key)) {
          return wrap(target.get(key));
        } else if (has.call(rawTarget, rawKey)) {
          return wrap(target.get(rawKey));
        } else if (target !== rawTarget) {
          target.get(key);
        }
      },
      get size() {
        const target = this["__v_raw"];
        !readonly2 && track(/* @__PURE__ */ toRaw(target), "iterate", ITERATE_KEY);
        return target.size;
      },
      has(key) {
        const target = this["__v_raw"];
        const rawTarget = /* @__PURE__ */ toRaw(target);
        const rawKey = /* @__PURE__ */ toRaw(key);
        if (!readonly2) {
          if (hasChanged(key, rawKey)) {
            track(rawTarget, "has", key);
          }
          track(rawTarget, "has", rawKey);
        }
        return key === rawKey ? target.has(key) : target.has(key) || target.has(rawKey);
      },
      forEach(callback, thisArg) {
        const observed = this;
        const target = observed["__v_raw"];
        const rawTarget = /* @__PURE__ */ toRaw(target);
        const wrap = shallow ? toShallow : readonly2 ? toReadonly : toReactive;
        !readonly2 && track(rawTarget, "iterate", ITERATE_KEY);
        return target.forEach((value, key) => {
          return callback.call(thisArg, wrap(value), wrap(key), observed);
        });
      }
    };
    extend(
      instrumentations,
      readonly2 ? {
        add: createReadonlyMethod("add"),
        set: createReadonlyMethod("set"),
        delete: createReadonlyMethod("delete"),
        clear: createReadonlyMethod("clear")
      } : {
        add(value) {
          const target = /* @__PURE__ */ toRaw(this);
          const proto = getProto(target);
          const rawValue = /* @__PURE__ */ toRaw(value);
          const valueToAdd = !shallow && !/* @__PURE__ */ isShallow(value) && !/* @__PURE__ */ isReadonly(value) ? rawValue : value;
          const hadKey = proto.has.call(target, valueToAdd) || hasChanged(value, valueToAdd) && proto.has.call(target, value) || hasChanged(rawValue, valueToAdd) && proto.has.call(target, rawValue);
          if (!hadKey) {
            target.add(valueToAdd);
            trigger(target, "add", valueToAdd, valueToAdd);
          }
          return this;
        },
        set(key, value) {
          if (!shallow && !/* @__PURE__ */ isShallow(value) && !/* @__PURE__ */ isReadonly(value)) {
            value = /* @__PURE__ */ toRaw(value);
          }
          const target = /* @__PURE__ */ toRaw(this);
          const { has, get } = getProto(target);
          let hadKey = has.call(target, key);
          if (!hadKey) {
            key = /* @__PURE__ */ toRaw(key);
            hadKey = has.call(target, key);
          }
          const oldValue = get.call(target, key);
          target.set(key, value);
          if (!hadKey) {
            trigger(target, "add", key, value);
          } else if (hasChanged(value, oldValue)) {
            trigger(target, "set", key, value);
          }
          return this;
        },
        delete(key) {
          const target = /* @__PURE__ */ toRaw(this);
          const { has, get } = getProto(target);
          let hadKey = has.call(target, key);
          if (!hadKey) {
            key = /* @__PURE__ */ toRaw(key);
            hadKey = has.call(target, key);
          }
          get ? get.call(target, key) : void 0;
          const result = target.delete(key);
          if (hadKey) {
            trigger(target, "delete", key, void 0);
          }
          return result;
        },
        clear() {
          const target = /* @__PURE__ */ toRaw(this);
          const hadItems = target.size !== 0;
          const result = target.clear();
          if (hadItems) {
            trigger(
              target,
              "clear",
              void 0,
              void 0
            );
          }
          return result;
        }
      }
    );
    const iteratorMethods = [
      "keys",
      "values",
      "entries",
      Symbol.iterator
    ];
    iteratorMethods.forEach((method) => {
      instrumentations[method] = createIterableMethod(method, readonly2, shallow);
    });
    return instrumentations;
  }
  function createInstrumentationGetter(isReadonly2, shallow) {
    const instrumentations = createInstrumentations(isReadonly2, shallow);
    return (target, key, receiver) => {
      if (key === "__v_isReactive") {
        return !isReadonly2;
      } else if (key === "__v_isReadonly") {
        return isReadonly2;
      } else if (key === "__v_raw") {
        return target;
      }
      return Reflect.get(
        hasOwn(instrumentations, key) && key in target ? instrumentations : target,
        key,
        receiver
      );
    };
  }
  const mutableCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(false, false)
  };
  const shallowCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(false, true)
  };
  const readonlyCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(true, false)
  };
  const shallowReadonlyCollectionHandlers = {
    get: /* @__PURE__ */ createInstrumentationGetter(true, true)
  };
  const reactiveMap = /* @__PURE__ */ new WeakMap();
  const shallowReactiveMap = /* @__PURE__ */ new WeakMap();
  const readonlyMap = /* @__PURE__ */ new WeakMap();
  const shallowReadonlyMap = /* @__PURE__ */ new WeakMap();
  function targetTypeMap(rawType) {
    switch (rawType) {
      case "Object":
      case "Array":
        return 1;
      case "Map":
      case "Set":
      case "WeakMap":
      case "WeakSet":
        return 2;
      default:
        return 0;
    }
  }
  // @__NO_SIDE_EFFECTS__
  function reactive(target) {
    if (/* @__PURE__ */ isReadonly(target)) {
      return target;
    }
    return createReactiveObject(
      target,
      false,
      mutableHandlers,
      mutableCollectionHandlers,
      reactiveMap
    );
  }
  // @__NO_SIDE_EFFECTS__
  function shallowReactive(target) {
    return createReactiveObject(
      target,
      false,
      shallowReactiveHandlers,
      shallowCollectionHandlers,
      shallowReactiveMap
    );
  }
  // @__NO_SIDE_EFFECTS__
  function readonly(target) {
    return createReactiveObject(
      target,
      true,
      readonlyHandlers,
      readonlyCollectionHandlers,
      readonlyMap
    );
  }
  // @__NO_SIDE_EFFECTS__
  function shallowReadonly(target) {
    return createReactiveObject(
      target,
      true,
      shallowReadonlyHandlers,
      shallowReadonlyCollectionHandlers,
      shallowReadonlyMap
    );
  }
  function createReactiveObject(target, isReadonly2, baseHandlers, collectionHandlers, proxyMap) {
    if (!isObject(target)) {
      return target;
    }
    if (target["__v_raw"] && !(isReadonly2 && target["__v_isReactive"])) {
      return target;
    }
    if (target["__v_skip"] || !Object.isExtensible(target)) {
      return target;
    }
    const existingProxy = proxyMap.get(target);
    if (existingProxy) {
      return existingProxy;
    }
    const targetType = targetTypeMap(toRawType(target));
    if (targetType === 0) {
      return target;
    }
    const proxy = new Proxy(
      target,
      targetType === 2 ? collectionHandlers : baseHandlers
    );
    proxyMap.set(target, proxy);
    return proxy;
  }
  // @__NO_SIDE_EFFECTS__
  function isReactive(value) {
    if (/* @__PURE__ */ isReadonly(value)) {
      return /* @__PURE__ */ isReactive(value["__v_raw"]);
    }
    return !!(value && value["__v_isReactive"]);
  }
  // @__NO_SIDE_EFFECTS__
  function isReadonly(value) {
    return !!(value && value["__v_isReadonly"]);
  }
  // @__NO_SIDE_EFFECTS__
  function isShallow(value) {
    return !!(value && value["__v_isShallow"]);
  }
  // @__NO_SIDE_EFFECTS__
  function isProxy(value) {
    return value ? !!value["__v_raw"] : false;
  }
  // @__NO_SIDE_EFFECTS__
  function toRaw(observed) {
    const raw = observed && observed["__v_raw"];
    return raw ? /* @__PURE__ */ toRaw(raw) : observed;
  }
  function markRaw(value) {
    if (!hasOwn(value, "__v_skip") && Object.isExtensible(value)) {
      def(value, "__v_skip", true);
    }
    return value;
  }
  const toReactive = (value) => isObject(value) ? /* @__PURE__ */ reactive(value) : value;
  const toReadonly = (value) => isObject(value) ? /* @__PURE__ */ readonly(value) : value;
  // @__NO_SIDE_EFFECTS__
  function isRef(r) {
    return r ? r["__v_isRef"] === true : false;
  }
  // @__NO_SIDE_EFFECTS__
  function ref(value) {
    return createRef(value, false);
  }
  function createRef(rawValue, shallow) {
    if (/* @__PURE__ */ isRef(rawValue)) {
      return rawValue;
    }
    return new RefImpl(rawValue, shallow);
  }
  class RefImpl {
    constructor(value, isShallow2) {
      this.dep = new Dep();
      this["__v_isRef"] = true;
      this["__v_isShallow"] = false;
      this._rawValue = isShallow2 ? value : /* @__PURE__ */ toRaw(value);
      this._value = isShallow2 ? value : toReactive(value);
      this["__v_isShallow"] = isShallow2;
    }
    get value() {
      {
        this.dep.track();
      }
      return this._value;
    }
    set value(newValue) {
      const oldValue = this._rawValue;
      const useDirectValue = this["__v_isShallow"] || /* @__PURE__ */ isShallow(newValue) || /* @__PURE__ */ isReadonly(newValue);
      newValue = useDirectValue ? newValue : /* @__PURE__ */ toRaw(newValue);
      if (hasChanged(newValue, oldValue)) {
        this._rawValue = newValue;
        this._value = useDirectValue ? newValue : toReactive(newValue);
        {
          this.dep.trigger();
        }
      }
    }
  }
  function unref(ref2) {
    return /* @__PURE__ */ isRef(ref2) ? ref2.value : ref2;
  }
  const shallowUnwrapHandlers = {
    get: (target, key, receiver) => key === "__v_raw" ? target : unref(Reflect.get(target, key, receiver)),
    set: (target, key, value, receiver) => {
      const oldValue = target[key];
      if (/* @__PURE__ */ isRef(oldValue) && !/* @__PURE__ */ isRef(value)) {
        oldValue.value = value;
        return true;
      } else {
        return Reflect.set(target, key, value, receiver);
      }
    }
  };
  function proxyRefs(objectWithRefs) {
    return /* @__PURE__ */ isReactive(objectWithRefs) ? objectWithRefs : new Proxy(objectWithRefs, shallowUnwrapHandlers);
  }
  class ComputedRefImpl {
    constructor(fn, setter, isSSR) {
      this.fn = fn;
      this.setter = setter;
      this._value = void 0;
      this.dep = new Dep(this);
      this.__v_isRef = true;
      this.deps = void 0;
      this.depsTail = void 0;
      this.flags = 16;
      this.globalVersion = globalVersion - 1;
      this.next = void 0;
      this.effect = this;
      this["__v_isReadonly"] = !setter;
      this.isSSR = isSSR;
    }
    /**
     * @internal
     */
    notify() {
      this.flags |= 16;
      if (!(this.flags & 8) && // avoid infinite self recursion
      activeSub !== this) {
        batch(this, true);
        return true;
      }
    }
    get value() {
      const link = this.dep.track();
      refreshComputed(this);
      if (link) {
        link.version = this.dep.version;
      }
      return this._value;
    }
    set value(newValue) {
      if (this.setter) {
        this.setter(newValue);
      }
    }
  }
  // @__NO_SIDE_EFFECTS__
  function computed$1(getterOrOptions, debugOptions, isSSR = false) {
    let getter;
    let setter;
    if (isFunction(getterOrOptions)) {
      getter = getterOrOptions;
    } else {
      getter = getterOrOptions.get;
      setter = getterOrOptions.set;
    }
    const cRef = new ComputedRefImpl(getter, setter, isSSR);
    return cRef;
  }
  const INITIAL_WATCHER_VALUE = {};
  const cleanupMap = /* @__PURE__ */ new WeakMap();
  let activeWatcher = void 0;
  function onWatcherCleanup(cleanupFn, failSilently = false, owner = activeWatcher) {
    if (owner) {
      let cleanups = cleanupMap.get(owner);
      if (!cleanups) cleanupMap.set(owner, cleanups = []);
      cleanups.push(cleanupFn);
    }
  }
  function watch$1(source, cb, options = EMPTY_OBJ) {
    const { immediate, deep, once, scheduler, augmentJob, call } = options;
    const reactiveGetter = (source2) => {
      if (deep) return source2;
      if (/* @__PURE__ */ isShallow(source2) || deep === false || deep === 0)
        return traverse(source2, 1);
      return traverse(source2);
    };
    let effect2;
    let getter;
    let cleanup;
    let boundCleanup;
    let forceTrigger = false;
    let isMultiSource = false;
    if (/* @__PURE__ */ isRef(source)) {
      getter = () => source.value;
      forceTrigger = /* @__PURE__ */ isShallow(source);
    } else if (/* @__PURE__ */ isReactive(source)) {
      getter = () => reactiveGetter(source);
      forceTrigger = true;
    } else if (isArray(source)) {
      isMultiSource = true;
      forceTrigger = source.some((s) => /* @__PURE__ */ isReactive(s) || /* @__PURE__ */ isShallow(s));
      getter = () => source.map((s) => {
        if (/* @__PURE__ */ isRef(s)) {
          return s.value;
        } else if (/* @__PURE__ */ isReactive(s)) {
          return reactiveGetter(s);
        } else if (isFunction(s)) {
          return call ? call(s, 2) : s();
        } else ;
      });
    } else if (isFunction(source)) {
      if (cb) {
        getter = call ? () => call(source, 2) : source;
      } else {
        getter = () => {
          if (cleanup) {
            pauseTracking();
            try {
              cleanup();
            } finally {
              resetTracking();
            }
          }
          const currentEffect = activeWatcher;
          activeWatcher = effect2;
          try {
            return call ? call(source, 3, [boundCleanup]) : source(boundCleanup);
          } finally {
            activeWatcher = currentEffect;
          }
        };
      }
    } else {
      getter = NOOP;
    }
    if (cb && deep) {
      const baseGetter = getter;
      const depth = deep === true ? Infinity : deep;
      getter = () => traverse(baseGetter(), depth);
    }
    const scope = getCurrentScope();
    const watchHandle = () => {
      effect2.stop();
      if (scope && scope.active) {
        remove(scope.effects, effect2);
      }
    };
    if (once && cb) {
      const _cb = cb;
      cb = (...args) => {
        const res = _cb(...args);
        watchHandle();
        return res;
      };
    }
    let oldValue = isMultiSource ? new Array(source.length).fill(INITIAL_WATCHER_VALUE) : INITIAL_WATCHER_VALUE;
    const job = (immediateFirstRun) => {
      if (!(effect2.flags & 1) || !effect2.dirty && !immediateFirstRun) {
        return;
      }
      if (cb) {
        const newValue = effect2.run();
        if (immediateFirstRun || deep || forceTrigger || (isMultiSource ? newValue.some((v, i) => hasChanged(v, oldValue[i])) : hasChanged(newValue, oldValue))) {
          if (cleanup) {
            cleanup();
          }
          const currentWatcher = activeWatcher;
          activeWatcher = effect2;
          try {
            const args = [
              newValue,
              // pass undefined as the old value when it's changed for the first time
              oldValue === INITIAL_WATCHER_VALUE ? void 0 : isMultiSource && oldValue[0] === INITIAL_WATCHER_VALUE ? [] : oldValue,
              boundCleanup
            ];
            oldValue = newValue;
            call ? call(cb, 3, args) : (
              // @ts-expect-error
              cb(...args)
            );
          } finally {
            activeWatcher = currentWatcher;
          }
        }
      } else {
        effect2.run();
      }
    };
    if (augmentJob) {
      augmentJob(job);
    }
    effect2 = new ReactiveEffect(getter);
    effect2.scheduler = scheduler ? () => scheduler(job, false) : job;
    boundCleanup = (fn) => onWatcherCleanup(fn, false, effect2);
    cleanup = effect2.onStop = () => {
      const cleanups = cleanupMap.get(effect2);
      if (cleanups) {
        if (call) {
          call(cleanups, 4);
        } else {
          for (const cleanup2 of cleanups) cleanup2();
        }
        cleanupMap.delete(effect2);
      }
    };
    if (cb) {
      if (immediate) {
        job(true);
      } else {
        oldValue = effect2.run();
      }
    } else if (scheduler) {
      scheduler(job.bind(null, true), true);
    } else {
      effect2.run();
    }
    watchHandle.pause = effect2.pause.bind(effect2);
    watchHandle.resume = effect2.resume.bind(effect2);
    watchHandle.stop = watchHandle;
    return watchHandle;
  }
  function traverse(value, depth = Infinity, seen) {
    if (depth <= 0 || !isObject(value) || value["__v_skip"]) {
      return value;
    }
    seen = seen || /* @__PURE__ */ new Map();
    if ((seen.get(value) || 0) >= depth) {
      return value;
    }
    seen.set(value, depth);
    depth--;
    if (/* @__PURE__ */ isRef(value)) {
      traverse(value.value, depth, seen);
    } else if (isArray(value)) {
      for (let i = 0; i < value.length; i++) {
        traverse(value[i], depth, seen);
      }
    } else if (isSet(value) || isMap(value)) {
      value.forEach((v) => {
        traverse(v, depth, seen);
      });
    } else if (isPlainObject(value)) {
      for (const key in value) {
        traverse(value[key], depth, seen);
      }
      for (const key of Object.getOwnPropertySymbols(value)) {
        if (Object.prototype.propertyIsEnumerable.call(value, key)) {
          traverse(value[key], depth, seen);
        }
      }
    }
    return value;
  }
  /**
  * @vue/runtime-core v3.5.38
  * (c) 2018-present Yuxi (Evan) You and Vue contributors
  * @license MIT
  **/
  const stack = [];
  let isWarning = false;
  function warn$1(msg, ...args) {
    if (isWarning) return;
    isWarning = true;
    pauseTracking();
    const instance = stack.length ? stack[stack.length - 1].component : null;
    const appWarnHandler = instance && instance.appContext.config.warnHandler;
    const trace = getComponentTrace();
    if (appWarnHandler) {
      callWithErrorHandling(
        appWarnHandler,
        instance,
        11,
        [
          // eslint-disable-next-line no-restricted-syntax
          msg + args.map((a) => {
            var _a, _b;
            return (_b = (_a = a.toString) == null ? void 0 : _a.call(a)) != null ? _b : JSON.stringify(a);
          }).join(""),
          instance && instance.proxy,
          trace.map(
            ({ vnode }) => `at <${formatComponentName(instance, vnode.type)}>`
          ).join("\n"),
          trace
        ]
      );
    } else {
      const warnArgs = [`[Vue warn]: ${msg}`, ...args];
      if (trace.length && // avoid spamming console during tests
      true) {
        warnArgs.push(`
`, ...formatTrace(trace));
      }
      console.warn(...warnArgs);
    }
    resetTracking();
    isWarning = false;
  }
  function getComponentTrace() {
    let currentVNode = stack[stack.length - 1];
    if (!currentVNode) {
      return [];
    }
    const normalizedStack = [];
    while (currentVNode) {
      const last = normalizedStack[0];
      if (last && last.vnode === currentVNode) {
        last.recurseCount++;
      } else {
        normalizedStack.push({
          vnode: currentVNode,
          recurseCount: 0
        });
      }
      const parentInstance = currentVNode.component && currentVNode.component.parent;
      currentVNode = parentInstance && parentInstance.vnode;
    }
    return normalizedStack;
  }
  function formatTrace(trace) {
    const logs = [];
    trace.forEach((entry, i) => {
      logs.push(...i === 0 ? [] : [`
`], ...formatTraceEntry(entry));
    });
    return logs;
  }
  function formatTraceEntry({ vnode, recurseCount }) {
    const postfix = recurseCount > 0 ? `... (${recurseCount} recursive calls)` : ``;
    const isRoot = vnode.component ? vnode.component.parent == null : false;
    const open = ` at <${formatComponentName(
      vnode.component,
      vnode.type,
      isRoot
    )}`;
    const close = `>` + postfix;
    return vnode.props ? [open, ...formatProps(vnode.props), close] : [open + close];
  }
  function formatProps(props) {
    const res = [];
    const keys = Object.keys(props);
    keys.slice(0, 3).forEach((key) => {
      res.push(...formatProp(key, props[key]));
    });
    if (keys.length > 3) {
      res.push(` ...`);
    }
    return res;
  }
  function formatProp(key, value, raw) {
    if (isString(value)) {
      value = JSON.stringify(value);
      return raw ? value : [`${key}=${value}`];
    } else if (typeof value === "number" || typeof value === "boolean" || value == null) {
      return raw ? value : [`${key}=${value}`];
    } else if (/* @__PURE__ */ isRef(value)) {
      value = formatProp(key, /* @__PURE__ */ toRaw(value.value), true);
      return raw ? value : [`${key}=Ref<`, value, `>`];
    } else if (isFunction(value)) {
      return [`${key}=fn${value.name ? `<${value.name}>` : ``}`];
    } else {
      value = /* @__PURE__ */ toRaw(value);
      return raw ? value : [`${key}=`, value];
    }
  }
  function callWithErrorHandling(fn, instance, type, args) {
    try {
      return args ? fn(...args) : fn();
    } catch (err) {
      handleError(err, instance, type);
    }
  }
  function callWithAsyncErrorHandling(fn, instance, type, args) {
    if (isFunction(fn)) {
      const res = callWithErrorHandling(fn, instance, type, args);
      if (res && isPromise(res)) {
        res.catch((err) => {
          handleError(err, instance, type);
        });
      }
      return res;
    }
    if (isArray(fn)) {
      const values = [];
      for (let i = 0; i < fn.length; i++) {
        values.push(callWithAsyncErrorHandling(fn[i], instance, type, args));
      }
      return values;
    }
  }
  function handleError(err, instance, type, throwInDev = true) {
    const contextVNode = instance ? instance.vnode : null;
    const { errorHandler, throwUnhandledErrorInProduction } = instance && instance.appContext.config || EMPTY_OBJ;
    if (instance) {
      let cur = instance.parent;
      const exposedInstance = instance.proxy;
      const errorInfo = `https://vuejs.org/error-reference/#runtime-${type}`;
      while (cur) {
        const errorCapturedHooks = cur.ec;
        if (errorCapturedHooks) {
          for (let i = 0; i < errorCapturedHooks.length; i++) {
            if (errorCapturedHooks[i](err, exposedInstance, errorInfo) === false) {
              return;
            }
          }
        }
        cur = cur.parent;
      }
      if (errorHandler) {
        pauseTracking();
        callWithErrorHandling(errorHandler, null, 10, [
          err,
          exposedInstance,
          errorInfo
        ]);
        resetTracking();
        return;
      }
    }
    logError(err, type, contextVNode, throwInDev, throwUnhandledErrorInProduction);
  }
  function logError(err, type, contextVNode, throwInDev = true, throwInProd = false) {
    if (throwInProd) {
      throw err;
    } else {
      console.error(err);
    }
  }
  const queue = [];
  let flushIndex = -1;
  const pendingPostFlushCbs = [];
  let activePostFlushCbs = null;
  let postFlushIndex = 0;
  const resolvedPromise = /* @__PURE__ */ Promise.resolve();
  let currentFlushPromise = null;
  function nextTick(fn) {
    const p2 = currentFlushPromise || resolvedPromise;
    return fn ? p2.then(this ? fn.bind(this) : fn) : p2;
  }
  function findInsertionIndex(id) {
    let start = flushIndex + 1;
    let end = queue.length;
    while (start < end) {
      const middle = start + end >>> 1;
      const middleJob = queue[middle];
      const middleJobId = getId(middleJob);
      if (middleJobId < id || middleJobId === id && middleJob.flags & 2) {
        start = middle + 1;
      } else {
        end = middle;
      }
    }
    return start;
  }
  function queueJob(job) {
    if (!(job.flags & 1)) {
      const jobId = getId(job);
      const lastJob = queue[queue.length - 1];
      if (!lastJob || // fast path when the job id is larger than the tail
      !(job.flags & 2) && jobId >= getId(lastJob)) {
        queue.push(job);
      } else {
        queue.splice(findInsertionIndex(jobId), 0, job);
      }
      job.flags |= 1;
      queueFlush();
    }
  }
  function queueFlush() {
    if (!currentFlushPromise) {
      currentFlushPromise = resolvedPromise.then(flushJobs);
    }
  }
  function queuePostFlushCb(cb) {
    if (!isArray(cb)) {
      if (activePostFlushCbs && cb.id === -1) {
        activePostFlushCbs.splice(postFlushIndex + 1, 0, cb);
      } else if (!(cb.flags & 1)) {
        pendingPostFlushCbs.push(cb);
        cb.flags |= 1;
      }
    } else {
      pendingPostFlushCbs.push(...cb);
    }
    queueFlush();
  }
  function flushPreFlushCbs(instance, seen, i = flushIndex + 1) {
    for (; i < queue.length; i++) {
      const cb = queue[i];
      if (cb && cb.flags & 2) {
        if (instance && cb.id !== instance.uid) {
          continue;
        }
        queue.splice(i, 1);
        i--;
        if (cb.flags & 4) {
          cb.flags &= -2;
        }
        cb();
        if (!(cb.flags & 4)) {
          cb.flags &= -2;
        }
      }
    }
  }
  function flushPostFlushCbs(seen) {
    if (pendingPostFlushCbs.length) {
      const deduped = [...new Set(pendingPostFlushCbs)].sort(
        (a, b) => getId(a) - getId(b)
      );
      pendingPostFlushCbs.length = 0;
      if (activePostFlushCbs) {
        activePostFlushCbs.push(...deduped);
        return;
      }
      activePostFlushCbs = deduped;
      for (postFlushIndex = 0; postFlushIndex < activePostFlushCbs.length; postFlushIndex++) {
        const cb = activePostFlushCbs[postFlushIndex];
        if (cb.flags & 4) {
          cb.flags &= -2;
        }
        if (!(cb.flags & 8)) cb();
        cb.flags &= -2;
      }
      activePostFlushCbs = null;
      postFlushIndex = 0;
    }
  }
  const getId = (job) => job.id == null ? job.flags & 2 ? -1 : Infinity : job.id;
  function flushJobs(seen) {
    try {
      for (flushIndex = 0; flushIndex < queue.length; flushIndex++) {
        const job = queue[flushIndex];
        if (job && !(job.flags & 8)) {
          if (false) ;
          if (job.flags & 4) {
            job.flags &= ~1;
          }
          callWithErrorHandling(
            job,
            job.i,
            job.i ? 15 : 14
          );
          if (!(job.flags & 4)) {
            job.flags &= ~1;
          }
        }
      }
    } finally {
      for (; flushIndex < queue.length; flushIndex++) {
        const job = queue[flushIndex];
        if (job) {
          job.flags &= -2;
        }
      }
      flushIndex = -1;
      queue.length = 0;
      flushPostFlushCbs();
      currentFlushPromise = null;
      if (queue.length || pendingPostFlushCbs.length) {
        flushJobs();
      }
    }
  }
  let currentRenderingInstance = null;
  let currentScopeId = null;
  function setCurrentRenderingInstance(instance) {
    const prev = currentRenderingInstance;
    currentRenderingInstance = instance;
    currentScopeId = instance && instance.type.__scopeId || null;
    return prev;
  }
  function withCtx(fn, ctx = currentRenderingInstance, isNonScopedSlot) {
    if (!ctx) return fn;
    if (fn._n) {
      return fn;
    }
    const renderFnWithContext = (...args) => {
      if (renderFnWithContext._d) {
        setBlockTracking(-1);
      }
      const prevInstance = setCurrentRenderingInstance(ctx);
      let res;
      try {
        res = fn(...args);
      } finally {
        setCurrentRenderingInstance(prevInstance);
        if (renderFnWithContext._d) {
          setBlockTracking(1);
        }
      }
      return res;
    };
    renderFnWithContext._n = true;
    renderFnWithContext._c = true;
    renderFnWithContext._d = true;
    return renderFnWithContext;
  }
  function withDirectives(vnode, directives) {
    if (currentRenderingInstance === null) {
      return vnode;
    }
    const instance = getComponentPublicInstance(currentRenderingInstance);
    const bindings = vnode.dirs || (vnode.dirs = []);
    for (let i = 0; i < directives.length; i++) {
      let [dir, value, arg, modifiers = EMPTY_OBJ] = directives[i];
      if (dir) {
        if (isFunction(dir)) {
          dir = {
            mounted: dir,
            updated: dir
          };
        }
        if (dir.deep) {
          traverse(value);
        }
        bindings.push({
          dir,
          instance,
          value,
          oldValue: void 0,
          arg,
          modifiers
        });
      }
    }
    return vnode;
  }
  function invokeDirectiveHook(vnode, prevVNode, instance, name) {
    const bindings = vnode.dirs;
    const oldBindings = prevVNode && prevVNode.dirs;
    for (let i = 0; i < bindings.length; i++) {
      const binding = bindings[i];
      if (oldBindings) {
        binding.oldValue = oldBindings[i].value;
      }
      let hook = binding.dir[name];
      if (hook) {
        pauseTracking();
        callWithAsyncErrorHandling(hook, instance, 8, [
          vnode.el,
          binding,
          vnode,
          prevVNode
        ]);
        resetTracking();
      }
    }
  }
  function provide(key, value) {
    if (currentInstance) {
      let provides = currentInstance.provides;
      const parentProvides = currentInstance.parent && currentInstance.parent.provides;
      if (parentProvides === provides) {
        provides = currentInstance.provides = Object.create(parentProvides);
      }
      provides[key] = value;
    }
  }
  function inject(key, defaultValue, treatDefaultAsFactory = false) {
    const instance = getCurrentInstance();
    if (instance || currentApp) {
      let provides = currentApp ? currentApp._context.provides : instance ? instance.parent == null || instance.ce ? instance.vnode.appContext && instance.vnode.appContext.provides : instance.parent.provides : void 0;
      if (provides && key in provides) {
        return provides[key];
      } else if (arguments.length > 1) {
        return treatDefaultAsFactory && isFunction(defaultValue) ? defaultValue.call(instance && instance.proxy) : defaultValue;
      } else ;
    }
  }
  const ssrContextKey = /* @__PURE__ */ Symbol.for("v-scx");
  const useSSRContext = () => {
    {
      const ctx = inject(ssrContextKey);
      return ctx;
    }
  };
  function watch(source, cb, options) {
    return doWatch(source, cb, options);
  }
  function doWatch(source, cb, options = EMPTY_OBJ) {
    const { immediate, deep, flush, once } = options;
    const baseWatchOptions = extend({}, options);
    const runsImmediately = cb && immediate || !cb && flush !== "post";
    let ssrCleanup;
    if (isInSSRComponentSetup) {
      if (flush === "sync") {
        const ctx = useSSRContext();
        ssrCleanup = ctx.__watcherHandles || (ctx.__watcherHandles = []);
      } else if (!runsImmediately) {
        const watchStopHandle = () => {
        };
        watchStopHandle.stop = NOOP;
        watchStopHandle.resume = NOOP;
        watchStopHandle.pause = NOOP;
        return watchStopHandle;
      }
    }
    const instance = currentInstance;
    baseWatchOptions.call = (fn, type, args) => callWithAsyncErrorHandling(fn, instance, type, args);
    let isPre = false;
    if (flush === "post") {
      baseWatchOptions.scheduler = (job) => {
        queuePostRenderEffect(job, instance && instance.suspense);
      };
    } else if (flush !== "sync") {
      isPre = true;
      baseWatchOptions.scheduler = (job, isFirstRun) => {
        if (isFirstRun) {
          job();
        } else {
          queueJob(job);
        }
      };
    }
    baseWatchOptions.augmentJob = (job) => {
      if (cb) {
        job.flags |= 4;
      }
      if (isPre) {
        job.flags |= 2;
        if (instance) {
          job.id = instance.uid;
          job.i = instance;
        }
      }
    };
    const watchHandle = watch$1(source, cb, baseWatchOptions);
    if (isInSSRComponentSetup) {
      if (ssrCleanup) {
        ssrCleanup.push(watchHandle);
      } else if (runsImmediately) {
        watchHandle();
      }
    }
    return watchHandle;
  }
  function instanceWatch(source, value, options) {
    const publicThis = this.proxy;
    const getter = isString(source) ? source.includes(".") ? createPathGetter(publicThis, source) : () => publicThis[source] : source.bind(publicThis, publicThis);
    let cb;
    if (isFunction(value)) {
      cb = value;
    } else {
      cb = value.handler;
      options = value;
    }
    const reset = setCurrentInstance(this);
    const res = doWatch(getter, cb.bind(publicThis), options);
    reset();
    return res;
  }
  function createPathGetter(ctx, path) {
    const segments = path.split(".");
    return () => {
      let cur = ctx;
      for (let i = 0; i < segments.length && cur; i++) {
        cur = cur[segments[i]];
      }
      return cur;
    };
  }
  const TeleportEndKey = /* @__PURE__ */ Symbol("_vte");
  const isTeleport = (type) => type.__isTeleport;
  const leaveCbKey = /* @__PURE__ */ Symbol("_leaveCb");
  function setTransitionHooks(vnode, hooks) {
    if (vnode.shapeFlag & 6 && vnode.component) {
      vnode.transition = hooks;
      setTransitionHooks(vnode.component.subTree, hooks);
    } else if (vnode.shapeFlag & 128) {
      vnode.ssContent.transition = hooks.clone(vnode.ssContent);
      vnode.ssFallback.transition = hooks.clone(vnode.ssFallback);
    } else {
      vnode.transition = hooks;
    }
  }
  // @__NO_SIDE_EFFECTS__
  function defineComponent(options, extraOptions) {
    return isFunction(options) ? (
      // #8236: extend call and options.name access are considered side-effects
      // by Rollup, so we have to wrap it in a pure-annotated IIFE.
      /* @__PURE__ */ (() => extend({ name: options.name }, extraOptions, { setup: options }))()
    ) : options;
  }
  function markAsyncBoundary(instance) {
    instance.ids = [instance.ids[0] + instance.ids[2]++ + "-", 0, 0];
  }
  function isTemplateRefKey(refs, key) {
    let desc;
    return !!((desc = Object.getOwnPropertyDescriptor(refs, key)) && !desc.configurable);
  }
  const pendingSetRefMap = /* @__PURE__ */ new WeakMap();
  function setRef(rawRef, oldRawRef, parentSuspense, vnode, isUnmount = false) {
    if (isArray(rawRef)) {
      rawRef.forEach(
        (r, i) => setRef(
          r,
          oldRawRef && (isArray(oldRawRef) ? oldRawRef[i] : oldRawRef),
          parentSuspense,
          vnode,
          isUnmount
        )
      );
      return;
    }
    if (isAsyncWrapper(vnode) && !isUnmount) {
      if (vnode.shapeFlag & 512 && vnode.type.__asyncResolved && vnode.component.subTree.component) {
        setRef(rawRef, oldRawRef, parentSuspense, vnode.component.subTree);
      }
      return;
    }
    const refValue = vnode.shapeFlag & 4 ? getComponentPublicInstance(vnode.component) : vnode.el;
    const value = isUnmount ? null : refValue;
    const { i: owner, r: ref3 } = rawRef;
    const oldRef = oldRawRef && oldRawRef.r;
    const refs = owner.refs === EMPTY_OBJ ? owner.refs = {} : owner.refs;
    const setupState = owner.setupState;
    const rawSetupState = /* @__PURE__ */ toRaw(setupState);
    const canSetSetupRef = setupState === EMPTY_OBJ ? NO : (key) => {
      if (isTemplateRefKey(refs, key)) {
        return false;
      }
      return hasOwn(rawSetupState, key);
    };
    const canSetRef = (ref22, key) => {
      if (key && isTemplateRefKey(refs, key)) {
        return false;
      }
      return true;
    };
    if (oldRef != null && oldRef !== ref3) {
      invalidatePendingSetRef(oldRawRef);
      if (isString(oldRef)) {
        refs[oldRef] = null;
        if (canSetSetupRef(oldRef)) {
          setupState[oldRef] = null;
        }
      } else if (/* @__PURE__ */ isRef(oldRef)) {
        const oldRawRefAtom = oldRawRef;
        if (canSetRef(oldRef, oldRawRefAtom.k)) {
          oldRef.value = null;
        }
        if (oldRawRefAtom.k) refs[oldRawRefAtom.k] = null;
      }
    }
    if (isFunction(ref3)) {
      callWithErrorHandling(ref3, owner, 12, [value, refs]);
    } else {
      const _isString = isString(ref3);
      const _isRef = /* @__PURE__ */ isRef(ref3);
      if (_isString || _isRef) {
        const doSet = () => {
          if (rawRef.f) {
            const existing = _isString ? canSetSetupRef(ref3) ? setupState[ref3] : refs[ref3] : canSetRef() || !rawRef.k ? ref3.value : refs[rawRef.k];
            if (isUnmount) {
              isArray(existing) && remove(existing, refValue);
            } else {
              if (!isArray(existing)) {
                if (_isString) {
                  refs[ref3] = [refValue];
                  if (canSetSetupRef(ref3)) {
                    setupState[ref3] = refs[ref3];
                  }
                } else {
                  const newVal = [refValue];
                  if (canSetRef(ref3, rawRef.k)) {
                    ref3.value = newVal;
                  }
                  if (rawRef.k) refs[rawRef.k] = newVal;
                }
              } else if (!existing.includes(refValue)) {
                existing.push(refValue);
              }
            }
          } else if (_isString) {
            refs[ref3] = value;
            if (canSetSetupRef(ref3)) {
              setupState[ref3] = value;
            }
          } else if (_isRef) {
            if (canSetRef(ref3, rawRef.k)) {
              ref3.value = value;
            }
            if (rawRef.k) refs[rawRef.k] = value;
          } else ;
        };
        if (value) {
          const job = () => {
            doSet();
            pendingSetRefMap.delete(rawRef);
          };
          job.id = -1;
          pendingSetRefMap.set(rawRef, job);
          queuePostRenderEffect(job, parentSuspense);
        } else {
          invalidatePendingSetRef(rawRef);
          doSet();
        }
      }
    }
  }
  function invalidatePendingSetRef(rawRef) {
    const pendingSetRef = pendingSetRefMap.get(rawRef);
    if (pendingSetRef) {
      pendingSetRef.flags |= 8;
      pendingSetRefMap.delete(rawRef);
    }
  }
  getGlobalThis().requestIdleCallback || ((cb) => setTimeout(cb, 1));
  getGlobalThis().cancelIdleCallback || ((id) => clearTimeout(id));
  const isAsyncWrapper = (i) => !!i.type.__asyncLoader;
  const isKeepAlive = (vnode) => vnode.type.__isKeepAlive;
  function onActivated(hook, target) {
    registerKeepAliveHook(hook, "a", target);
  }
  function onDeactivated(hook, target) {
    registerKeepAliveHook(hook, "da", target);
  }
  function registerKeepAliveHook(hook, type, target = currentInstance) {
    const wrappedHook = hook.__wdc || (hook.__wdc = () => {
      let current = target;
      while (current) {
        if (current.isDeactivated) {
          return;
        }
        current = current.parent;
      }
      return hook();
    });
    injectHook(type, wrappedHook, target);
    if (target) {
      let current = target.parent;
      while (current && current.parent) {
        if (isKeepAlive(current.parent.vnode)) {
          injectToKeepAliveRoot(wrappedHook, type, target, current);
        }
        current = current.parent;
      }
    }
  }
  function injectToKeepAliveRoot(hook, type, target, keepAliveRoot) {
    const injected = injectHook(
      type,
      hook,
      keepAliveRoot,
      true
      /* prepend */
    );
    onUnmounted(() => {
      remove(keepAliveRoot[type], injected);
    }, target);
  }
  function injectHook(type, hook, target = currentInstance, prepend = false) {
    if (target) {
      const hooks = target[type] || (target[type] = []);
      const wrappedHook = hook.__weh || (hook.__weh = (...args) => {
        pauseTracking();
        const reset = setCurrentInstance(target);
        const res = callWithAsyncErrorHandling(hook, target, type, args);
        reset();
        resetTracking();
        return res;
      });
      if (prepend) {
        hooks.unshift(wrappedHook);
      } else {
        hooks.push(wrappedHook);
      }
      return wrappedHook;
    }
  }
  const createHook = (lifecycle) => (hook, target = currentInstance) => {
    if (!isInSSRComponentSetup || lifecycle === "sp") {
      injectHook(lifecycle, (...args) => hook(...args), target);
    }
  };
  const onBeforeMount = createHook("bm");
  const onMounted = createHook("m");
  const onBeforeUpdate = createHook(
    "bu"
  );
  const onUpdated = createHook("u");
  const onBeforeUnmount = createHook(
    "bum"
  );
  const onUnmounted = createHook("um");
  const onServerPrefetch = createHook(
    "sp"
  );
  const onRenderTriggered = createHook("rtg");
  const onRenderTracked = createHook("rtc");
  function onErrorCaptured(hook, target = currentInstance) {
    injectHook("ec", hook, target);
  }
  const NULL_DYNAMIC_COMPONENT = /* @__PURE__ */ Symbol.for("v-ndc");
  function renderList(source, renderItem, cache, index) {
    let ret;
    const cached = cache;
    const sourceIsArray = isArray(source);
    if (sourceIsArray || isString(source)) {
      const sourceIsReactiveArray = sourceIsArray && /* @__PURE__ */ isReactive(source);
      let needsWrap = false;
      let isReadonlySource = false;
      if (sourceIsReactiveArray) {
        needsWrap = !/* @__PURE__ */ isShallow(source);
        isReadonlySource = /* @__PURE__ */ isReadonly(source);
        source = shallowReadArray(source);
      }
      ret = new Array(source.length);
      for (let i = 0, l = source.length; i < l; i++) {
        ret[i] = renderItem(
          needsWrap ? isReadonlySource ? toReadonly(toReactive(source[i])) : toReactive(source[i]) : source[i],
          i,
          void 0,
          cached
        );
      }
    } else if (typeof source === "number") {
      {
        ret = new Array(source);
        for (let i = 0; i < source; i++) {
          ret[i] = renderItem(i + 1, i, void 0, cached);
        }
      }
    } else if (isObject(source)) {
      if (source[Symbol.iterator]) {
        ret = Array.from(
          source,
          (item, i) => renderItem(item, i, void 0, cached)
        );
      } else {
        const keys = Object.keys(source);
        ret = new Array(keys.length);
        for (let i = 0, l = keys.length; i < l; i++) {
          const key = keys[i];
          ret[i] = renderItem(source[key], key, i, cached);
        }
      }
    } else {
      ret = [];
    }
    return ret;
  }
  const getPublicInstance = (i) => {
    if (!i) return null;
    if (isStatefulComponent(i)) return getComponentPublicInstance(i);
    return getPublicInstance(i.parent);
  };
  const publicPropertiesMap = (
    // Move PURE marker to new line to workaround compiler discarding it
    // due to type annotation
    /* @__PURE__ */ extend(/* @__PURE__ */ Object.create(null), {
      $: (i) => i,
      $el: (i) => i.vnode.el,
      $data: (i) => i.data,
      $props: (i) => i.props,
      $attrs: (i) => i.attrs,
      $slots: (i) => i.slots,
      $refs: (i) => i.refs,
      $parent: (i) => getPublicInstance(i.parent),
      $root: (i) => getPublicInstance(i.root),
      $host: (i) => i.ce,
      $emit: (i) => i.emit,
      $options: (i) => resolveMergedOptions(i),
      $forceUpdate: (i) => i.f || (i.f = () => {
        queueJob(i.update);
      }),
      $nextTick: (i) => i.n || (i.n = nextTick.bind(i.proxy)),
      $watch: (i) => instanceWatch.bind(i)
    })
  );
  const hasSetupBinding = (state, key) => state !== EMPTY_OBJ && !state.__isScriptSetup && hasOwn(state, key);
  const PublicInstanceProxyHandlers = {
    get({ _: instance }, key) {
      if (key === "__v_skip") {
        return true;
      }
      const { ctx, setupState, data, props, accessCache, type, appContext } = instance;
      if (key[0] !== "$") {
        const n = accessCache[key];
        if (n !== void 0) {
          switch (n) {
            case 1:
              return setupState[key];
            case 2:
              return data[key];
            case 4:
              return ctx[key];
            case 3:
              return props[key];
          }
        } else if (hasSetupBinding(setupState, key)) {
          accessCache[key] = 1;
          return setupState[key];
        } else if (data !== EMPTY_OBJ && hasOwn(data, key)) {
          accessCache[key] = 2;
          return data[key];
        } else if (hasOwn(props, key)) {
          accessCache[key] = 3;
          return props[key];
        } else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
          accessCache[key] = 4;
          return ctx[key];
        } else if (shouldCacheAccess) {
          accessCache[key] = 0;
        }
      }
      const publicGetter = publicPropertiesMap[key];
      let cssModule, globalProperties;
      if (publicGetter) {
        if (key === "$attrs") {
          track(instance.attrs, "get", "");
        }
        return publicGetter(instance);
      } else if (
        // css module (injected by vue-loader)
        (cssModule = type.__cssModules) && (cssModule = cssModule[key])
      ) {
        return cssModule;
      } else if (ctx !== EMPTY_OBJ && hasOwn(ctx, key)) {
        accessCache[key] = 4;
        return ctx[key];
      } else if (
        // global properties
        globalProperties = appContext.config.globalProperties, hasOwn(globalProperties, key)
      ) {
        {
          return globalProperties[key];
        }
      } else ;
    },
    set({ _: instance }, key, value) {
      const { data, setupState, ctx } = instance;
      if (hasSetupBinding(setupState, key)) {
        setupState[key] = value;
        return true;
      } else if (data !== EMPTY_OBJ && hasOwn(data, key)) {
        data[key] = value;
        return true;
      } else if (hasOwn(instance.props, key)) {
        return false;
      }
      if (key[0] === "$" && key.slice(1) in instance) {
        return false;
      } else {
        {
          ctx[key] = value;
        }
      }
      return true;
    },
    has({
      _: { data, setupState, accessCache, ctx, appContext, props, type }
    }, key) {
      let cssModules;
      return !!(accessCache[key] || data !== EMPTY_OBJ && key[0] !== "$" && hasOwn(data, key) || hasSetupBinding(setupState, key) || hasOwn(props, key) || hasOwn(ctx, key) || hasOwn(publicPropertiesMap, key) || hasOwn(appContext.config.globalProperties, key) || (cssModules = type.__cssModules) && cssModules[key]);
    },
    defineProperty(target, key, descriptor) {
      if (descriptor.get != null) {
        target._.accessCache[key] = 0;
      } else if (hasOwn(descriptor, "value")) {
        this.set(target, key, descriptor.value, null);
      }
      return Reflect.defineProperty(target, key, descriptor);
    }
  };
  function normalizePropsOrEmits(props) {
    return isArray(props) ? props.reduce(
      (normalized, p2) => (normalized[p2] = null, normalized),
      {}
    ) : props;
  }
  let shouldCacheAccess = true;
  function applyOptions(instance) {
    const options = resolveMergedOptions(instance);
    const publicThis = instance.proxy;
    const ctx = instance.ctx;
    shouldCacheAccess = false;
    if (options.beforeCreate) {
      callHook(options.beforeCreate, instance, "bc");
    }
    const {
      // state
      data: dataOptions,
      computed: computedOptions,
      methods,
      watch: watchOptions,
      provide: provideOptions,
      inject: injectOptions,
      // lifecycle
      created,
      beforeMount,
      mounted,
      beforeUpdate,
      updated,
      activated,
      deactivated,
      beforeDestroy,
      beforeUnmount,
      destroyed,
      unmounted,
      render,
      renderTracked,
      renderTriggered,
      errorCaptured,
      serverPrefetch,
      // public API
      expose,
      inheritAttrs,
      // assets
      components,
      directives,
      filters
    } = options;
    const checkDuplicateProperties = null;
    if (injectOptions) {
      resolveInjections(injectOptions, ctx, checkDuplicateProperties);
    }
    if (methods) {
      for (const key in methods) {
        const methodHandler = methods[key];
        if (isFunction(methodHandler)) {
          {
            ctx[key] = methodHandler.bind(publicThis);
          }
        }
      }
    }
    if (dataOptions) {
      const data = dataOptions.call(publicThis, publicThis);
      if (!isObject(data)) ;
      else {
        instance.data = /* @__PURE__ */ reactive(data);
      }
    }
    shouldCacheAccess = true;
    if (computedOptions) {
      for (const key in computedOptions) {
        const opt = computedOptions[key];
        const get = isFunction(opt) ? opt.bind(publicThis, publicThis) : isFunction(opt.get) ? opt.get.bind(publicThis, publicThis) : NOOP;
        const set = !isFunction(opt) && isFunction(opt.set) ? opt.set.bind(publicThis) : NOOP;
        const c = computed({
          get,
          set
        });
        Object.defineProperty(ctx, key, {
          enumerable: true,
          configurable: true,
          get: () => c.value,
          set: (v) => c.value = v
        });
      }
    }
    if (watchOptions) {
      for (const key in watchOptions) {
        createWatcher(watchOptions[key], ctx, publicThis, key);
      }
    }
    if (provideOptions) {
      const provides = isFunction(provideOptions) ? provideOptions.call(publicThis) : provideOptions;
      Reflect.ownKeys(provides).forEach((key) => {
        provide(key, provides[key]);
      });
    }
    if (created) {
      callHook(created, instance, "c");
    }
    function registerLifecycleHook(register, hook) {
      if (isArray(hook)) {
        hook.forEach((_hook) => register(_hook.bind(publicThis)));
      } else if (hook) {
        register(hook.bind(publicThis));
      }
    }
    registerLifecycleHook(onBeforeMount, beforeMount);
    registerLifecycleHook(onMounted, mounted);
    registerLifecycleHook(onBeforeUpdate, beforeUpdate);
    registerLifecycleHook(onUpdated, updated);
    registerLifecycleHook(onActivated, activated);
    registerLifecycleHook(onDeactivated, deactivated);
    registerLifecycleHook(onErrorCaptured, errorCaptured);
    registerLifecycleHook(onRenderTracked, renderTracked);
    registerLifecycleHook(onRenderTriggered, renderTriggered);
    registerLifecycleHook(onBeforeUnmount, beforeUnmount);
    registerLifecycleHook(onUnmounted, unmounted);
    registerLifecycleHook(onServerPrefetch, serverPrefetch);
    if (isArray(expose)) {
      if (expose.length) {
        const exposed = instance.exposed || (instance.exposed = {});
        expose.forEach((key) => {
          Object.defineProperty(exposed, key, {
            get: () => publicThis[key],
            set: (val) => publicThis[key] = val,
            enumerable: true
          });
        });
      } else if (!instance.exposed) {
        instance.exposed = {};
      }
    }
    if (render && instance.render === NOOP) {
      instance.render = render;
    }
    if (inheritAttrs != null) {
      instance.inheritAttrs = inheritAttrs;
    }
    if (components) instance.components = components;
    if (directives) instance.directives = directives;
    if (serverPrefetch) {
      markAsyncBoundary(instance);
    }
  }
  function resolveInjections(injectOptions, ctx, checkDuplicateProperties = NOOP) {
    if (isArray(injectOptions)) {
      injectOptions = normalizeInject(injectOptions);
    }
    for (const key in injectOptions) {
      const opt = injectOptions[key];
      let injected;
      if (isObject(opt)) {
        if ("default" in opt) {
          injected = inject(
            opt.from || key,
            opt.default,
            true
          );
        } else {
          injected = inject(opt.from || key);
        }
      } else {
        injected = inject(opt);
      }
      if (/* @__PURE__ */ isRef(injected)) {
        Object.defineProperty(ctx, key, {
          enumerable: true,
          configurable: true,
          get: () => injected.value,
          set: (v) => injected.value = v
        });
      } else {
        ctx[key] = injected;
      }
    }
  }
  function callHook(hook, instance, type) {
    callWithAsyncErrorHandling(
      isArray(hook) ? hook.map((h2) => h2.bind(instance.proxy)) : hook.bind(instance.proxy),
      instance,
      type
    );
  }
  function createWatcher(raw, ctx, publicThis, key) {
    let getter = key.includes(".") ? createPathGetter(publicThis, key) : () => publicThis[key];
    if (isString(raw)) {
      const handler = ctx[raw];
      if (isFunction(handler)) {
        {
          watch(getter, handler);
        }
      }
    } else if (isFunction(raw)) {
      {
        watch(getter, raw.bind(publicThis));
      }
    } else if (isObject(raw)) {
      if (isArray(raw)) {
        raw.forEach((r) => createWatcher(r, ctx, publicThis, key));
      } else {
        const handler = isFunction(raw.handler) ? raw.handler.bind(publicThis) : ctx[raw.handler];
        if (isFunction(handler)) {
          watch(getter, handler, raw);
        }
      }
    } else ;
  }
  function resolveMergedOptions(instance) {
    const base = instance.type;
    const { mixins, extends: extendsOptions } = base;
    const {
      mixins: globalMixins,
      optionsCache: cache,
      config: { optionMergeStrategies }
    } = instance.appContext;
    const cached = cache.get(base);
    let resolved;
    if (cached) {
      resolved = cached;
    } else if (!globalMixins.length && !mixins && !extendsOptions) {
      {
        resolved = base;
      }
    } else {
      resolved = {};
      if (globalMixins.length) {
        globalMixins.forEach(
          (m) => mergeOptions(resolved, m, optionMergeStrategies, true)
        );
      }
      mergeOptions(resolved, base, optionMergeStrategies);
    }
    if (isObject(base)) {
      cache.set(base, resolved);
    }
    return resolved;
  }
  function mergeOptions(to, from, strats, asMixin = false) {
    const { mixins, extends: extendsOptions } = from;
    if (extendsOptions) {
      mergeOptions(to, extendsOptions, strats, true);
    }
    if (mixins) {
      mixins.forEach(
        (m) => mergeOptions(to, m, strats, true)
      );
    }
    for (const key in from) {
      if (asMixin && key === "expose") ;
      else {
        const strat = internalOptionMergeStrats[key] || strats && strats[key];
        to[key] = strat ? strat(to[key], from[key]) : from[key];
      }
    }
    return to;
  }
  const internalOptionMergeStrats = {
    data: mergeDataFn,
    props: mergeEmitsOrPropsOptions,
    emits: mergeEmitsOrPropsOptions,
    // objects
    methods: mergeObjectOptions,
    computed: mergeObjectOptions,
    // lifecycle
    beforeCreate: mergeAsArray,
    created: mergeAsArray,
    beforeMount: mergeAsArray,
    mounted: mergeAsArray,
    beforeUpdate: mergeAsArray,
    updated: mergeAsArray,
    beforeDestroy: mergeAsArray,
    beforeUnmount: mergeAsArray,
    destroyed: mergeAsArray,
    unmounted: mergeAsArray,
    activated: mergeAsArray,
    deactivated: mergeAsArray,
    errorCaptured: mergeAsArray,
    serverPrefetch: mergeAsArray,
    // assets
    components: mergeObjectOptions,
    directives: mergeObjectOptions,
    // watch
    watch: mergeWatchOptions,
    // provide / inject
    provide: mergeDataFn,
    inject: mergeInject
  };
  function mergeDataFn(to, from) {
    if (!from) {
      return to;
    }
    if (!to) {
      return from;
    }
    return function mergedDataFn() {
      return extend(
        isFunction(to) ? to.call(this, this) : to,
        isFunction(from) ? from.call(this, this) : from
      );
    };
  }
  function mergeInject(to, from) {
    return mergeObjectOptions(normalizeInject(to), normalizeInject(from));
  }
  function normalizeInject(raw) {
    if (isArray(raw)) {
      const res = {};
      for (let i = 0; i < raw.length; i++) {
        res[raw[i]] = raw[i];
      }
      return res;
    }
    return raw;
  }
  function mergeAsArray(to, from) {
    return to ? [...new Set([].concat(to, from))] : from;
  }
  function mergeObjectOptions(to, from) {
    return to ? extend(/* @__PURE__ */ Object.create(null), to, from) : from;
  }
  function mergeEmitsOrPropsOptions(to, from) {
    if (to) {
      if (isArray(to) && isArray(from)) {
        return [.../* @__PURE__ */ new Set([...to, ...from])];
      }
      return extend(
        /* @__PURE__ */ Object.create(null),
        normalizePropsOrEmits(to),
        normalizePropsOrEmits(from != null ? from : {})
      );
    } else {
      return from;
    }
  }
  function mergeWatchOptions(to, from) {
    if (!to) return from;
    if (!from) return to;
    const merged = extend(/* @__PURE__ */ Object.create(null), to);
    for (const key in from) {
      merged[key] = mergeAsArray(to[key], from[key]);
    }
    return merged;
  }
  function createAppContext() {
    return {
      app: null,
      config: {
        isNativeTag: NO,
        performance: false,
        globalProperties: {},
        optionMergeStrategies: {},
        errorHandler: void 0,
        warnHandler: void 0,
        compilerOptions: {}
      },
      mixins: [],
      components: {},
      directives: {},
      provides: /* @__PURE__ */ Object.create(null),
      optionsCache: /* @__PURE__ */ new WeakMap(),
      propsCache: /* @__PURE__ */ new WeakMap(),
      emitsCache: /* @__PURE__ */ new WeakMap()
    };
  }
  let uid$1 = 0;
  function createAppAPI(render, hydrate) {
    return function createApp2(rootComponent, rootProps = null) {
      if (!isFunction(rootComponent)) {
        rootComponent = extend({}, rootComponent);
      }
      if (rootProps != null && !isObject(rootProps)) {
        rootProps = null;
      }
      const context = createAppContext();
      const installedPlugins = /* @__PURE__ */ new WeakSet();
      const pluginCleanupFns = [];
      let isMounted = false;
      const app = context.app = {
        _uid: uid$1++,
        _component: rootComponent,
        _props: rootProps,
        _container: null,
        _context: context,
        _instance: null,
        version,
        get config() {
          return context.config;
        },
        set config(v) {
        },
        use(plugin, ...options) {
          if (installedPlugins.has(plugin)) ;
          else if (plugin && isFunction(plugin.install)) {
            installedPlugins.add(plugin);
            plugin.install(app, ...options);
          } else if (isFunction(plugin)) {
            installedPlugins.add(plugin);
            plugin(app, ...options);
          } else ;
          return app;
        },
        mixin(mixin) {
          {
            if (!context.mixins.includes(mixin)) {
              context.mixins.push(mixin);
            }
          }
          return app;
        },
        component(name, component) {
          if (!component) {
            return context.components[name];
          }
          context.components[name] = component;
          return app;
        },
        directive(name, directive) {
          if (!directive) {
            return context.directives[name];
          }
          context.directives[name] = directive;
          return app;
        },
        mount(rootContainer, isHydrate, namespace) {
          if (!isMounted) {
            const vnode = app._ceVNode || createVNode(rootComponent, rootProps);
            vnode.appContext = context;
            if (namespace === true) {
              namespace = "svg";
            } else if (namespace === false) {
              namespace = void 0;
            }
            {
              render(vnode, rootContainer, namespace);
            }
            isMounted = true;
            app._container = rootContainer;
            rootContainer.__vue_app__ = app;
            return getComponentPublicInstance(vnode.component);
          }
        },
        onUnmount(cleanupFn) {
          pluginCleanupFns.push(cleanupFn);
        },
        unmount() {
          if (isMounted) {
            callWithAsyncErrorHandling(
              pluginCleanupFns,
              app._instance,
              16
            );
            render(null, app._container);
            delete app._container.__vue_app__;
          }
        },
        provide(key, value) {
          context.provides[key] = value;
          return app;
        },
        runWithContext(fn) {
          const lastApp = currentApp;
          currentApp = app;
          try {
            return fn();
          } finally {
            currentApp = lastApp;
          }
        }
      };
      return app;
    };
  }
  let currentApp = null;
  const getModelModifiers = (props, modelName) => {
    return modelName === "modelValue" || modelName === "model-value" ? props.modelModifiers : props[`${modelName}Modifiers`] || props[`${camelize(modelName)}Modifiers`] || props[`${hyphenate(modelName)}Modifiers`];
  };
  function emit(instance, event, ...rawArgs) {
    if (instance.isUnmounted) return;
    const props = instance.vnode.props || EMPTY_OBJ;
    let args = rawArgs;
    const isModelListener2 = event.startsWith("update:");
    const modifiers = isModelListener2 && getModelModifiers(props, event.slice(7));
    if (modifiers) {
      if (modifiers.trim) {
        args = rawArgs.map((a) => isString(a) ? a.trim() : a);
      }
      if (modifiers.number) {
        args = rawArgs.map(looseToNumber);
      }
    }
    let handlerName;
    let handler = props[handlerName = toHandlerKey(event)] || // also try camelCase event handler (#2249)
    props[handlerName = toHandlerKey(camelize(event))];
    if (!handler && isModelListener2) {
      handler = props[handlerName = toHandlerKey(hyphenate(event))];
    }
    if (handler) {
      callWithAsyncErrorHandling(
        handler,
        instance,
        6,
        args
      );
    }
    const onceHandler = props[handlerName + `Once`];
    if (onceHandler) {
      if (!instance.emitted) {
        instance.emitted = {};
      } else if (instance.emitted[handlerName]) {
        return;
      }
      instance.emitted[handlerName] = true;
      callWithAsyncErrorHandling(
        onceHandler,
        instance,
        6,
        args
      );
    }
  }
  const mixinEmitsCache = /* @__PURE__ */ new WeakMap();
  function normalizeEmitsOptions(comp, appContext, asMixin = false) {
    const cache = asMixin ? mixinEmitsCache : appContext.emitsCache;
    const cached = cache.get(comp);
    if (cached !== void 0) {
      return cached;
    }
    const raw = comp.emits;
    let normalized = {};
    let hasExtends = false;
    if (!isFunction(comp)) {
      const extendEmits = (raw2) => {
        const normalizedFromExtend = normalizeEmitsOptions(raw2, appContext, true);
        if (normalizedFromExtend) {
          hasExtends = true;
          extend(normalized, normalizedFromExtend);
        }
      };
      if (!asMixin && appContext.mixins.length) {
        appContext.mixins.forEach(extendEmits);
      }
      if (comp.extends) {
        extendEmits(comp.extends);
      }
      if (comp.mixins) {
        comp.mixins.forEach(extendEmits);
      }
    }
    if (!raw && !hasExtends) {
      if (isObject(comp)) {
        cache.set(comp, null);
      }
      return null;
    }
    if (isArray(raw)) {
      raw.forEach((key) => normalized[key] = null);
    } else {
      extend(normalized, raw);
    }
    if (isObject(comp)) {
      cache.set(comp, normalized);
    }
    return normalized;
  }
  function isEmitListener(options, key) {
    if (!options || !isOn(key)) {
      return false;
    }
    key = key.slice(2).replace(/Once$/, "");
    return hasOwn(options, key[0].toLowerCase() + key.slice(1)) || hasOwn(options, hyphenate(key)) || hasOwn(options, key);
  }
  function markAttrsAccessed() {
  }
  function renderComponentRoot(instance) {
    const {
      type: Component,
      vnode,
      proxy,
      withProxy,
      propsOptions: [propsOptions],
      slots,
      attrs,
      emit: emit2,
      render,
      renderCache,
      props,
      data,
      setupState,
      ctx,
      inheritAttrs
    } = instance;
    const prev = setCurrentRenderingInstance(instance);
    let result;
    let fallthroughAttrs;
    try {
      if (vnode.shapeFlag & 4) {
        const proxyToUse = withProxy || proxy;
        const thisProxy = false ? new Proxy(proxyToUse, {
          get(target, key, receiver) {
            warn$1(
              `Property '${String(
                key
              )}' was accessed via 'this'. Avoid using 'this' in templates.`
            );
            return Reflect.get(target, key, receiver);
          }
        }) : proxyToUse;
        result = normalizeVNode(
          render.call(
            thisProxy,
            proxyToUse,
            renderCache,
            false ? /* @__PURE__ */ shallowReadonly(props) : props,
            setupState,
            data,
            ctx
          )
        );
        fallthroughAttrs = attrs;
      } else {
        const render2 = Component;
        if (false) ;
        result = normalizeVNode(
          render2.length > 1 ? render2(
            false ? /* @__PURE__ */ shallowReadonly(props) : props,
            false ? {
              get attrs() {
                markAttrsAccessed();
                return /* @__PURE__ */ shallowReadonly(attrs);
              },
              slots,
              emit: emit2
            } : { attrs, slots, emit: emit2 }
          ) : render2(
            false ? /* @__PURE__ */ shallowReadonly(props) : props,
            null
          )
        );
        fallthroughAttrs = Component.props ? attrs : getFunctionalFallthrough(attrs);
      }
    } catch (err) {
      blockStack.length = 0;
      handleError(err, instance, 1);
      result = createVNode(Comment);
    }
    let root = result;
    if (fallthroughAttrs && inheritAttrs !== false) {
      const keys = Object.keys(fallthroughAttrs);
      const { shapeFlag } = root;
      if (keys.length) {
        if (shapeFlag & (1 | 6)) {
          if (propsOptions && keys.some(isModelListener)) {
            fallthroughAttrs = filterModelListeners(
              fallthroughAttrs,
              propsOptions
            );
          }
          root = cloneVNode(root, fallthroughAttrs, false, true);
        }
      }
    }
    if (vnode.dirs) {
      root = cloneVNode(root, null, false, true);
      root.dirs = root.dirs ? root.dirs.concat(vnode.dirs) : vnode.dirs;
    }
    if (vnode.transition) {
      setTransitionHooks(root, vnode.transition);
    }
    {
      result = root;
    }
    setCurrentRenderingInstance(prev);
    return result;
  }
  const getFunctionalFallthrough = (attrs) => {
    let res;
    for (const key in attrs) {
      if (key === "class" || key === "style" || isOn(key)) {
        (res || (res = {}))[key] = attrs[key];
      }
    }
    return res;
  };
  const filterModelListeners = (attrs, props) => {
    const res = {};
    for (const key in attrs) {
      if (!isModelListener(key) || !(key.slice(9) in props)) {
        res[key] = attrs[key];
      }
    }
    return res;
  };
  function shouldUpdateComponent(prevVNode, nextVNode, optimized) {
    const { props: prevProps, children: prevChildren, component } = prevVNode;
    const { props: nextProps, children: nextChildren, patchFlag } = nextVNode;
    const emits = component.emitsOptions;
    if (nextVNode.dirs || nextVNode.transition) {
      return true;
    }
    if (optimized && patchFlag >= 0) {
      if (patchFlag & 1024) {
        return true;
      }
      if (patchFlag & 16) {
        if (!prevProps) {
          return !!nextProps;
        }
        return hasPropsChanged(prevProps, nextProps, emits);
      } else if (patchFlag & 8) {
        const dynamicProps = nextVNode.dynamicProps;
        for (let i = 0; i < dynamicProps.length; i++) {
          const key = dynamicProps[i];
          if (hasPropValueChanged(nextProps, prevProps, key) && !isEmitListener(emits, key)) {
            return true;
          }
        }
      }
    } else {
      if (prevChildren || nextChildren) {
        if (!nextChildren || !nextChildren.$stable) {
          return true;
        }
      }
      if (prevProps === nextProps) {
        return false;
      }
      if (!prevProps) {
        return !!nextProps;
      }
      if (!nextProps) {
        return true;
      }
      return hasPropsChanged(prevProps, nextProps, emits);
    }
    return false;
  }
  function hasPropsChanged(prevProps, nextProps, emitsOptions) {
    const nextKeys = Object.keys(nextProps);
    if (nextKeys.length !== Object.keys(prevProps).length) {
      return true;
    }
    for (let i = 0; i < nextKeys.length; i++) {
      const key = nextKeys[i];
      if (hasPropValueChanged(nextProps, prevProps, key) && !isEmitListener(emitsOptions, key)) {
        return true;
      }
    }
    return false;
  }
  function hasPropValueChanged(nextProps, prevProps, key) {
    const nextProp = nextProps[key];
    const prevProp = prevProps[key];
    if (key === "style" && isObject(nextProp) && isObject(prevProp)) {
      return !looseEqual(nextProp, prevProp);
    }
    return nextProp !== prevProp;
  }
  function updateHOCHostEl({ vnode, parent, suspense }, el) {
    while (parent) {
      const root = parent.subTree;
      if (root.suspense && root.suspense.activeBranch === vnode) {
        root.suspense.vnode.el = root.el = el;
        vnode = root;
      }
      if (root === vnode) {
        (vnode = parent.vnode).el = el;
        parent = parent.parent;
      } else {
        break;
      }
    }
    if (suspense && suspense.activeBranch === vnode) {
      suspense.vnode.el = el;
    }
  }
  const internalObjectProto = {};
  const createInternalObject = () => Object.create(internalObjectProto);
  const isInternalObject = (obj) => Object.getPrototypeOf(obj) === internalObjectProto;
  function initProps(instance, rawProps, isStateful, isSSR = false) {
    const props = {};
    const attrs = createInternalObject();
    instance.propsDefaults = /* @__PURE__ */ Object.create(null);
    setFullProps(instance, rawProps, props, attrs);
    for (const key in instance.propsOptions[0]) {
      if (!(key in props)) {
        props[key] = void 0;
      }
    }
    if (isStateful) {
      instance.props = isSSR ? props : /* @__PURE__ */ shallowReactive(props);
    } else {
      if (!instance.type.props) {
        instance.props = attrs;
      } else {
        instance.props = props;
      }
    }
    instance.attrs = attrs;
  }
  function updateProps(instance, rawProps, rawPrevProps, optimized) {
    const {
      props,
      attrs,
      vnode: { patchFlag }
    } = instance;
    const rawCurrentProps = /* @__PURE__ */ toRaw(props);
    const [options] = instance.propsOptions;
    let hasAttrsChanged = false;
    if (
      // always force full diff in dev
      // - #1942 if hmr is enabled with sfc component
      // - vite#872 non-sfc component used by sfc component
      (optimized || patchFlag > 0) && !(patchFlag & 16)
    ) {
      if (patchFlag & 8) {
        const propsToUpdate = instance.vnode.dynamicProps;
        for (let i = 0; i < propsToUpdate.length; i++) {
          let key = propsToUpdate[i];
          if (isEmitListener(instance.emitsOptions, key)) {
            continue;
          }
          const value = rawProps[key];
          if (options) {
            if (hasOwn(attrs, key)) {
              if (value !== attrs[key]) {
                attrs[key] = value;
                hasAttrsChanged = true;
              }
            } else {
              const camelizedKey = camelize(key);
              props[camelizedKey] = resolvePropValue(
                options,
                rawCurrentProps,
                camelizedKey,
                value,
                instance,
                false
              );
            }
          } else {
            if (value !== attrs[key]) {
              attrs[key] = value;
              hasAttrsChanged = true;
            }
          }
        }
      }
    } else {
      if (setFullProps(instance, rawProps, props, attrs)) {
        hasAttrsChanged = true;
      }
      let kebabKey;
      for (const key in rawCurrentProps) {
        if (!rawProps || // for camelCase
        !hasOwn(rawProps, key) && // it's possible the original props was passed in as kebab-case
        // and converted to camelCase (#955)
        ((kebabKey = hyphenate(key)) === key || !hasOwn(rawProps, kebabKey))) {
          if (options) {
            if (rawPrevProps && // for camelCase
            (rawPrevProps[key] !== void 0 || // for kebab-case
            rawPrevProps[kebabKey] !== void 0)) {
              props[key] = resolvePropValue(
                options,
                rawCurrentProps,
                key,
                void 0,
                instance,
                true
              );
            }
          } else {
            delete props[key];
          }
        }
      }
      if (attrs !== rawCurrentProps) {
        for (const key in attrs) {
          if (!rawProps || !hasOwn(rawProps, key) && true) {
            delete attrs[key];
            hasAttrsChanged = true;
          }
        }
      }
    }
    if (hasAttrsChanged) {
      trigger(instance.attrs, "set", "");
    }
  }
  function setFullProps(instance, rawProps, props, attrs) {
    const [options, needCastKeys] = instance.propsOptions;
    let hasAttrsChanged = false;
    let rawCastValues;
    if (rawProps) {
      for (let key in rawProps) {
        if (isReservedProp(key)) {
          continue;
        }
        const value = rawProps[key];
        let camelKey;
        if (options && hasOwn(options, camelKey = camelize(key))) {
          if (!needCastKeys || !needCastKeys.includes(camelKey)) {
            props[camelKey] = value;
          } else {
            (rawCastValues || (rawCastValues = {}))[camelKey] = value;
          }
        } else if (!isEmitListener(instance.emitsOptions, key)) {
          if (!(key in attrs) || value !== attrs[key]) {
            attrs[key] = value;
            hasAttrsChanged = true;
          }
        }
      }
    }
    if (needCastKeys) {
      const rawCurrentProps = /* @__PURE__ */ toRaw(props);
      const castValues = rawCastValues || EMPTY_OBJ;
      for (let i = 0; i < needCastKeys.length; i++) {
        const key = needCastKeys[i];
        props[key] = resolvePropValue(
          options,
          rawCurrentProps,
          key,
          castValues[key],
          instance,
          !hasOwn(castValues, key)
        );
      }
    }
    return hasAttrsChanged;
  }
  function resolvePropValue(options, props, key, value, instance, isAbsent) {
    const opt = options[key];
    if (opt != null) {
      const hasDefault = hasOwn(opt, "default");
      if (hasDefault && value === void 0) {
        const defaultValue = opt.default;
        if (opt.type !== Function && !opt.skipFactory && isFunction(defaultValue)) {
          const { propsDefaults } = instance;
          if (key in propsDefaults) {
            value = propsDefaults[key];
          } else {
            const reset = setCurrentInstance(instance);
            value = propsDefaults[key] = defaultValue.call(
              null,
              props
            );
            reset();
          }
        } else {
          value = defaultValue;
        }
        if (instance.ce) {
          instance.ce._setProp(key, value);
        }
      }
      if (opt[
        0
        /* shouldCast */
      ]) {
        if (isAbsent && !hasDefault) {
          value = false;
        } else if (opt[
          1
          /* shouldCastTrue */
        ] && (value === "" || value === hyphenate(key))) {
          value = true;
        }
      }
    }
    return value;
  }
  const mixinPropsCache = /* @__PURE__ */ new WeakMap();
  function normalizePropsOptions(comp, appContext, asMixin = false) {
    const cache = asMixin ? mixinPropsCache : appContext.propsCache;
    const cached = cache.get(comp);
    if (cached) {
      return cached;
    }
    const raw = comp.props;
    const normalized = {};
    const needCastKeys = [];
    let hasExtends = false;
    if (!isFunction(comp)) {
      const extendProps = (raw2) => {
        hasExtends = true;
        const [props, keys] = normalizePropsOptions(raw2, appContext, true);
        extend(normalized, props);
        if (keys) needCastKeys.push(...keys);
      };
      if (!asMixin && appContext.mixins.length) {
        appContext.mixins.forEach(extendProps);
      }
      if (comp.extends) {
        extendProps(comp.extends);
      }
      if (comp.mixins) {
        comp.mixins.forEach(extendProps);
      }
    }
    if (!raw && !hasExtends) {
      if (isObject(comp)) {
        cache.set(comp, EMPTY_ARR);
      }
      return EMPTY_ARR;
    }
    if (isArray(raw)) {
      for (let i = 0; i < raw.length; i++) {
        const normalizedKey = camelize(raw[i]);
        if (validatePropName(normalizedKey)) {
          normalized[normalizedKey] = EMPTY_OBJ;
        }
      }
    } else if (raw) {
      for (const key in raw) {
        const normalizedKey = camelize(key);
        if (validatePropName(normalizedKey)) {
          const opt = raw[key];
          const prop = normalized[normalizedKey] = isArray(opt) || isFunction(opt) ? { type: opt } : extend({}, opt);
          const propType = prop.type;
          let shouldCast = false;
          let shouldCastTrue = true;
          if (isArray(propType)) {
            for (let index = 0; index < propType.length; ++index) {
              const type = propType[index];
              const typeName = isFunction(type) && type.name;
              if (typeName === "Boolean") {
                shouldCast = true;
                break;
              } else if (typeName === "String") {
                shouldCastTrue = false;
              }
            }
          } else {
            shouldCast = isFunction(propType) && propType.name === "Boolean";
          }
          prop[
            0
            /* shouldCast */
          ] = shouldCast;
          prop[
            1
            /* shouldCastTrue */
          ] = shouldCastTrue;
          if (shouldCast || hasOwn(prop, "default")) {
            needCastKeys.push(normalizedKey);
          }
        }
      }
    }
    const res = [normalized, needCastKeys];
    if (isObject(comp)) {
      cache.set(comp, res);
    }
    return res;
  }
  function validatePropName(key) {
    if (key[0] !== "$" && !isReservedProp(key)) {
      return true;
    }
    return false;
  }
  const isInternalKey = (key) => key === "_" || key === "_ctx" || key === "$stable";
  const normalizeSlotValue = (value) => isArray(value) ? value.map(normalizeVNode) : [normalizeVNode(value)];
  const normalizeSlot = (key, rawSlot, ctx) => {
    if (rawSlot._n) {
      return rawSlot;
    }
    const normalized = withCtx((...args) => {
      if (false) ;
      return normalizeSlotValue(rawSlot(...args));
    }, ctx);
    normalized._c = false;
    return normalized;
  };
  const normalizeObjectSlots = (rawSlots, slots, instance) => {
    const ctx = rawSlots._ctx;
    for (const key in rawSlots) {
      if (isInternalKey(key)) continue;
      const value = rawSlots[key];
      if (isFunction(value)) {
        slots[key] = normalizeSlot(key, value, ctx);
      } else if (value != null) {
        const normalized = normalizeSlotValue(value);
        slots[key] = () => normalized;
      }
    }
  };
  const normalizeVNodeSlots = (instance, children) => {
    const normalized = normalizeSlotValue(children);
    instance.slots.default = () => normalized;
  };
  const assignSlots = (slots, children, optimized) => {
    for (const key in children) {
      if (optimized || !isInternalKey(key)) {
        slots[key] = children[key];
      }
    }
  };
  const initSlots = (instance, children, optimized) => {
    const slots = instance.slots = createInternalObject();
    if (instance.vnode.shapeFlag & 32) {
      const type = children._;
      if (type) {
        assignSlots(slots, children, optimized);
        if (optimized) {
          def(slots, "_", type, true);
        }
      } else {
        normalizeObjectSlots(children, slots);
      }
    } else if (children) {
      normalizeVNodeSlots(instance, children);
    }
  };
  const updateSlots = (instance, children, optimized) => {
    const { vnode, slots } = instance;
    let needDeletionCheck = true;
    let deletionComparisonTarget = EMPTY_OBJ;
    if (vnode.shapeFlag & 32) {
      const type = children._;
      if (type) {
        if (optimized && type === 1) {
          needDeletionCheck = false;
        } else {
          assignSlots(slots, children, optimized);
        }
      } else {
        needDeletionCheck = !children.$stable;
        normalizeObjectSlots(children, slots);
      }
      deletionComparisonTarget = children;
    } else if (children) {
      normalizeVNodeSlots(instance, children);
      deletionComparisonTarget = { default: 1 };
    }
    if (needDeletionCheck) {
      for (const key in slots) {
        if (!isInternalKey(key) && deletionComparisonTarget[key] == null) {
          delete slots[key];
        }
      }
    }
  };
  const queuePostRenderEffect = queueEffectWithSuspense;
  function createRenderer(options) {
    return baseCreateRenderer(options);
  }
  function baseCreateRenderer(options, createHydrationFns) {
    const target = getGlobalThis();
    target.__VUE__ = true;
    const {
      insert: hostInsert,
      remove: hostRemove,
      patchProp: hostPatchProp,
      createElement: hostCreateElement,
      createText: hostCreateText,
      createComment: hostCreateComment,
      setText: hostSetText,
      setElementText: hostSetElementText,
      parentNode: hostParentNode,
      nextSibling: hostNextSibling,
      setScopeId: hostSetScopeId = NOOP,
      insertStaticContent: hostInsertStaticContent
    } = options;
    const patch = (n1, n2, container, anchor = null, parentComponent = null, parentSuspense = null, namespace = void 0, slotScopeIds = null, optimized = !!n2.dynamicChildren) => {
      if (n1 === n2) {
        return;
      }
      if (n1 && !isSameVNodeType(n1, n2)) {
        anchor = getNextHostNode(n1);
        unmount2(n1, parentComponent, parentSuspense, true);
        n1 = null;
      }
      if (n2.patchFlag === -2) {
        optimized = false;
        n2.dynamicChildren = null;
      }
      const { type, ref: ref3, shapeFlag } = n2;
      switch (type) {
        case Text:
          processText(n1, n2, container, anchor);
          break;
        case Comment:
          processCommentNode(n1, n2, container, anchor);
          break;
        case Static:
          if (n1 == null) {
            mountStaticNode(n2, container, anchor, namespace);
          }
          break;
        case Fragment:
          processFragment(
            n1,
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
          break;
        default:
          if (shapeFlag & 1) {
            processElement(
              n1,
              n2,
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized
            );
          } else if (shapeFlag & 6) {
            processComponent(
              n1,
              n2,
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized
            );
          } else if (shapeFlag & 64) {
            type.process(
              n1,
              n2,
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized,
              internals
            );
          } else if (shapeFlag & 128) {
            type.process(
              n1,
              n2,
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized,
              internals
            );
          } else ;
      }
      if (ref3 != null && parentComponent) {
        setRef(ref3, n1 && n1.ref, parentSuspense, n2 || n1, !n2);
      } else if (ref3 == null && n1 && n1.ref != null) {
        setRef(n1.ref, null, parentSuspense, n1, true);
      }
    };
    const processText = (n1, n2, container, anchor) => {
      if (n1 == null) {
        hostInsert(
          n2.el = hostCreateText(n2.children),
          container,
          anchor
        );
      } else {
        const el = n2.el = n1.el;
        if (n2.children !== n1.children) {
          hostSetText(el, n2.children);
        }
      }
    };
    const processCommentNode = (n1, n2, container, anchor) => {
      if (n1 == null) {
        hostInsert(
          n2.el = hostCreateComment(n2.children || ""),
          container,
          anchor
        );
      } else {
        n2.el = n1.el;
      }
    };
    const mountStaticNode = (n2, container, anchor, namespace) => {
      [n2.el, n2.anchor] = hostInsertStaticContent(
        n2.children,
        container,
        anchor,
        namespace,
        n2.el,
        n2.anchor
      );
    };
    const moveStaticNode = ({ el, anchor }, container, nextSibling) => {
      let next;
      while (el && el !== anchor) {
        next = hostNextSibling(el);
        hostInsert(el, container, nextSibling);
        el = next;
      }
      hostInsert(anchor, container, nextSibling);
    };
    const removeStaticNode = ({ el, anchor }) => {
      let next;
      while (el && el !== anchor) {
        next = hostNextSibling(el);
        hostRemove(el);
        el = next;
      }
      hostRemove(anchor);
    };
    const processElement = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
      if (n2.type === "svg") {
        namespace = "svg";
      } else if (n2.type === "math") {
        namespace = "mathml";
      }
      if (n1 == null) {
        mountElement(
          n2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      } else {
        const customElement = n1.el && n1.el._isVueCE ? n1.el : null;
        try {
          if (customElement) {
            customElement._beginPatch();
          }
          patchElement(
            n1,
            n2,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } finally {
          if (customElement) {
            customElement._endPatch();
          }
        }
      }
    };
    const mountElement = (vnode, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
      let el;
      let vnodeHook;
      const { props, shapeFlag, transition, dirs } = vnode;
      el = vnode.el = hostCreateElement(
        vnode.type,
        namespace,
        props && props.is,
        props
      );
      if (shapeFlag & 8) {
        hostSetElementText(el, vnode.children);
      } else if (shapeFlag & 16) {
        mountChildren(
          vnode.children,
          el,
          null,
          parentComponent,
          parentSuspense,
          resolveChildrenNamespace(vnode, namespace),
          slotScopeIds,
          optimized
        );
      }
      if (dirs) {
        invokeDirectiveHook(vnode, null, parentComponent, "created");
      }
      setScopeId(el, vnode, vnode.scopeId, slotScopeIds, parentComponent);
      if (props) {
        for (const key in props) {
          if (key !== "value" && !isReservedProp(key)) {
            hostPatchProp(el, key, null, props[key], namespace, parentComponent);
          }
        }
        if ("value" in props) {
          hostPatchProp(el, "value", null, props.value, namespace);
        }
        if (vnodeHook = props.onVnodeBeforeMount) {
          invokeVNodeHook(vnodeHook, parentComponent, vnode);
        }
      }
      if (dirs) {
        invokeDirectiveHook(vnode, null, parentComponent, "beforeMount");
      }
      const needCallTransitionHooks = needTransition(parentSuspense, transition);
      if (needCallTransitionHooks) {
        transition.beforeEnter(el);
      }
      hostInsert(el, container, anchor);
      if ((vnodeHook = props && props.onVnodeMounted) || needCallTransitionHooks || dirs) {
        queuePostRenderEffect(() => {
          try {
            vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
            needCallTransitionHooks && transition.enter(el);
            dirs && invokeDirectiveHook(vnode, null, parentComponent, "mounted");
          } finally {
          }
        }, parentSuspense);
      }
    };
    const setScopeId = (el, vnode, scopeId, slotScopeIds, parentComponent) => {
      if (scopeId) {
        hostSetScopeId(el, scopeId);
      }
      if (slotScopeIds) {
        for (let i = 0; i < slotScopeIds.length; i++) {
          hostSetScopeId(el, slotScopeIds[i]);
        }
      }
      if (parentComponent) {
        let subTree = parentComponent.subTree;
        if (vnode === subTree || isSuspense(subTree.type) && (subTree.ssContent === vnode || subTree.ssFallback === vnode)) {
          const parentVNode = parentComponent.vnode;
          setScopeId(
            el,
            parentVNode,
            parentVNode.scopeId,
            parentVNode.slotScopeIds,
            parentComponent.parent
          );
        }
      }
    };
    const mountChildren = (children, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized, start = 0) => {
      for (let i = start; i < children.length; i++) {
        const child = children[i] = optimized ? cloneIfMounted(children[i]) : normalizeVNode(children[i]);
        patch(
          null,
          child,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      }
    };
    const patchElement = (n1, n2, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
      const el = n2.el = n1.el;
      let { patchFlag, dynamicChildren, dirs } = n2;
      patchFlag |= n1.patchFlag & 16;
      const oldProps = n1.props || EMPTY_OBJ;
      const newProps = n2.props || EMPTY_OBJ;
      let vnodeHook;
      parentComponent && toggleRecurse(parentComponent, false);
      if (vnodeHook = newProps.onVnodeBeforeUpdate) {
        invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
      }
      if (dirs) {
        invokeDirectiveHook(n2, n1, parentComponent, "beforeUpdate");
      }
      parentComponent && toggleRecurse(parentComponent, true);
      if (oldProps.innerHTML && newProps.innerHTML == null || oldProps.textContent && newProps.textContent == null) {
        hostSetElementText(el, "");
      }
      if (dynamicChildren) {
        patchBlockChildren(
          n1.dynamicChildren,
          dynamicChildren,
          el,
          parentComponent,
          parentSuspense,
          resolveChildrenNamespace(n2, namespace),
          slotScopeIds
        );
      } else if (!optimized) {
        patchChildren(
          n1,
          n2,
          el,
          null,
          parentComponent,
          parentSuspense,
          resolveChildrenNamespace(n2, namespace),
          slotScopeIds,
          false
        );
      }
      if (patchFlag > 0) {
        if (patchFlag & 16) {
          patchProps(el, oldProps, newProps, parentComponent, namespace);
        } else {
          if (patchFlag & 2) {
            if (oldProps.class !== newProps.class) {
              hostPatchProp(el, "class", null, newProps.class, namespace);
            }
          }
          if (patchFlag & 4) {
            hostPatchProp(el, "style", oldProps.style, newProps.style, namespace);
          }
          if (patchFlag & 8) {
            const propsToUpdate = n2.dynamicProps;
            for (let i = 0; i < propsToUpdate.length; i++) {
              const key = propsToUpdate[i];
              const prev = oldProps[key];
              const next = newProps[key];
              if (next !== prev || key === "value") {
                hostPatchProp(el, key, prev, next, namespace, parentComponent);
              }
            }
          }
        }
        if (patchFlag & 1) {
          if (n1.children !== n2.children) {
            hostSetElementText(el, n2.children);
          }
        }
      } else if (!optimized && dynamicChildren == null) {
        patchProps(el, oldProps, newProps, parentComponent, namespace);
      }
      if ((vnodeHook = newProps.onVnodeUpdated) || dirs) {
        queuePostRenderEffect(() => {
          vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, n2, n1);
          dirs && invokeDirectiveHook(n2, n1, parentComponent, "updated");
        }, parentSuspense);
      }
    };
    const patchBlockChildren = (oldChildren, newChildren, fallbackContainer, parentComponent, parentSuspense, namespace, slotScopeIds) => {
      for (let i = 0; i < newChildren.length; i++) {
        const oldVNode = oldChildren[i];
        const newVNode = newChildren[i];
        const container = (
          // oldVNode may be an errored async setup() component inside Suspense
          // which will not have a mounted element
          oldVNode.el && // - In the case of a Fragment, we need to provide the actual parent
          // of the Fragment itself so it can move its children.
          (oldVNode.type === Fragment || // - In the case of different nodes, there is going to be a replacement
          // which also requires the correct parent container
          !isSameVNodeType(oldVNode, newVNode) || // - In the case of a component, it could contain anything.
          oldVNode.shapeFlag & (6 | 64 | 128)) ? hostParentNode(oldVNode.el) : (
            // In other cases, the parent container is not actually used so we
            // just pass the block element here to avoid a DOM parentNode call.
            fallbackContainer
          )
        );
        patch(
          oldVNode,
          newVNode,
          container,
          null,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          true
        );
      }
    };
    const patchProps = (el, oldProps, newProps, parentComponent, namespace) => {
      if (oldProps !== newProps) {
        if (oldProps !== EMPTY_OBJ) {
          for (const key in oldProps) {
            if (!isReservedProp(key) && !(key in newProps)) {
              hostPatchProp(
                el,
                key,
                oldProps[key],
                null,
                namespace,
                parentComponent
              );
            }
          }
        }
        for (const key in newProps) {
          if (isReservedProp(key)) continue;
          const next = newProps[key];
          const prev = oldProps[key];
          if (next !== prev && key !== "value") {
            hostPatchProp(el, key, prev, next, namespace, parentComponent);
          }
        }
        if ("value" in newProps) {
          hostPatchProp(el, "value", oldProps.value, newProps.value, namespace);
        }
      }
    };
    const processFragment = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
      const fragmentStartAnchor = n2.el = n1 ? n1.el : hostCreateText("");
      const fragmentEndAnchor = n2.anchor = n1 ? n1.anchor : hostCreateText("");
      let { patchFlag, dynamicChildren, slotScopeIds: fragmentSlotScopeIds } = n2;
      if (fragmentSlotScopeIds) {
        slotScopeIds = slotScopeIds ? slotScopeIds.concat(fragmentSlotScopeIds) : fragmentSlotScopeIds;
      }
      if (n1 == null) {
        hostInsert(fragmentStartAnchor, container, anchor);
        hostInsert(fragmentEndAnchor, container, anchor);
        mountChildren(
          // #10007
          // such fragment like `<></>` will be compiled into
          // a fragment which doesn't have a children.
          // In this case fallback to an empty array
          n2.children || [],
          container,
          fragmentEndAnchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      } else {
        if (patchFlag > 0 && patchFlag & 64 && dynamicChildren && // #2715 the previous fragment could've been a BAILed one as a result
        // of renderSlot() with no valid children
        n1.dynamicChildren && n1.dynamicChildren.length === dynamicChildren.length) {
          patchBlockChildren(
            n1.dynamicChildren,
            dynamicChildren,
            container,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds
          );
          if (
            // #2080 if the stable fragment has a key, it's a <template v-for> that may
            //  get moved around. Make sure all root level vnodes inherit el.
            // #2134 or if it's a component root, it may also get moved around
            // as the component is being moved.
            n2.key != null || parentComponent && n2 === parentComponent.subTree
          ) {
            traverseStaticChildren(
              n1,
              n2,
              true
              /* shallow */
            );
          }
        } else {
          patchChildren(
            n1,
            n2,
            container,
            fragmentEndAnchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        }
      }
    };
    const processComponent = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
      n2.slotScopeIds = slotScopeIds;
      if (n1 == null) {
        if (n2.shapeFlag & 512) {
          parentComponent.ctx.activate(
            n2,
            container,
            anchor,
            namespace,
            optimized
          );
        } else {
          mountComponent(
            n2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            optimized
          );
        }
      } else {
        updateComponent(n1, n2, optimized);
      }
    };
    const mountComponent = (initialVNode, container, anchor, parentComponent, parentSuspense, namespace, optimized) => {
      const instance = initialVNode.component = createComponentInstance(
        initialVNode,
        parentComponent,
        parentSuspense
      );
      if (isKeepAlive(initialVNode)) {
        instance.ctx.renderer = internals;
      }
      {
        setupComponent(instance, false, optimized);
      }
      if (instance.asyncDep) {
        parentSuspense && parentSuspense.registerDep(instance, setupRenderEffect, optimized);
        if (!initialVNode.el) {
          const placeholder = instance.subTree = createVNode(Comment);
          processCommentNode(null, placeholder, container, anchor);
          initialVNode.placeholder = placeholder.el;
        }
      } else {
        setupRenderEffect(
          instance,
          initialVNode,
          container,
          anchor,
          parentSuspense,
          namespace,
          optimized
        );
      }
    };
    const updateComponent = (n1, n2, optimized) => {
      const instance = n2.component = n1.component;
      if (shouldUpdateComponent(n1, n2, optimized)) {
        if (instance.asyncDep && !instance.asyncResolved) {
          updateComponentPreRender(instance, n2, optimized);
          return;
        } else {
          instance.next = n2;
          instance.update();
        }
      } else {
        n2.el = n1.el;
        instance.vnode = n2;
      }
    };
    const setupRenderEffect = (instance, initialVNode, container, anchor, parentSuspense, namespace, optimized) => {
      const componentUpdateFn = () => {
        if (!instance.isMounted) {
          let vnodeHook;
          const { el, props } = initialVNode;
          const { bm, m, parent, root, type } = instance;
          const isAsyncWrapperVNode = isAsyncWrapper(initialVNode);
          toggleRecurse(instance, false);
          if (bm) {
            invokeArrayFns(bm);
          }
          if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeBeforeMount)) {
            invokeVNodeHook(vnodeHook, parent, initialVNode);
          }
          toggleRecurse(instance, true);
          {
            if (root.ce && root.ce._hasShadowRoot()) {
              root.ce._injectChildStyle(
                type,
                instance.parent ? instance.parent.type : void 0
              );
            }
            const subTree = instance.subTree = renderComponentRoot(instance);
            patch(
              null,
              subTree,
              container,
              anchor,
              instance,
              parentSuspense,
              namespace
            );
            initialVNode.el = subTree.el;
          }
          if (m) {
            queuePostRenderEffect(m, parentSuspense);
          }
          if (!isAsyncWrapperVNode && (vnodeHook = props && props.onVnodeMounted)) {
            const scopedInitialVNode = initialVNode;
            queuePostRenderEffect(
              () => invokeVNodeHook(vnodeHook, parent, scopedInitialVNode),
              parentSuspense
            );
          }
          if (initialVNode.shapeFlag & 256 || parent && isAsyncWrapper(parent.vnode) && parent.vnode.shapeFlag & 256) {
            instance.a && queuePostRenderEffect(instance.a, parentSuspense);
          }
          instance.isMounted = true;
          initialVNode = container = anchor = null;
        } else {
          let { next, bu, u, parent, vnode } = instance;
          {
            const nonHydratedAsyncRoot = locateNonHydratedAsyncRoot(instance);
            if (nonHydratedAsyncRoot) {
              if (next) {
                next.el = vnode.el;
                updateComponentPreRender(instance, next, optimized);
              }
              nonHydratedAsyncRoot.asyncDep.then(() => {
                queuePostRenderEffect(() => {
                  if (!instance.isUnmounted) update();
                }, parentSuspense);
              });
              return;
            }
          }
          let originNext = next;
          let vnodeHook;
          toggleRecurse(instance, false);
          if (next) {
            next.el = vnode.el;
            updateComponentPreRender(instance, next, optimized);
          } else {
            next = vnode;
          }
          if (bu) {
            invokeArrayFns(bu);
          }
          if (vnodeHook = next.props && next.props.onVnodeBeforeUpdate) {
            invokeVNodeHook(vnodeHook, parent, next, vnode);
          }
          toggleRecurse(instance, true);
          const nextTree = renderComponentRoot(instance);
          const prevTree = instance.subTree;
          instance.subTree = nextTree;
          patch(
            prevTree,
            nextTree,
            // parent may have changed if it's in a teleport
            hostParentNode(prevTree.el),
            // anchor may have changed if it's in a fragment
            getNextHostNode(prevTree),
            instance,
            parentSuspense,
            namespace
          );
          next.el = nextTree.el;
          if (originNext === null) {
            updateHOCHostEl(instance, nextTree.el);
          }
          if (u) {
            queuePostRenderEffect(u, parentSuspense);
          }
          if (vnodeHook = next.props && next.props.onVnodeUpdated) {
            queuePostRenderEffect(
              () => invokeVNodeHook(vnodeHook, parent, next, vnode),
              parentSuspense
            );
          }
        }
      };
      instance.scope.on();
      const effect2 = instance.effect = new ReactiveEffect(componentUpdateFn);
      instance.scope.off();
      const update = instance.update = effect2.run.bind(effect2);
      const job = instance.job = effect2.runIfDirty.bind(effect2);
      job.i = instance;
      job.id = instance.uid;
      effect2.scheduler = () => queueJob(job);
      toggleRecurse(instance, true);
      update();
    };
    const updateComponentPreRender = (instance, nextVNode, optimized) => {
      nextVNode.component = instance;
      const prevProps = instance.vnode.props;
      instance.vnode = nextVNode;
      instance.next = null;
      updateProps(instance, nextVNode.props, prevProps, optimized);
      updateSlots(instance, nextVNode.children, optimized);
      pauseTracking();
      flushPreFlushCbs(instance);
      resetTracking();
    };
    const patchChildren = (n1, n2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized = false) => {
      const c1 = n1 && n1.children;
      const prevShapeFlag = n1 ? n1.shapeFlag : 0;
      const c2 = n2.children;
      const { patchFlag, shapeFlag } = n2;
      if (patchFlag > 0) {
        if (patchFlag & 128) {
          patchKeyedChildren(
            c1,
            c2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
          return;
        } else if (patchFlag & 256) {
          patchUnkeyedChildren(
            c1,
            c2,
            container,
            anchor,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
          return;
        }
      }
      if (shapeFlag & 8) {
        if (prevShapeFlag & 16) {
          unmountChildren(c1, parentComponent, parentSuspense);
        }
        if (c2 !== c1) {
          hostSetElementText(container, c2);
        }
      } else {
        if (prevShapeFlag & 16) {
          if (shapeFlag & 16) {
            patchKeyedChildren(
              c1,
              c2,
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized
            );
          } else {
            unmountChildren(c1, parentComponent, parentSuspense, true);
          }
        } else {
          if (prevShapeFlag & 8) {
            hostSetElementText(container, "");
          }
          if (shapeFlag & 16) {
            mountChildren(
              c2,
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized
            );
          }
        }
      }
    };
    const patchUnkeyedChildren = (c1, c2, container, anchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
      c1 = c1 || EMPTY_ARR;
      c2 = c2 || EMPTY_ARR;
      const oldLength = c1.length;
      const newLength = c2.length;
      const commonLength = Math.min(oldLength, newLength);
      let i;
      for (i = 0; i < commonLength; i++) {
        const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
        patch(
          c1[i],
          nextChild,
          container,
          null,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized
        );
      }
      if (oldLength > newLength) {
        unmountChildren(
          c1,
          parentComponent,
          parentSuspense,
          true,
          false,
          commonLength
        );
      } else {
        mountChildren(
          c2,
          container,
          anchor,
          parentComponent,
          parentSuspense,
          namespace,
          slotScopeIds,
          optimized,
          commonLength
        );
      }
    };
    const patchKeyedChildren = (c1, c2, container, parentAnchor, parentComponent, parentSuspense, namespace, slotScopeIds, optimized) => {
      let i = 0;
      const l2 = c2.length;
      let e1 = c1.length - 1;
      let e2 = l2 - 1;
      while (i <= e1 && i <= e2) {
        const n1 = c1[i];
        const n2 = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
        if (isSameVNodeType(n1, n2)) {
          patch(
            n1,
            n2,
            container,
            null,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else {
          break;
        }
        i++;
      }
      while (i <= e1 && i <= e2) {
        const n1 = c1[e1];
        const n2 = c2[e2] = optimized ? cloneIfMounted(c2[e2]) : normalizeVNode(c2[e2]);
        if (isSameVNodeType(n1, n2)) {
          patch(
            n1,
            n2,
            container,
            null,
            parentComponent,
            parentSuspense,
            namespace,
            slotScopeIds,
            optimized
          );
        } else {
          break;
        }
        e1--;
        e2--;
      }
      if (i > e1) {
        if (i <= e2) {
          const nextPos = e2 + 1;
          const anchor = nextPos < l2 ? c2[nextPos].el : parentAnchor;
          while (i <= e2) {
            patch(
              null,
              c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]),
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized
            );
            i++;
          }
        }
      } else if (i > e2) {
        while (i <= e1) {
          unmount2(c1[i], parentComponent, parentSuspense, true);
          i++;
        }
      } else {
        const s1 = i;
        const s2 = i;
        const keyToNewIndexMap = /* @__PURE__ */ new Map();
        for (i = s2; i <= e2; i++) {
          const nextChild = c2[i] = optimized ? cloneIfMounted(c2[i]) : normalizeVNode(c2[i]);
          if (nextChild.key != null) {
            keyToNewIndexMap.set(nextChild.key, i);
          }
        }
        let j;
        let patched = 0;
        const toBePatched = e2 - s2 + 1;
        let moved = false;
        let maxNewIndexSoFar = 0;
        const newIndexToOldIndexMap = new Array(toBePatched);
        for (i = 0; i < toBePatched; i++) newIndexToOldIndexMap[i] = 0;
        for (i = s1; i <= e1; i++) {
          const prevChild = c1[i];
          if (patched >= toBePatched) {
            unmount2(prevChild, parentComponent, parentSuspense, true);
            continue;
          }
          let newIndex;
          if (prevChild.key != null) {
            newIndex = keyToNewIndexMap.get(prevChild.key);
          } else {
            for (j = s2; j <= e2; j++) {
              if (newIndexToOldIndexMap[j - s2] === 0 && isSameVNodeType(prevChild, c2[j])) {
                newIndex = j;
                break;
              }
            }
          }
          if (newIndex === void 0) {
            unmount2(prevChild, parentComponent, parentSuspense, true);
          } else {
            newIndexToOldIndexMap[newIndex - s2] = i + 1;
            if (newIndex >= maxNewIndexSoFar) {
              maxNewIndexSoFar = newIndex;
            } else {
              moved = true;
            }
            patch(
              prevChild,
              c2[newIndex],
              container,
              null,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized
            );
            patched++;
          }
        }
        const increasingNewIndexSequence = moved ? getSequence(newIndexToOldIndexMap) : EMPTY_ARR;
        j = increasingNewIndexSequence.length - 1;
        for (i = toBePatched - 1; i >= 0; i--) {
          const nextIndex = s2 + i;
          const nextChild = c2[nextIndex];
          const anchorVNode = c2[nextIndex + 1];
          const anchor = nextIndex + 1 < l2 ? (
            // #13559, #14173 fallback to el placeholder for unresolved async component
            anchorVNode.el || resolveAsyncComponentPlaceholder(anchorVNode)
          ) : parentAnchor;
          if (newIndexToOldIndexMap[i] === 0) {
            patch(
              null,
              nextChild,
              container,
              anchor,
              parentComponent,
              parentSuspense,
              namespace,
              slotScopeIds,
              optimized
            );
          } else if (moved) {
            if (j < 0 || i !== increasingNewIndexSequence[j]) {
              move(nextChild, container, anchor, 2);
            } else {
              j--;
            }
          }
        }
      }
    };
    const move = (vnode, container, anchor, moveType, parentSuspense = null) => {
      const { el, type, transition, children, shapeFlag } = vnode;
      if (shapeFlag & 6) {
        move(vnode.component.subTree, container, anchor, moveType);
        return;
      }
      if (shapeFlag & 128) {
        vnode.suspense.move(container, anchor, moveType);
        return;
      }
      if (shapeFlag & 64) {
        type.move(vnode, container, anchor, internals);
        return;
      }
      if (type === Fragment) {
        hostInsert(el, container, anchor);
        for (let i = 0; i < children.length; i++) {
          move(children[i], container, anchor, moveType);
        }
        hostInsert(vnode.anchor, container, anchor);
        return;
      }
      if (type === Static) {
        moveStaticNode(vnode, container, anchor);
        return;
      }
      const needTransition2 = moveType !== 2 && shapeFlag & 1 && transition;
      if (needTransition2) {
        if (moveType === 0) {
          if (transition.persisted && !el[leaveCbKey]) {
            hostInsert(el, container, anchor);
          } else {
            transition.beforeEnter(el);
            hostInsert(el, container, anchor);
            queuePostRenderEffect(() => transition.enter(el), parentSuspense);
          }
        } else {
          const { leave, delayLeave, afterLeave } = transition;
          const remove22 = () => {
            if (vnode.ctx.isUnmounted) {
              hostRemove(el);
            } else {
              hostInsert(el, container, anchor);
            }
          };
          const performLeave = () => {
            const wasLeaving = el._isLeaving || !!el[leaveCbKey];
            if (el._isLeaving) {
              el[leaveCbKey](
                true
                /* cancelled */
              );
            }
            if (transition.persisted && !wasLeaving) {
              remove22();
            } else {
              leave(el, () => {
                remove22();
                afterLeave && afterLeave();
              });
            }
          };
          if (delayLeave) {
            delayLeave(el, remove22, performLeave);
          } else {
            performLeave();
          }
        }
      } else {
        hostInsert(el, container, anchor);
      }
    };
    const unmount2 = (vnode, parentComponent, parentSuspense, doRemove = false, optimized = false) => {
      const {
        type,
        props,
        ref: ref3,
        children,
        dynamicChildren,
        shapeFlag,
        patchFlag,
        dirs,
        cacheIndex,
        memo
      } = vnode;
      if (patchFlag === -2) {
        optimized = false;
      }
      if (ref3 != null) {
        pauseTracking();
        setRef(ref3, null, parentSuspense, vnode, true);
        resetTracking();
      }
      if (cacheIndex != null) {
        parentComponent.renderCache[cacheIndex] = void 0;
      }
      if (shapeFlag & 256) {
        parentComponent.ctx.deactivate(vnode);
        return;
      }
      const shouldInvokeDirs = shapeFlag & 1 && dirs;
      const shouldInvokeVnodeHook = !isAsyncWrapper(vnode);
      let vnodeHook;
      if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeBeforeUnmount)) {
        invokeVNodeHook(vnodeHook, parentComponent, vnode);
      }
      if (shapeFlag & 6) {
        unmountComponent(vnode.component, parentSuspense, doRemove);
      } else {
        if (shapeFlag & 128) {
          vnode.suspense.unmount(parentSuspense, doRemove);
          return;
        }
        if (shouldInvokeDirs) {
          invokeDirectiveHook(vnode, null, parentComponent, "beforeUnmount");
        }
        if (shapeFlag & 64) {
          vnode.type.remove(
            vnode,
            parentComponent,
            parentSuspense,
            internals,
            doRemove
          );
        } else if (dynamicChildren && // #5154
        // when v-once is used inside a block, setBlockTracking(-1) marks the
        // parent block with hasOnce: true
        // so that it doesn't take the fast path during unmount - otherwise
        // components nested in v-once are never unmounted.
        !dynamicChildren.hasOnce && // #1153: fast path should not be taken for non-stable (v-for) fragments
        (type !== Fragment || patchFlag > 0 && patchFlag & 64)) {
          unmountChildren(
            dynamicChildren,
            parentComponent,
            parentSuspense,
            false,
            true
          );
        } else if (type === Fragment && patchFlag & (128 | 256) || !optimized && shapeFlag & 16) {
          unmountChildren(children, parentComponent, parentSuspense);
        }
        if (doRemove) {
          remove2(vnode);
        }
      }
      const shouldInvalidateMemo = memo != null && cacheIndex == null;
      if (shouldInvokeVnodeHook && (vnodeHook = props && props.onVnodeUnmounted) || shouldInvokeDirs || shouldInvalidateMemo) {
        queuePostRenderEffect(() => {
          vnodeHook && invokeVNodeHook(vnodeHook, parentComponent, vnode);
          shouldInvokeDirs && invokeDirectiveHook(vnode, null, parentComponent, "unmounted");
          if (shouldInvalidateMemo) {
            vnode.el = null;
          }
        }, parentSuspense);
      }
    };
    const remove2 = (vnode) => {
      const { type, el, anchor, transition } = vnode;
      if (type === Fragment) {
        {
          removeFragment(el, anchor);
        }
        return;
      }
      if (type === Static) {
        removeStaticNode(vnode);
        return;
      }
      const performRemove = () => {
        hostRemove(el);
        if (transition && !transition.persisted && transition.afterLeave) {
          transition.afterLeave();
        }
      };
      if (vnode.shapeFlag & 1 && transition && !transition.persisted) {
        const { leave, delayLeave } = transition;
        const performLeave = () => leave(el, performRemove);
        if (delayLeave) {
          delayLeave(vnode.el, performRemove, performLeave);
        } else {
          performLeave();
        }
      } else {
        performRemove();
      }
    };
    const removeFragment = (cur, end) => {
      let next;
      while (cur !== end) {
        next = hostNextSibling(cur);
        hostRemove(cur);
        cur = next;
      }
      hostRemove(end);
    };
    const unmountComponent = (instance, parentSuspense, doRemove) => {
      const { bum, scope, job, subTree, um, m, a } = instance;
      invalidateMount(m);
      invalidateMount(a);
      if (bum) {
        invokeArrayFns(bum);
      }
      scope.stop();
      if (job) {
        job.flags |= 8;
        unmount2(subTree, instance, parentSuspense, doRemove);
      }
      if (um) {
        queuePostRenderEffect(um, parentSuspense);
      }
      queuePostRenderEffect(() => {
        instance.isUnmounted = true;
      }, parentSuspense);
    };
    const unmountChildren = (children, parentComponent, parentSuspense, doRemove = false, optimized = false, start = 0) => {
      for (let i = start; i < children.length; i++) {
        unmount2(children[i], parentComponent, parentSuspense, doRemove, optimized);
      }
    };
    const getNextHostNode = (vnode) => {
      if (vnode.shapeFlag & 6) {
        return getNextHostNode(vnode.component.subTree);
      }
      if (vnode.shapeFlag & 128) {
        return vnode.suspense.next();
      }
      const el = hostNextSibling(vnode.anchor || vnode.el);
      const teleportEnd = el && el[TeleportEndKey];
      return teleportEnd ? hostNextSibling(teleportEnd) : el;
    };
    let isFlushing = false;
    const render = (vnode, container, namespace) => {
      let instance;
      if (vnode == null) {
        if (container._vnode) {
          unmount2(container._vnode, null, null, true);
          instance = container._vnode.component;
        }
      } else {
        patch(
          container._vnode || null,
          vnode,
          container,
          null,
          null,
          null,
          namespace
        );
      }
      container._vnode = vnode;
      if (!isFlushing) {
        isFlushing = true;
        flushPreFlushCbs(instance);
        flushPostFlushCbs();
        isFlushing = false;
      }
    };
    const internals = {
      p: patch,
      um: unmount2,
      m: move,
      r: remove2,
      mt: mountComponent,
      mc: mountChildren,
      pc: patchChildren,
      pbc: patchBlockChildren,
      n: getNextHostNode,
      o: options
    };
    let hydrate;
    return {
      render,
      hydrate,
      createApp: createAppAPI(render)
    };
  }
  function resolveChildrenNamespace({ type, props }, currentNamespace) {
    return currentNamespace === "svg" && type === "foreignObject" || currentNamespace === "mathml" && type === "annotation-xml" && props && props.encoding && props.encoding.includes("html") ? void 0 : currentNamespace;
  }
  function toggleRecurse({ effect: effect2, job }, allowed) {
    if (allowed) {
      effect2.flags |= 32;
      job.flags |= 4;
    } else {
      effect2.flags &= -33;
      job.flags &= -5;
    }
  }
  function needTransition(parentSuspense, transition) {
    return (!parentSuspense || parentSuspense && !parentSuspense.pendingBranch) && transition && !transition.persisted;
  }
  function traverseStaticChildren(n1, n2, shallow = false) {
    const ch1 = n1.children;
    const ch2 = n2.children;
    if (isArray(ch1) && isArray(ch2)) {
      for (let i = 0; i < ch1.length; i++) {
        const c1 = ch1[i];
        let c2 = ch2[i];
        if (c2.shapeFlag & 1 && !c2.dynamicChildren) {
          if (c2.patchFlag <= 0 || c2.patchFlag === 32) {
            c2 = ch2[i] = cloneIfMounted(ch2[i]);
            c2.el = c1.el;
          }
          if (!shallow && c2.patchFlag !== -2)
            traverseStaticChildren(c1, c2);
        }
        if (c2.type === Text) {
          if (c2.patchFlag === -1) {
            c2 = ch2[i] = cloneIfMounted(c2);
          }
          c2.el = c1.el;
        }
        if (c2.type === Comment && !c2.el) {
          c2.el = c1.el;
        }
      }
    }
  }
  function getSequence(arr) {
    const p2 = arr.slice();
    const result = [0];
    let i, j, u, v, c;
    const len = arr.length;
    for (i = 0; i < len; i++) {
      const arrI = arr[i];
      if (arrI !== 0) {
        j = result[result.length - 1];
        if (arr[j] < arrI) {
          p2[i] = j;
          result.push(i);
          continue;
        }
        u = 0;
        v = result.length - 1;
        while (u < v) {
          c = u + v >> 1;
          if (arr[result[c]] < arrI) {
            u = c + 1;
          } else {
            v = c;
          }
        }
        if (arrI < arr[result[u]]) {
          if (u > 0) {
            p2[i] = result[u - 1];
          }
          result[u] = i;
        }
      }
    }
    u = result.length;
    v = result[u - 1];
    while (u-- > 0) {
      result[u] = v;
      v = p2[v];
    }
    return result;
  }
  function locateNonHydratedAsyncRoot(instance) {
    const subComponent = instance.subTree.component;
    if (subComponent) {
      if (subComponent.asyncDep && !subComponent.asyncResolved) {
        return subComponent;
      } else {
        return locateNonHydratedAsyncRoot(subComponent);
      }
    }
  }
  function invalidateMount(hooks) {
    if (hooks) {
      for (let i = 0; i < hooks.length; i++)
        hooks[i].flags |= 8;
    }
  }
  function resolveAsyncComponentPlaceholder(anchorVnode) {
    if (anchorVnode.placeholder) {
      return anchorVnode.placeholder;
    }
    const instance = anchorVnode.component;
    if (instance) {
      return resolveAsyncComponentPlaceholder(instance.subTree);
    }
    return null;
  }
  const isSuspense = (type) => type.__isSuspense;
  function queueEffectWithSuspense(fn, suspense) {
    if (suspense && suspense.pendingBranch) {
      if (isArray(fn)) {
        suspense.effects.push(...fn);
      } else {
        suspense.effects.push(fn);
      }
    } else {
      queuePostFlushCb(fn);
    }
  }
  const Fragment = /* @__PURE__ */ Symbol.for("v-fgt");
  const Text = /* @__PURE__ */ Symbol.for("v-txt");
  const Comment = /* @__PURE__ */ Symbol.for("v-cmt");
  const Static = /* @__PURE__ */ Symbol.for("v-stc");
  const blockStack = [];
  let currentBlock = null;
  function openBlock(disableTracking = false) {
    blockStack.push(currentBlock = disableTracking ? null : []);
  }
  function closeBlock() {
    blockStack.pop();
    currentBlock = blockStack[blockStack.length - 1] || null;
  }
  let isBlockTreeEnabled = 1;
  function setBlockTracking(value, inVOnce = false) {
    isBlockTreeEnabled += value;
    if (value < 0 && currentBlock && inVOnce) {
      currentBlock.hasOnce = true;
    }
  }
  function setupBlock(vnode) {
    vnode.dynamicChildren = isBlockTreeEnabled > 0 ? currentBlock || EMPTY_ARR : null;
    closeBlock();
    if (isBlockTreeEnabled > 0 && currentBlock) {
      currentBlock.push(vnode);
    }
    return vnode;
  }
  function createElementBlock(type, props, children, patchFlag, dynamicProps, shapeFlag) {
    return setupBlock(
      createBaseVNode(
        type,
        props,
        children,
        patchFlag,
        dynamicProps,
        shapeFlag,
        true
      )
    );
  }
  function createBlock(type, props, children, patchFlag, dynamicProps) {
    return setupBlock(
      createVNode(
        type,
        props,
        children,
        patchFlag,
        dynamicProps,
        true
      )
    );
  }
  function isVNode(value) {
    return value ? value.__v_isVNode === true : false;
  }
  function isSameVNodeType(n1, n2) {
    return n1.type === n2.type && n1.key === n2.key;
  }
  const normalizeKey = ({ key }) => key != null ? key : null;
  const normalizeRef = ({
    ref: ref3,
    ref_key,
    ref_for
  }) => {
    if (typeof ref3 === "number") {
      ref3 = "" + ref3;
    }
    return ref3 != null ? isString(ref3) || /* @__PURE__ */ isRef(ref3) || isFunction(ref3) ? { i: currentRenderingInstance, r: ref3, k: ref_key, f: !!ref_for } : ref3 : null;
  };
  function createBaseVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, shapeFlag = type === Fragment ? 0 : 1, isBlockNode = false, needFullChildrenNormalization = false) {
    const vnode = {
      __v_isVNode: true,
      __v_skip: true,
      type,
      props,
      key: props && normalizeKey(props),
      ref: props && normalizeRef(props),
      scopeId: currentScopeId,
      slotScopeIds: null,
      children,
      component: null,
      suspense: null,
      ssContent: null,
      ssFallback: null,
      dirs: null,
      transition: null,
      el: null,
      anchor: null,
      target: null,
      targetStart: null,
      targetAnchor: null,
      staticCount: 0,
      shapeFlag,
      patchFlag,
      dynamicProps,
      dynamicChildren: null,
      appContext: null,
      ctx: currentRenderingInstance
    };
    if (needFullChildrenNormalization) {
      normalizeChildren(vnode, children);
      if (shapeFlag & 128) {
        type.normalize(vnode);
      }
    } else if (children) {
      vnode.shapeFlag |= isString(children) ? 8 : 16;
    }
    if (isBlockTreeEnabled > 0 && // avoid a block node from tracking itself
    !isBlockNode && // has current parent block
    currentBlock && // presence of a patch flag indicates this node needs patching on updates.
    // component nodes also should always be patched, because even if the
    // component doesn't need to update, it needs to persist the instance on to
    // the next vnode so that it can be properly unmounted later.
    (vnode.patchFlag > 0 || shapeFlag & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
    // vnode should not be considered dynamic due to handler caching.
    vnode.patchFlag !== 32) {
      currentBlock.push(vnode);
    }
    return vnode;
  }
  const createVNode = _createVNode;
  function _createVNode(type, props = null, children = null, patchFlag = 0, dynamicProps = null, isBlockNode = false) {
    if (!type || type === NULL_DYNAMIC_COMPONENT) {
      type = Comment;
    }
    if (isVNode(type)) {
      const cloned = cloneVNode(
        type,
        props,
        true
        /* mergeRef: true */
      );
      if (children) {
        normalizeChildren(cloned, children);
      }
      if (isBlockTreeEnabled > 0 && !isBlockNode && currentBlock) {
        if (cloned.shapeFlag & 6) {
          currentBlock[currentBlock.indexOf(type)] = cloned;
        } else {
          currentBlock.push(cloned);
        }
      }
      cloned.patchFlag = -2;
      return cloned;
    }
    if (isClassComponent(type)) {
      type = type.__vccOpts;
    }
    if (props) {
      props = guardReactiveProps(props);
      let { class: klass, style } = props;
      if (klass && !isString(klass)) {
        props.class = normalizeClass(klass);
      }
      if (isObject(style)) {
        if (/* @__PURE__ */ isProxy(style) && !isArray(style)) {
          style = extend({}, style);
        }
        props.style = normalizeStyle(style);
      }
    }
    const shapeFlag = isString(type) ? 1 : isSuspense(type) ? 128 : isTeleport(type) ? 64 : isObject(type) ? 4 : isFunction(type) ? 2 : 0;
    return createBaseVNode(
      type,
      props,
      children,
      patchFlag,
      dynamicProps,
      shapeFlag,
      isBlockNode,
      true
    );
  }
  function guardReactiveProps(props) {
    if (!props) return null;
    return /* @__PURE__ */ isProxy(props) || isInternalObject(props) ? extend({}, props) : props;
  }
  function cloneVNode(vnode, extraProps, mergeRef = false, cloneTransition = false) {
    const { props, ref: ref3, patchFlag, children, transition } = vnode;
    const mergedProps = extraProps ? mergeProps(props || {}, extraProps) : props;
    const cloned = {
      __v_isVNode: true,
      __v_skip: true,
      type: vnode.type,
      props: mergedProps,
      key: mergedProps && normalizeKey(mergedProps),
      ref: extraProps && extraProps.ref ? (
        // #2078 in the case of <component :is="vnode" ref="extra"/>
        // if the vnode itself already has a ref, cloneVNode will need to merge
        // the refs so the single vnode can be set on multiple refs
        mergeRef && ref3 ? isArray(ref3) ? ref3.concat(normalizeRef(extraProps)) : [ref3, normalizeRef(extraProps)] : normalizeRef(extraProps)
      ) : ref3,
      scopeId: vnode.scopeId,
      slotScopeIds: vnode.slotScopeIds,
      children,
      target: vnode.target,
      targetStart: vnode.targetStart,
      targetAnchor: vnode.targetAnchor,
      staticCount: vnode.staticCount,
      shapeFlag: vnode.shapeFlag,
      // if the vnode is cloned with extra props, we can no longer assume its
      // existing patch flag to be reliable and need to add the FULL_PROPS flag.
      // note: preserve flag for fragments since they use the flag for children
      // fast paths only.
      patchFlag: extraProps && vnode.type !== Fragment ? patchFlag === -1 ? 16 : patchFlag | 16 : patchFlag,
      dynamicProps: vnode.dynamicProps,
      dynamicChildren: vnode.dynamicChildren,
      appContext: vnode.appContext,
      dirs: vnode.dirs,
      transition,
      // These should technically only be non-null on mounted VNodes. However,
      // they *should* be copied for kept-alive vnodes. So we just always copy
      // them since them being non-null during a mount doesn't affect the logic as
      // they will simply be overwritten.
      component: vnode.component,
      suspense: vnode.suspense,
      ssContent: vnode.ssContent && cloneVNode(vnode.ssContent),
      ssFallback: vnode.ssFallback && cloneVNode(vnode.ssFallback),
      placeholder: vnode.placeholder,
      el: vnode.el,
      anchor: vnode.anchor,
      ctx: vnode.ctx,
      ce: vnode.ce
    };
    if (transition && cloneTransition) {
      setTransitionHooks(
        cloned,
        transition.clone(cloned)
      );
    }
    return cloned;
  }
  function createTextVNode(text = " ", flag = 0) {
    return createVNode(Text, null, text, flag);
  }
  function createCommentVNode(text = "", asBlock = false) {
    return asBlock ? (openBlock(), createBlock(Comment, null, text)) : createVNode(Comment, null, text);
  }
  function normalizeVNode(child) {
    if (child == null || typeof child === "boolean") {
      return createVNode(Comment);
    } else if (isArray(child)) {
      return createVNode(
        Fragment,
        null,
        // #3666, avoid reference pollution when reusing vnode
        child.slice()
      );
    } else if (isVNode(child)) {
      return cloneIfMounted(child);
    } else {
      return createVNode(Text, null, String(child));
    }
  }
  function cloneIfMounted(child) {
    return child.el === null && child.patchFlag !== -1 || child.memo ? child : cloneVNode(child);
  }
  function normalizeChildren(vnode, children) {
    let type = 0;
    const { shapeFlag } = vnode;
    if (children == null) {
      children = null;
    } else if (isArray(children)) {
      type = 16;
    } else if (typeof children === "object") {
      if (shapeFlag & (1 | 64)) {
        const slot = children.default;
        if (slot) {
          slot._c && (slot._d = false);
          normalizeChildren(vnode, slot());
          slot._c && (slot._d = true);
        }
        return;
      } else {
        type = 32;
        const slotFlag = children._;
        if (!slotFlag && !isInternalObject(children)) {
          children._ctx = currentRenderingInstance;
        } else if (slotFlag === 3 && currentRenderingInstance) {
          if (currentRenderingInstance.slots._ === 1) {
            children._ = 1;
          } else {
            children._ = 2;
            vnode.patchFlag |= 1024;
          }
        }
      }
    } else if (isFunction(children)) {
      children = { default: children, _ctx: currentRenderingInstance };
      type = 32;
    } else {
      children = String(children);
      if (shapeFlag & 64) {
        type = 16;
        children = [createTextVNode(children)];
      } else {
        type = 8;
      }
    }
    vnode.children = children;
    vnode.shapeFlag |= type;
  }
  function mergeProps(...args) {
    const ret = {};
    for (let i = 0; i < args.length; i++) {
      const toMerge = args[i];
      for (const key in toMerge) {
        if (key === "class") {
          if (ret.class !== toMerge.class) {
            ret.class = normalizeClass([ret.class, toMerge.class]);
          }
        } else if (key === "style") {
          ret.style = normalizeStyle([ret.style, toMerge.style]);
        } else if (isOn(key)) {
          const existing = ret[key];
          const incoming = toMerge[key];
          if (incoming && existing !== incoming && !(isArray(existing) && existing.includes(incoming))) {
            ret[key] = existing ? [].concat(existing, incoming) : incoming;
          } else if (incoming == null && existing == null && // mergeProps({ 'onUpdate:modelValue': undefined }) should not retain
          // the model listener.
          !isModelListener(key)) {
            ret[key] = incoming;
          }
        } else if (key !== "") {
          ret[key] = toMerge[key];
        }
      }
    }
    return ret;
  }
  function invokeVNodeHook(hook, instance, vnode, prevVNode = null) {
    callWithAsyncErrorHandling(hook, instance, 7, [
      vnode,
      prevVNode
    ]);
  }
  const emptyAppContext = createAppContext();
  let uid = 0;
  function createComponentInstance(vnode, parent, suspense) {
    const type = vnode.type;
    const appContext = (parent ? parent.appContext : vnode.appContext) || emptyAppContext;
    const instance = {
      uid: uid++,
      vnode,
      type,
      parent,
      appContext,
      root: null,
      // to be immediately set
      next: null,
      subTree: null,
      // will be set synchronously right after creation
      effect: null,
      update: null,
      // will be set synchronously right after creation
      job: null,
      scope: new EffectScope(
        true
        /* detached */
      ),
      render: null,
      proxy: null,
      exposed: null,
      exposeProxy: null,
      withProxy: null,
      provides: parent ? parent.provides : Object.create(appContext.provides),
      ids: parent ? parent.ids : ["", 0, 0],
      accessCache: null,
      renderCache: [],
      // local resolved assets
      components: null,
      directives: null,
      // resolved props and emits options
      propsOptions: normalizePropsOptions(type, appContext),
      emitsOptions: normalizeEmitsOptions(type, appContext),
      // emit
      emit: null,
      // to be set immediately
      emitted: null,
      // props default value
      propsDefaults: EMPTY_OBJ,
      // inheritAttrs
      inheritAttrs: type.inheritAttrs,
      // state
      ctx: EMPTY_OBJ,
      data: EMPTY_OBJ,
      props: EMPTY_OBJ,
      attrs: EMPTY_OBJ,
      slots: EMPTY_OBJ,
      refs: EMPTY_OBJ,
      setupState: EMPTY_OBJ,
      setupContext: null,
      // suspense related
      suspense,
      suspenseId: suspense ? suspense.pendingId : 0,
      asyncDep: null,
      asyncResolved: false,
      // lifecycle hooks
      // not using enums here because it results in computed properties
      isMounted: false,
      isUnmounted: false,
      isDeactivated: false,
      bc: null,
      c: null,
      bm: null,
      m: null,
      bu: null,
      u: null,
      um: null,
      bum: null,
      da: null,
      a: null,
      rtg: null,
      rtc: null,
      ec: null,
      sp: null
    };
    {
      instance.ctx = { _: instance };
    }
    instance.root = parent ? parent.root : instance;
    instance.emit = emit.bind(null, instance);
    if (vnode.ce) {
      vnode.ce(instance);
    }
    return instance;
  }
  let currentInstance = null;
  const getCurrentInstance = () => currentInstance || currentRenderingInstance;
  let internalSetCurrentInstance;
  let setInSSRSetupState;
  {
    const g = getGlobalThis();
    const registerGlobalSetter = (key, setter) => {
      let setters;
      if (!(setters = g[key])) setters = g[key] = [];
      setters.push(setter);
      return (v) => {
        if (setters.length > 1) setters.forEach((set) => set(v));
        else setters[0](v);
      };
    };
    internalSetCurrentInstance = registerGlobalSetter(
      `__VUE_INSTANCE_SETTERS__`,
      (v) => currentInstance = v
    );
    setInSSRSetupState = registerGlobalSetter(
      `__VUE_SSR_SETTERS__`,
      (v) => isInSSRComponentSetup = v
    );
  }
  const setCurrentInstance = (instance) => {
    const prev = currentInstance;
    internalSetCurrentInstance(instance);
    instance.scope.on();
    return () => {
      instance.scope.off();
      internalSetCurrentInstance(prev);
    };
  };
  const unsetCurrentInstance = () => {
    currentInstance && currentInstance.scope.off();
    internalSetCurrentInstance(null);
  };
  function isStatefulComponent(instance) {
    return instance.vnode.shapeFlag & 4;
  }
  let isInSSRComponentSetup = false;
  function setupComponent(instance, isSSR = false, optimized = false) {
    isSSR && setInSSRSetupState(isSSR);
    const { props, children } = instance.vnode;
    const isStateful = isStatefulComponent(instance);
    initProps(instance, props, isStateful, isSSR);
    initSlots(instance, children, optimized || isSSR);
    const setupResult = isStateful ? setupStatefulComponent(instance, isSSR) : void 0;
    isSSR && setInSSRSetupState(false);
    return setupResult;
  }
  function setupStatefulComponent(instance, isSSR) {
    const Component = instance.type;
    instance.accessCache = /* @__PURE__ */ Object.create(null);
    instance.proxy = new Proxy(instance.ctx, PublicInstanceProxyHandlers);
    const { setup } = Component;
    if (setup) {
      pauseTracking();
      const setupContext = instance.setupContext = setup.length > 1 ? createSetupContext(instance) : null;
      const reset = setCurrentInstance(instance);
      const setupResult = callWithErrorHandling(
        setup,
        instance,
        0,
        [
          instance.props,
          setupContext
        ]
      );
      const isAsyncSetup = isPromise(setupResult);
      resetTracking();
      reset();
      if ((isAsyncSetup || instance.sp) && !isAsyncWrapper(instance)) {
        markAsyncBoundary(instance);
      }
      if (isAsyncSetup) {
        setupResult.then(unsetCurrentInstance, unsetCurrentInstance);
        if (isSSR) {
          return setupResult.then((resolvedResult) => {
            handleSetupResult(instance, resolvedResult);
          }).catch((e) => {
            handleError(e, instance, 0);
          });
        } else {
          instance.asyncDep = setupResult;
        }
      } else {
        handleSetupResult(instance, setupResult);
      }
    } else {
      finishComponentSetup(instance);
    }
  }
  function handleSetupResult(instance, setupResult, isSSR) {
    if (isFunction(setupResult)) {
      if (instance.type.__ssrInlineRender) {
        instance.ssrRender = setupResult;
      } else {
        instance.render = setupResult;
      }
    } else if (isObject(setupResult)) {
      instance.setupState = proxyRefs(setupResult);
    } else ;
    finishComponentSetup(instance);
  }
  function finishComponentSetup(instance, isSSR, skipOptions) {
    const Component = instance.type;
    if (!instance.render) {
      instance.render = Component.render || NOOP;
    }
    {
      const reset = setCurrentInstance(instance);
      pauseTracking();
      try {
        applyOptions(instance);
      } finally {
        resetTracking();
        reset();
      }
    }
  }
  const attrsProxyHandlers = {
    get(target, key) {
      track(target, "get", "");
      return target[key];
    }
  };
  function createSetupContext(instance) {
    const expose = (exposed) => {
      instance.exposed = exposed || {};
    };
    {
      return {
        attrs: new Proxy(instance.attrs, attrsProxyHandlers),
        slots: instance.slots,
        emit: instance.emit,
        expose
      };
    }
  }
  function getComponentPublicInstance(instance) {
    if (instance.exposed) {
      return instance.exposeProxy || (instance.exposeProxy = new Proxy(proxyRefs(markRaw(instance.exposed)), {
        get(target, key) {
          if (key in target) {
            return target[key];
          } else if (key in publicPropertiesMap) {
            return publicPropertiesMap[key](instance);
          }
        },
        has(target, key) {
          return key in target || key in publicPropertiesMap;
        }
      }));
    } else {
      return instance.proxy;
    }
  }
  const classifyRE = /(?:^|[-_])\w/g;
  const classify = (str) => str.replace(classifyRE, (c) => c.toUpperCase()).replace(/[-_]/g, "");
  function getComponentName(Component, includeInferred = true) {
    return isFunction(Component) ? Component.displayName || Component.name : Component.name || includeInferred && Component.__name;
  }
  function formatComponentName(instance, Component, isRoot = false) {
    let name = getComponentName(Component);
    if (!name && Component.__file) {
      const match = Component.__file.match(/([^/\\]+)\.\w+$/);
      if (match) {
        name = match[1];
      }
    }
    if (!name && instance) {
      const inferFromRegistry = (registry) => {
        for (const key in registry) {
          if (registry[key] === Component) {
            return key;
          }
        }
      };
      name = inferFromRegistry(instance.components) || instance.parent && inferFromRegistry(
        instance.parent.type.components
      ) || inferFromRegistry(instance.appContext.components);
    }
    return name ? classify(name) : isRoot ? `App` : `Anonymous`;
  }
  function isClassComponent(value) {
    return isFunction(value) && "__vccOpts" in value;
  }
  const computed = (getterOrOptions, debugOptions) => {
    const c = /* @__PURE__ */ computed$1(getterOrOptions, debugOptions, isInSSRComponentSetup);
    return c;
  };
  const version = "3.5.38";
  /**
  * @vue/runtime-dom v3.5.38
  * (c) 2018-present Yuxi (Evan) You and Vue contributors
  * @license MIT
  **/
  let policy = void 0;
  const tt = typeof window !== "undefined" && window.trustedTypes;
  if (tt) {
    try {
      policy = /* @__PURE__ */ tt.createPolicy("vue", {
        createHTML: (val) => val
      });
    } catch (e) {
    }
  }
  const unsafeToTrustedHTML = policy ? (val) => policy.createHTML(val) : (val) => val;
  const svgNS = "http://www.w3.org/2000/svg";
  const mathmlNS = "http://www.w3.org/1998/Math/MathML";
  const doc = typeof document !== "undefined" ? document : null;
  const templateContainer = doc && /* @__PURE__ */ doc.createElement("template");
  const nodeOps = {
    insert: (child, parent, anchor) => {
      parent.insertBefore(child, anchor || null);
    },
    remove: (child) => {
      const parent = child.parentNode;
      if (parent) {
        parent.removeChild(child);
      }
    },
    createElement: (tag, namespace, is, props) => {
      const el = namespace === "svg" ? doc.createElementNS(svgNS, tag) : namespace === "mathml" ? doc.createElementNS(mathmlNS, tag) : is ? doc.createElement(tag, { is }) : doc.createElement(tag);
      if (tag === "select" && props && props.multiple != null) {
        el.setAttribute("multiple", props.multiple);
      }
      return el;
    },
    createText: (text) => doc.createTextNode(text),
    createComment: (text) => doc.createComment(text),
    setText: (node, text) => {
      node.nodeValue = text;
    },
    setElementText: (el, text) => {
      el.textContent = text;
    },
    parentNode: (node) => node.parentNode,
    nextSibling: (node) => node.nextSibling,
    querySelector: (selector) => doc.querySelector(selector),
    setScopeId(el, id) {
      el.setAttribute(id, "");
    },
    // __UNSAFE__
    // Reason: innerHTML.
    // Static content here can only come from compiled templates.
    // As long as the user only uses trusted templates, this is safe.
    insertStaticContent(content, parent, anchor, namespace, start, end) {
      const before = anchor ? anchor.previousSibling : parent.lastChild;
      if (start && (start === end || start.nextSibling)) {
        while (true) {
          parent.insertBefore(start.cloneNode(true), anchor);
          if (start === end || !(start = start.nextSibling)) break;
        }
      } else {
        templateContainer.innerHTML = unsafeToTrustedHTML(
          namespace === "svg" ? `<svg>${content}</svg>` : namespace === "mathml" ? `<math>${content}</math>` : content
        );
        const template = templateContainer.content;
        if (namespace === "svg" || namespace === "mathml") {
          const wrapper = template.firstChild;
          while (wrapper.firstChild) {
            template.appendChild(wrapper.firstChild);
          }
          template.removeChild(wrapper);
        }
        parent.insertBefore(template, anchor);
      }
      return [
        // first
        before ? before.nextSibling : parent.firstChild,
        // last
        anchor ? anchor.previousSibling : parent.lastChild
      ];
    }
  };
  const vtcKey = /* @__PURE__ */ Symbol("_vtc");
  function patchClass(el, value, isSVG) {
    const transitionClasses = el[vtcKey];
    if (transitionClasses) {
      value = (value ? [value, ...transitionClasses] : [...transitionClasses]).join(" ");
    }
    if (value == null) {
      el.removeAttribute("class");
    } else if (isSVG) {
      el.setAttribute("class", value);
    } else {
      el.className = value;
    }
  }
  const vShowOriginalDisplay = /* @__PURE__ */ Symbol("_vod");
  const vShowHidden = /* @__PURE__ */ Symbol("_vsh");
  const vShow = {
    // used for prop mismatch check during hydration
    name: "show",
    beforeMount(el, { value }, { transition }) {
      el[vShowOriginalDisplay] = el.style.display === "none" ? "" : el.style.display;
      if (transition && value) {
        transition.beforeEnter(el);
      } else {
        setDisplay(el, value);
      }
    },
    mounted(el, { value }, { transition }) {
      if (transition && value) {
        transition.enter(el);
      }
    },
    updated(el, { value, oldValue }, { transition }) {
      if (!value === !oldValue) return;
      if (transition) {
        if (value) {
          transition.beforeEnter(el);
          setDisplay(el, true);
          transition.enter(el);
        } else {
          transition.leave(el, () => {
            setDisplay(el, false);
          });
        }
      } else {
        setDisplay(el, value);
      }
    },
    beforeUnmount(el, { value }) {
      setDisplay(el, value);
    }
  };
  function setDisplay(el, value) {
    el.style.display = value ? el[vShowOriginalDisplay] : "none";
    el[vShowHidden] = !value;
  }
  const CSS_VAR_TEXT = /* @__PURE__ */ Symbol("");
  const displayRE = /(?:^|;)\s*display\s*:/;
  function patchStyle(el, prev, next) {
    const style = el.style;
    const isCssString = isString(next);
    let hasControlledDisplay = false;
    if (next && !isCssString) {
      if (prev) {
        if (!isString(prev)) {
          for (const key in prev) {
            if (next[key] == null) {
              setStyle(style, key, "");
            }
          }
        } else {
          for (const prevStyle of prev.split(";")) {
            const key = prevStyle.slice(0, prevStyle.indexOf(":")).trim();
            if (next[key] == null) {
              setStyle(style, key, "");
            }
          }
        }
      }
      for (const key in next) {
        if (key === "display") {
          hasControlledDisplay = true;
        }
        const value = next[key];
        if (value != null) {
          if (!shouldPreserveTextareaResizeStyle(
            el,
            key,
            !isString(prev) && prev ? prev[key] : void 0,
            value
          )) {
            setStyle(style, key, value);
          }
        } else {
          setStyle(style, key, "");
        }
      }
    } else {
      if (isCssString) {
        if (prev !== next) {
          const cssVarText = style[CSS_VAR_TEXT];
          if (cssVarText) {
            next += ";" + cssVarText;
          }
          style.cssText = next;
          hasControlledDisplay = displayRE.test(next);
        }
      } else if (prev) {
        el.removeAttribute("style");
      }
    }
    if (vShowOriginalDisplay in el) {
      el[vShowOriginalDisplay] = hasControlledDisplay ? style.display : "";
      if (el[vShowHidden]) {
        style.display = "none";
      }
    }
  }
  const importantRE = /\s*!important$/;
  function setStyle(style, name, val) {
    if (isArray(val)) {
      val.forEach((v) => setStyle(style, name, v));
    } else {
      if (val == null) val = "";
      if (name.startsWith("--")) {
        style.setProperty(name, val);
      } else {
        const prefixed = autoPrefix(style, name);
        if (importantRE.test(val)) {
          style.setProperty(
            hyphenate(prefixed),
            val.replace(importantRE, ""),
            "important"
          );
        } else {
          style[prefixed] = val;
        }
      }
    }
  }
  const prefixes = ["Webkit", "Moz", "ms"];
  const prefixCache = {};
  function autoPrefix(style, rawName) {
    const cached = prefixCache[rawName];
    if (cached) {
      return cached;
    }
    let name = camelize(rawName);
    if (name !== "filter" && name in style) {
      return prefixCache[rawName] = name;
    }
    name = capitalize(name);
    for (let i = 0; i < prefixes.length; i++) {
      const prefixed = prefixes[i] + name;
      if (prefixed in style) {
        return prefixCache[rawName] = prefixed;
      }
    }
    return rawName;
  }
  function shouldPreserveTextareaResizeStyle(el, key, prev, next) {
    return el.tagName === "TEXTAREA" && (key === "width" || key === "height") && isString(next) && prev === next;
  }
  const xlinkNS = "http://www.w3.org/1999/xlink";
  function patchAttr(el, key, value, isSVG, instance, isBoolean = isSpecialBooleanAttr(key)) {
    if (isSVG && key.startsWith("xlink:")) {
      if (value == null) {
        el.removeAttributeNS(xlinkNS, key.slice(6, key.length));
      } else {
        el.setAttributeNS(xlinkNS, key, value);
      }
    } else {
      if (value == null || isBoolean && !includeBooleanAttr(value)) {
        el.removeAttribute(key);
      } else {
        el.setAttribute(
          key,
          isBoolean ? "" : isSymbol(value) ? String(value) : value
        );
      }
    }
  }
  function patchDOMProp(el, key, value, parentComponent, attrName) {
    if (key === "innerHTML" || key === "textContent") {
      if (value != null) {
        el[key] = key === "innerHTML" ? unsafeToTrustedHTML(value) : value;
      }
      return;
    }
    const tag = el.tagName;
    if (key === "value" && tag !== "PROGRESS" && // custom elements may use _value internally
    !tag.includes("-")) {
      const oldValue = tag === "OPTION" ? el.getAttribute("value") || "" : el.value;
      const newValue = value == null ? (
        // #11647: value should be set as empty string for null and undefined,
        // but <input type="checkbox"> should be set as 'on'.
        el.type === "checkbox" ? "on" : ""
      ) : String(value);
      if (oldValue !== newValue || !("_value" in el)) {
        el.value = newValue;
      }
      if (value == null) {
        el.removeAttribute(key);
      }
      el._value = value;
      return;
    }
    let needRemove = false;
    if (value === "" || value == null) {
      const type = typeof el[key];
      if (type === "boolean") {
        value = includeBooleanAttr(value);
      } else if (value == null && type === "string") {
        value = "";
        needRemove = true;
      } else if (type === "number") {
        value = 0;
        needRemove = true;
      }
    }
    try {
      el[key] = value;
    } catch (e) {
    }
    needRemove && el.removeAttribute(attrName || key);
  }
  function addEventListener(el, event, handler, options) {
    el.addEventListener(event, handler, options);
  }
  function removeEventListener(el, event, handler, options) {
    el.removeEventListener(event, handler, options);
  }
  const veiKey = /* @__PURE__ */ Symbol("_vei");
  function patchEvent(el, rawName, prevValue, nextValue, instance = null) {
    const invokers = el[veiKey] || (el[veiKey] = {});
    const existingInvoker = invokers[rawName];
    if (nextValue && existingInvoker) {
      existingInvoker.value = nextValue;
    } else {
      const [name, options] = parseName(rawName);
      if (nextValue) {
        const invoker = invokers[rawName] = createInvoker(
          nextValue,
          instance
        );
        addEventListener(el, name, invoker, options);
      } else if (existingInvoker) {
        removeEventListener(el, name, existingInvoker, options);
        invokers[rawName] = void 0;
      }
    }
  }
  const optionsModifierRE = /(?:Once|Passive|Capture)$/;
  function parseName(name) {
    let options;
    if (optionsModifierRE.test(name)) {
      options = {};
      let m;
      while (m = name.match(optionsModifierRE)) {
        name = name.slice(0, name.length - m[0].length);
        options[m[0].toLowerCase()] = true;
      }
    }
    const event = name[2] === ":" ? name.slice(3) : hyphenate(name.slice(2));
    return [event, options];
  }
  let cachedNow = 0;
  const p = /* @__PURE__ */ Promise.resolve();
  const getNow = () => cachedNow || (p.then(() => cachedNow = 0), cachedNow = Date.now());
  function createInvoker(initialValue, instance) {
    const invoker = (e) => {
      if (!e._vts) {
        e._vts = Date.now();
      } else if (e._vts <= invoker.attached) {
        return;
      }
      const value = invoker.value;
      if (isArray(value)) {
        const originalStop = e.stopImmediatePropagation;
        e.stopImmediatePropagation = () => {
          originalStop.call(e);
          e._stopped = true;
        };
        const handlers2 = value.slice();
        const args = [e];
        for (let i = 0; i < handlers2.length; i++) {
          if (e._stopped) {
            break;
          }
          const handler = handlers2[i];
          if (handler) {
            callWithAsyncErrorHandling(
              handler,
              instance,
              5,
              args
            );
          }
        }
      } else {
        callWithAsyncErrorHandling(
          value,
          instance,
          5,
          [e]
        );
      }
    };
    invoker.value = initialValue;
    invoker.attached = getNow();
    return invoker;
  }
  const isNativeOn = (key) => key.charCodeAt(0) === 111 && key.charCodeAt(1) === 110 && // lowercase letter
  key.charCodeAt(2) > 96 && key.charCodeAt(2) < 123;
  const patchProp = (el, key, prevValue, nextValue, namespace, parentComponent) => {
    const isSVG = namespace === "svg";
    if (key === "class") {
      patchClass(el, nextValue, isSVG);
    } else if (key === "style") {
      patchStyle(el, prevValue, nextValue);
    } else if (isOn(key)) {
      if (!isModelListener(key)) {
        patchEvent(el, key, prevValue, nextValue, parentComponent);
      }
    } else if (key[0] === "." ? (key = key.slice(1), true) : key[0] === "^" ? (key = key.slice(1), false) : shouldSetAsProp(el, key, nextValue, isSVG)) {
      patchDOMProp(el, key, nextValue);
      if (!el.tagName.includes("-") && (key === "value" || key === "checked" || key === "selected")) {
        patchAttr(el, key, nextValue, isSVG, parentComponent, key !== "value");
      }
    } else if (
      // #11081 force set props for possible async custom element
      el._isVueCE && // #12408 check if it's declared prop or it's async custom element
      (shouldSetAsPropForVueCE(el, key) || // @ts-expect-error _def is private
      el._def.__asyncLoader && (/[A-Z]/.test(key) || !isString(nextValue)))
    ) {
      patchDOMProp(el, camelize(key), nextValue, parentComponent, key);
    } else {
      if (key === "true-value") {
        el._trueValue = nextValue;
      } else if (key === "false-value") {
        el._falseValue = nextValue;
      }
      patchAttr(el, key, nextValue, isSVG);
    }
  };
  function shouldSetAsProp(el, key, value, isSVG) {
    if (isSVG) {
      if (key === "innerHTML" || key === "textContent") {
        return true;
      }
      if (key in el && isNativeOn(key) && isFunction(value)) {
        return true;
      }
      return false;
    }
    if (key === "spellcheck" || key === "draggable" || key === "translate" || key === "autocorrect") {
      return false;
    }
    if (key === "sandbox" && el.tagName === "IFRAME") {
      return false;
    }
    if (key === "form") {
      return false;
    }
    if (key === "list" && el.tagName === "INPUT") {
      return false;
    }
    if (key === "type" && el.tagName === "TEXTAREA") {
      return false;
    }
    if (key === "width" || key === "height") {
      const tag = el.tagName;
      if (tag === "IMG" || tag === "VIDEO" || tag === "CANVAS" || tag === "SOURCE") {
        return false;
      }
    }
    if (isNativeOn(key) && isString(value)) {
      return false;
    }
    return key in el;
  }
  function shouldSetAsPropForVueCE(el, key) {
    const props = (
      // @ts-expect-error _def is private
      el._def.props
    );
    if (!props) {
      return false;
    }
    const camelKey = camelize(key);
    return Array.isArray(props) ? props.some((prop) => camelize(prop) === camelKey) : Object.keys(props).some((prop) => camelize(prop) === camelKey);
  }
  const getModelAssigner = (vnode) => {
    const fn = vnode.props["onUpdate:modelValue"] || false;
    return isArray(fn) ? (value) => invokeArrayFns(fn, value) : fn;
  };
  function onCompositionStart(e) {
    e.target.composing = true;
  }
  function onCompositionEnd(e) {
    const target = e.target;
    if (target.composing) {
      target.composing = false;
      target.dispatchEvent(new Event("input"));
    }
  }
  const assignKey = /* @__PURE__ */ Symbol("_assign");
  function castValue(value, trim, number) {
    if (trim) value = value.trim();
    if (number) value = looseToNumber(value);
    return value;
  }
  const vModelText = {
    created(el, { modifiers: { lazy, trim, number } }, vnode) {
      el[assignKey] = getModelAssigner(vnode);
      const castToNumber = number || vnode.props && vnode.props.type === "number";
      addEventListener(el, lazy ? "change" : "input", (e) => {
        if (e.target.composing) return;
        el[assignKey](castValue(el.value, trim, castToNumber));
      });
      if (trim || castToNumber) {
        addEventListener(el, "change", () => {
          el.value = castValue(el.value, trim, castToNumber);
        });
      }
      if (!lazy) {
        addEventListener(el, "compositionstart", onCompositionStart);
        addEventListener(el, "compositionend", onCompositionEnd);
        addEventListener(el, "change", onCompositionEnd);
      }
    },
    // set value on mounted so it's after min/max for type="range"
    mounted(el, { value }) {
      el.value = value == null ? "" : value;
    },
    beforeUpdate(el, { value, oldValue, modifiers: { lazy, trim, number } }, vnode) {
      el[assignKey] = getModelAssigner(vnode);
      if (el.composing) return;
      const elValue = (number || el.type === "number") && !/^0\d/.test(el.value) ? looseToNumber(el.value) : el.value;
      const newValue = value == null ? "" : value;
      if (elValue === newValue) {
        return;
      }
      const rootNode = el.getRootNode();
      if ((rootNode instanceof Document || rootNode instanceof ShadowRoot) && rootNode.activeElement === el && el.type !== "range") {
        if (lazy && value === oldValue) {
          return;
        }
        if (trim && el.value.trim() === newValue) {
          return;
        }
      }
      el.value = newValue;
    }
  };
  const vModelCheckbox = {
    // #4096 array checkboxes need to be deep traversed
    deep: true,
    created(el, _, vnode) {
      el[assignKey] = getModelAssigner(vnode);
      addEventListener(el, "change", () => {
        const modelValue = el._modelValue;
        const elementValue = getValue(el);
        const checked = el.checked;
        const assign = el[assignKey];
        if (isArray(modelValue)) {
          const index = looseIndexOf(modelValue, elementValue);
          const found = index !== -1;
          if (checked && !found) {
            assign(modelValue.concat(elementValue));
          } else if (!checked && found) {
            const filtered = [...modelValue];
            filtered.splice(index, 1);
            assign(filtered);
          }
        } else if (isSet(modelValue)) {
          const cloned = new Set(modelValue);
          if (checked) {
            cloned.add(elementValue);
          } else {
            cloned.delete(elementValue);
          }
          assign(cloned);
        } else {
          assign(getCheckboxValue(el, checked));
        }
      });
    },
    // set initial checked on mount to wait for true-value/false-value
    mounted: setChecked,
    beforeUpdate(el, binding, vnode) {
      el[assignKey] = getModelAssigner(vnode);
      setChecked(el, binding, vnode);
    }
  };
  function setChecked(el, { value, oldValue }, vnode) {
    el._modelValue = value;
    let checked;
    if (isArray(value)) {
      checked = looseIndexOf(value, vnode.props.value) > -1;
    } else if (isSet(value)) {
      checked = value.has(vnode.props.value);
    } else {
      if (value === oldValue) return;
      checked = looseEqual(value, getCheckboxValue(el, true));
    }
    if (el.checked !== checked) {
      el.checked = checked;
    }
  }
  function getValue(el) {
    return "_value" in el ? el._value : el.value;
  }
  function getCheckboxValue(el, checked) {
    const key = checked ? "_trueValue" : "_falseValue";
    return key in el ? el[key] : checked;
  }
  const systemModifiers = ["ctrl", "shift", "alt", "meta"];
  const modifierGuards = {
    stop: (e) => e.stopPropagation(),
    prevent: (e) => e.preventDefault(),
    self: (e) => e.target !== e.currentTarget,
    ctrl: (e) => !e.ctrlKey,
    shift: (e) => !e.shiftKey,
    alt: (e) => !e.altKey,
    meta: (e) => !e.metaKey,
    left: (e) => "button" in e && e.button !== 0,
    middle: (e) => "button" in e && e.button !== 1,
    right: (e) => "button" in e && e.button !== 2,
    exact: (e, modifiers) => systemModifiers.some((m) => e[`${m}Key`] && !modifiers.includes(m))
  };
  const withModifiers = (fn, modifiers) => {
    if (!fn) return fn;
    const cache = fn._withMods || (fn._withMods = {});
    const cacheKey = modifiers.join(".");
    return cache[cacheKey] || (cache[cacheKey] = (event, ...args) => {
      for (let i = 0; i < modifiers.length; i++) {
        const guard = modifierGuards[modifiers[i]];
        if (guard && guard(event, modifiers)) return;
      }
      return fn(event, ...args);
    });
  };
  const keyNames = {
    esc: "escape",
    space: " ",
    up: "arrow-up",
    left: "arrow-left",
    right: "arrow-right",
    down: "arrow-down",
    delete: "backspace"
  };
  const withKeys = (fn, modifiers) => {
    const cache = fn._withKeys || (fn._withKeys = {});
    const cacheKey = modifiers.join(".");
    return cache[cacheKey] || (cache[cacheKey] = (event) => {
      if (!("key" in event)) {
        return;
      }
      const eventKey = hyphenate(event.key);
      if (modifiers.some(
        (k) => k === eventKey || keyNames[k] === eventKey
      )) {
        return fn(event);
      }
    });
  };
  const rendererOptions = /* @__PURE__ */ extend({ patchProp }, nodeOps);
  let renderer;
  function ensureRenderer() {
    return renderer || (renderer = createRenderer(rendererOptions));
  }
  const createApp = (...args) => {
    const app = ensureRenderer().createApp(...args);
    const { mount: mount2 } = app;
    app.mount = (containerOrSelector) => {
      const container = normalizeContainer(containerOrSelector);
      if (!container) return;
      const component = app._component;
      if (!isFunction(component) && !component.render && !component.template) {
        component.template = container.innerHTML;
      }
      if (container.nodeType === 1) {
        container.textContent = "";
      }
      const proxy = mount2(container, false, resolveRootNamespace(container));
      if (container instanceof Element) {
        container.removeAttribute("v-cloak");
        container.setAttribute("data-v-app", "");
      }
      return proxy;
    };
    return app;
  };
  function resolveRootNamespace(container) {
    if (container instanceof SVGElement) {
      return "svg";
    }
    if (typeof MathMLElement === "function" && container instanceof MathMLElement) {
      return "mathml";
    }
  }
  function normalizeContainer(container) {
    if (isString(container)) {
      const res = document.querySelector(container);
      return res;
    }
    return container;
  }
  const HOOK_SOURCE = "tmap-hook";
  const PANEL_SOURCE = "tmap-panel";
  var HookEvent = /* @__PURE__ */ ((HookEvent2) => {
    HookEvent2["MAP_READY"] = "MAP_READY";
    HookEvent2["POINT_ADDED"] = "POINT_ADDED";
    HookEvent2["SEGMENT_ADDED"] = "SEGMENT_ADDED";
    HookEvent2["MEASUREMENT_RESULT"] = "MEASUREMENT_RESULT";
    HookEvent2["POINT_REMOVED"] = "POINT_REMOVED";
    HookEvent2["POLYGON_POINT_ADDED"] = "POLYGON_POINT_ADDED";
    HookEvent2["POLYGON_POINT_REMOVED"] = "POLYGON_POINT_REMOVED";
    HookEvent2["POLYGON_DRAWN"] = "POLYGON_DRAWN";
    HookEvent2["POLYGON_SELECTED"] = "POLYGON_SELECTED";
    HookEvent2["POLYGON_DELETED"] = "POLYGON_DELETED";
    HookEvent2["POLYGON_MODE_CHANGED"] = "POLYGON_MODE_CHANGED";
    HookEvent2["POLYGON_EDIT_STARTED"] = "POLYGON_EDIT_STARTED";
    HookEvent2["POLYGON_EDIT_FINISHED"] = "POLYGON_EDIT_FINISHED";
    HookEvent2["POLYGON_EDIT_CANCELLED"] = "POLYGON_EDIT_CANCELLED";
    HookEvent2["POINT_MARKER_ADDED"] = "POINT_MARKER_ADDED";
    HookEvent2["POINT_MARKER_DELETED"] = "POINT_MARKER_DELETED";
    HookEvent2["MAP_LOST"] = "MAP_LOST";
    HookEvent2["MAP_RESTORED"] = "MAP_RESTORED";
    HookEvent2["POLYGON_GEOMETRY"] = "POLYGON_GEOMETRY";
    HookEvent2["MOUSE_MOVE"] = "MOUSE_MOVE";
    HookEvent2["CIRCLE_CENTER_SET"] = "CIRCLE_CENTER_SET";
    HookEvent2["CIRCLE_UPDATED"] = "CIRCLE_UPDATED";
    return HookEvent2;
  })(HookEvent || {});
  var PanelCmd = /* @__PURE__ */ ((PanelCmd2) => {
    PanelCmd2["PANEL_READY"] = "PANEL_READY";
    PanelCmd2["SET_TOOL"] = "SET_TOOL";
    PanelCmd2["FINISH"] = "FINISH";
    PanelCmd2["UNDO"] = "UNDO";
    PanelCmd2["CLEAR"] = "CLEAR";
    PanelCmd2["SET_DEBUG"] = "SET_DEBUG";
    PanelCmd2["DRAW_POLYGON"] = "DRAW_POLYGON";
    PanelCmd2["DELETE_POLYGON"] = "DELETE_POLYGON";
    PanelCmd2["START_DRAWING_POLYGON"] = "START_DRAWING_POLYGON";
    PanelCmd2["FINISH_DRAWING_POLYGON"] = "FINISH_DRAWING_POLYGON";
    PanelCmd2["CANCEL_DRAWING_POLYGON"] = "CANCEL_DRAWING_POLYGON";
    PanelCmd2["UNDO_POLYGON_POINT"] = "UNDO_POLYGON_POINT";
    PanelCmd2["SELECT_POLYGON"] = "SELECT_POLYGON";
    PanelCmd2["TOGGLE_POLYGON_VISIBLE"] = "TOGGLE_POLYGON_VISIBLE";
    PanelCmd2["START_EDIT_POLYGON"] = "START_EDIT_POLYGON";
    PanelCmd2["FINISH_EDIT_POLYGON"] = "FINISH_EDIT_POLYGON";
    PanelCmd2["CANCEL_EDIT_POLYGON"] = "CANCEL_EDIT_POLYGON";
    PanelCmd2["DELETE_POINT_MARKER"] = "DELETE_POINT_MARKER";
    PanelCmd2["SELECT_POINT_MARKER"] = "SELECT_POINT_MARKER";
    PanelCmd2["TOGGLE_POINT_MARKER_VISIBLE"] = "TOGGLE_POINT_MARKER_VISIBLE";
    PanelCmd2["RENAME_POINT_MARKER"] = "RENAME_POINT_MARKER";
    PanelCmd2["IMPORT_POINT_MARKERS"] = "IMPORT_POINT_MARKERS";
    PanelCmd2["UPDATE_CIRCLE"] = "UPDATE_CIRCLE";
    PanelCmd2["FINISH_CIRCLE"] = "FINISH_CIRCLE";
    return PanelCmd2;
  })(PanelCmd || {});
  function sendToHook(msg) {
    window.postMessage({ ...msg, source: PANEL_SOURCE }, "*");
  }
  const handlers = [];
  function onMessage(event) {
    const msg = event.data;
    if (!msg || msg.source !== HOOK_SOURCE) return;
    handlers.forEach((h) => h(msg));
  }
  let listenerInstalled = false;
  function ensureListener() {
    if (listenerInstalled) return;
    window.addEventListener("message", onMessage);
    listenerInstalled = true;
  }
  function useMapBridge() {
    const onHookEvent = (handler) => {
      ensureListener();
      handlers.push(handler);
      onUnmounted(() => {
        const idx = handlers.indexOf(handler);
        if (idx !== -1) handlers.splice(idx, 1);
      });
    };
    const sendCmd = sendToHook;
    onMounted(() => {
      sendToHook({ type: PanelCmd.PANEL_READY });
    });
    return { onHookEvent, sendCmd };
  }
  function formatDistance(meters) {
    if (meters >= 1e3) {
      return `${(meters / 1e3).toFixed(2)} km`;
    }
    return `${Math.round(meters)} m`;
  }
  function formatArea(sqMeters) {
    if (sqMeters >= 1e6) {
      return `${(sqMeters / 1e6).toFixed(2)} km²`;
    }
    if (sqMeters >= 1e3) {
      return `${(sqMeters / 1e6).toFixed(4)} km² (${Math.round(sqMeters).toLocaleString()} m²)`;
    }
    return `${Math.round(sqMeters)} m²`;
  }
  function useTool() {
    const { onHookEvent, sendCmd } = useMapBridge();
    const isMapReady = /* @__PURE__ */ ref(false);
    const mapStatus = /* @__PURE__ */ ref("init");
    const activeTool = /* @__PURE__ */ ref("");
    const segments = /* @__PURE__ */ ref([]);
    const totalM = /* @__PURE__ */ ref(0);
    const pointCount = /* @__PURE__ */ ref(0);
    const polygonMode = /* @__PURE__ */ ref("idle");
    const drawingPointCount = /* @__PURE__ */ ref(0);
    const drawingCoordsText = /* @__PURE__ */ ref("");
    const polygonLayers = /* @__PURE__ */ ref([]);
    const editingPolygonId = /* @__PURE__ */ ref(null);
    let polygonNameCounter = 0;
    const pointMarkers = /* @__PURE__ */ ref([]);
    const mouseCoords = /* @__PURE__ */ ref(null);
    const circlePreview = /* @__PURE__ */ ref(null);
    const circlePreviewGeometry = /* @__PURE__ */ ref(null);
    const totalLabel = computed(() => totalM.value > 0 ? formatDistance(totalM.value) : "");
    onHookEvent((msg) => {
      switch (msg.type) {
        case HookEvent.MAP_READY:
          isMapReady.value = true;
          mapStatus.value = "ready";
          break;
        case HookEvent.MAP_LOST:
          isMapReady.value = false;
          mapStatus.value = "lost";
          break;
        case HookEvent.MAP_RESTORED:
          isMapReady.value = true;
          mapStatus.value = "restored";
          setTimeout(() => {
            if (mapStatus.value === "restored") mapStatus.value = "ready";
          }, 2e3);
          break;
        case HookEvent.POINT_ADDED:
          pointCount.value = msg.payload.index + 1;
          break;
        case HookEvent.SEGMENT_ADDED: {
          const p2 = msg.payload;
          segments.value.push({
            from: p2.fromIdx + 1,
            to: p2.toIdx + 1,
            distanceM: p2.distanceM,
            label: formatDistance(p2.distanceM)
          });
          totalM.value = p2.totalM;
          break;
        }
        case HookEvent.POINT_REMOVED:
          pointCount.value = msg.payload.newCount;
          if (segments.value.length > 0) {
            const removed = segments.value.pop();
            totalM.value -= removed.distanceM;
          }
          break;
        case HookEvent.POLYGON_MODE_CHANGED:
          polygonMode.value = msg.payload.mode;
          drawingPointCount.value = msg.payload.drawingPointCount;
          if (msg.payload.mode === "idle") {
            drawingCoordsText.value = "";
          }
          break;
        case HookEvent.POLYGON_POINT_ADDED:
          drawingPointCount.value = msg.payload.index + 1;
          drawingCoordsText.value = msg.payload.coordsText;
          break;
        case HookEvent.POLYGON_POINT_REMOVED:
          drawingPointCount.value = msg.payload.newCount;
          drawingCoordsText.value = msg.payload.coordsText;
          break;
        case HookEvent.POLYGON_DRAWN:
          polygonLayers.value.push({
            id: msg.payload.id,
            name: `多边形 ${++polygonNameCounter}`,
            visible: true,
            selected: false,
            coords: [],
            area: null,
            perimeter: null
          });
          break;
        case HookEvent.POLYGON_SELECTED: {
          const prev = polygonLayers.value.find((l) => l.selected);
          if (prev) {
            prev.selected = false;
          }
          const next = polygonLayers.value.find((l) => l.id === msg.payload.id);
          if (next) {
            next.selected = true;
            next.coords = msg.payload.coords;
          }
          break;
        }
        case HookEvent.POLYGON_DELETED: {
          const idx = polygonLayers.value.findIndex((l) => l.id === msg.payload.id);
          if (idx !== -1) polygonLayers.value.splice(idx, 1);
          break;
        }
        case HookEvent.POLYGON_EDIT_STARTED:
          editingPolygonId.value = msg.payload.id;
          break;
        case HookEvent.POLYGON_EDIT_FINISHED: {
          editingPolygonId.value = null;
          const edited = polygonLayers.value.find((l) => l.id === msg.payload.id);
          if (edited) edited.coords = msg.payload.coords;
          break;
        }
        case HookEvent.POLYGON_EDIT_CANCELLED:
          editingPolygonId.value = null;
          break;
        case HookEvent.POLYGON_GEOMETRY: {
          const layer = polygonLayers.value.find((l) => l.id === msg.payload.id);
          if (layer) {
            layer.area = msg.payload.area;
            layer.perimeter = msg.payload.perimeter;
          }
          break;
        }
        case HookEvent.POINT_MARKER_ADDED:
          pointMarkers.value.push({
            id: msg.payload.id,
            name: msg.payload.name,
            visible: true,
            selected: false,
            lat: msg.payload.lat,
            lng: msg.payload.lng
          });
          break;
        case HookEvent.POINT_MARKER_DELETED: {
          const idx = pointMarkers.value.findIndex((p2) => p2.id === msg.payload.id);
          if (idx !== -1) pointMarkers.value.splice(idx, 1);
          break;
        }
        case HookEvent.MOUSE_MOVE:
          mouseCoords.value = { lat: msg.payload.lat, lng: msg.payload.lng };
          break;
        case HookEvent.CIRCLE_CENTER_SET:
          circlePreview.value = {
            id: msg.payload.id,
            lat: msg.payload.lat,
            lng: msg.payload.lng,
            radius: msg.payload.radius,
            nPoints: msg.payload.nPoints
          };
          circlePreviewGeometry.value = null;
          break;
        case HookEvent.CIRCLE_UPDATED:
          if (circlePreview.value && circlePreview.value.id === msg.payload.id) {
            circlePreview.value.radius = msg.payload.radius;
            circlePreview.value.nPoints = msg.payload.nPoints;
            circlePreviewGeometry.value = {
              area: msg.payload.area,
              perimeter: msg.payload.perimeter
            };
          }
          break;
      }
    });
    function setTool(toolId) {
      const next = activeTool.value === toolId ? "" : toolId;
      activeTool.value = next;
      segments.value = [];
      totalM.value = 0;
      pointCount.value = 0;
      if (next !== "circle") {
        circlePreview.value = null;
        circlePreviewGeometry.value = null;
      }
      if (next !== "polygon") {
        polygonMode.value = "idle";
        drawingPointCount.value = 0;
        drawingCoordsText.value = "";
      }
      sendCmd({ type: PanelCmd.SET_TOOL, payload: { toolId: next } });
    }
    function finish() {
      activeTool.value = "";
      sendCmd({ type: PanelCmd.FINISH });
    }
    function undo() {
      sendCmd({ type: PanelCmd.UNDO });
    }
    function clear() {
      segments.value = [];
      totalM.value = 0;
      pointCount.value = 0;
      activeTool.value = "";
      polygonMode.value = "idle";
      drawingPointCount.value = 0;
      drawingCoordsText.value = "";
      polygonLayers.value = [];
      polygonNameCounter = 0;
      pointMarkers.value = [];
      circlePreview.value = null;
      circlePreviewGeometry.value = null;
      sendCmd({ type: PanelCmd.CLEAR });
    }
    function startDrawingPolygon() {
      sendCmd({ type: PanelCmd.START_DRAWING_POLYGON });
    }
    function finishDrawingPolygon() {
      sendCmd({ type: PanelCmd.FINISH_DRAWING_POLYGON });
    }
    function cancelDrawingPolygon() {
      sendCmd({ type: PanelCmd.CANCEL_DRAWING_POLYGON });
    }
    function undoPolygonPoint() {
      sendCmd({ type: PanelCmd.UNDO_POLYGON_POINT });
    }
    function drawPolygon(input) {
      sendCmd({ type: PanelCmd.DRAW_POLYGON, payload: { input } });
    }
    function deletePolygon(id) {
      sendCmd({ type: PanelCmd.DELETE_POLYGON, payload: { id } });
    }
    function selectPolygonFromPanel(id) {
      const prev = polygonLayers.value.find((l) => l.selected);
      if (prev) prev.selected = false;
      const next = polygonLayers.value.find((l) => l.id === id);
      if (next) next.selected = true;
      sendCmd({ type: PanelCmd.SELECT_POLYGON, payload: { id } });
    }
    function togglePolygonVisible(id) {
      const layer = polygonLayers.value.find((l) => l.id === id);
      if (!layer) return;
      layer.visible = !layer.visible;
      sendCmd({ type: PanelCmd.TOGGLE_POLYGON_VISIBLE, payload: { id, visible: layer.visible } });
    }
    function renamePolygon(id, name) {
      const layer = polygonLayers.value.find((l) => l.id === id);
      if (layer) layer.name = name;
    }
    function startEditPolygon(id) {
      sendCmd({ type: PanelCmd.START_EDIT_POLYGON, payload: { id } });
    }
    function finishEditPolygon() {
      sendCmd({ type: PanelCmd.FINISH_EDIT_POLYGON });
    }
    function cancelEditPolygon() {
      sendCmd({ type: PanelCmd.CANCEL_EDIT_POLYGON });
    }
    function deletePointMarker(id) {
      sendCmd({ type: PanelCmd.DELETE_POINT_MARKER, payload: { id } });
    }
    function selectPointMarkerFromPanel(id, multiSelect = false) {
      if (multiSelect) {
        const marker = pointMarkers.value.find((p2) => p2.id === id);
        if (marker) marker.selected = !marker.selected;
      } else {
        pointMarkers.value.forEach((p2) => {
          p2.selected = false;
        });
        const marker = pointMarkers.value.find((p2) => p2.id === id);
        if (marker) marker.selected = true;
        sendCmd({ type: PanelCmd.SELECT_POINT_MARKER, payload: { id } });
      }
    }
    function togglePointMarkerVisible(id) {
      const marker = pointMarkers.value.find((p2) => p2.id === id);
      if (!marker) return;
      marker.visible = !marker.visible;
      sendCmd({ type: PanelCmd.TOGGLE_POINT_MARKER_VISIBLE, payload: { id, visible: marker.visible } });
    }
    function renamePointMarker(id, name) {
      const marker = pointMarkers.value.find((p2) => p2.id === id);
      if (marker) marker.name = name;
      sendCmd({ type: PanelCmd.RENAME_POINT_MARKER, payload: { id, name } });
    }
    function importPointMarkers(input) {
      sendCmd({ type: PanelCmd.IMPORT_POINT_MARKERS, payload: { input } });
    }
    function updateCircle(id, radius, nPoints) {
      sendCmd({ type: PanelCmd.UPDATE_CIRCLE, payload: { id, radius, nPoints } });
    }
    function finishCircle() {
      sendCmd({ type: PanelCmd.FINISH_CIRCLE });
      circlePreview.value = null;
      circlePreviewGeometry.value = null;
    }
    function setDebug(enabled) {
      sendCmd({ type: PanelCmd.SET_DEBUG, payload: { enabled } });
    }
    return {
      isMapReady,
      mapStatus,
      activeTool,
      segments,
      totalLabel,
      pointCount,
      // polygon
      polygonMode,
      drawingPointCount,
      drawingCoordsText,
      polygonLayers,
      editingPolygonId,
      // point marker
      pointMarkers,
      // mouse coords
      mouseCoords,
      // circle
      circlePreview,
      circlePreviewGeometry,
      // commands
      setTool,
      finish,
      undo,
      clear,
      startDrawingPolygon,
      finishDrawingPolygon,
      cancelDrawingPolygon,
      undoPolygonPoint,
      drawPolygon,
      deletePolygon,
      selectPolygonFromPanel,
      togglePolygonVisible,
      renamePolygon,
      startEditPolygon,
      finishEditPolygon,
      cancelEditPolygon,
      deletePointMarker,
      selectPointMarkerFromPanel,
      togglePointMarkerVisible,
      renamePointMarker,
      importPointMarkers,
      updateCircle,
      finishCircle,
      setDebug
    };
  }
  const SETTINGS_KEY = "__tmh_settings__";
  const THEME_KEY = "__tmh_theme__";
  const HOST_ID = "tmap-hooker-host";
  const TOOL_CONFIGS = [
    {
      id: "multi-point",
      name: "多点测距",
      icon: "📐",
      description: "连续点击测量折线总距离"
    },
    {
      id: "circle",
      name: "圆形",
      icon: "⭕",
      description: "点击圆心，自定义半径画圆"
    },
    {
      id: "polygon",
      name: "绘制多边形",
      icon: "⬡",
      description: "在地图上点击选点绘制多边形"
    },
    {
      id: "point-marker",
      name: "打点标记",
      icon: "📍",
      description: "在地图上点击标记位置点"
    }
  ];
  const TOOL_IDS = {
    MULTI_POINT: "multi-point",
    CIRCLE: "circle",
    POLYGON: "polygon",
    POINT_MARKER: "point-marker"
  };
  const _hoisted_1$8 = { class: "toolbar" };
  const _hoisted_2$6 = ["title", "disabled", "onClick"];
  const _hoisted_3$5 = { class: "tool-icon" };
  const _hoisted_4$5 = { class: "tool-name" };
  const _sfc_main$8 = /* @__PURE__ */ defineComponent({
    __name: "ToolBar",
    props: {
      activeTool: {},
      isMapReady: { type: Boolean }
    },
    emits: ["select"],
    setup(__props, { emit: __emit }) {
      const emit2 = __emit;
      return (_ctx, _cache) => {
        return openBlock(), createElementBlock("div", _hoisted_1$8, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unref(TOOL_CONFIGS), (tool) => {
            return openBlock(), createElementBlock("button", {
              key: tool.id,
              class: normalizeClass(["tool-btn", { active: __props.activeTool === tool.id, disabled: !__props.isMapReady }]),
              title: tool.description,
              disabled: !__props.isMapReady,
              onClick: ($event) => emit2("select", tool.id)
            }, [
              createBaseVNode("span", _hoisted_3$5, toDisplayString(tool.icon), 1),
              createBaseVNode("span", _hoisted_4$5, toDisplayString(tool.name), 1)
            ], 10, _hoisted_2$6);
          }), 128))
        ]);
      };
    }
  });
  const _hoisted_1$7 = { class: "result-block" };
  const _hoisted_2$5 = {
    key: 0,
    class: "result-hint"
  };
  const _hoisted_3$4 = {
    key: 1,
    class: "segment-list"
  };
  const _hoisted_4$4 = { class: "seg-idx" };
  const _hoisted_5$3 = { class: "seg-dist" };
  const _hoisted_6$3 = { class: "segment-row segment-total" };
  const _hoisted_7$3 = { class: "seg-dist" };
  const _sfc_main$7 = /* @__PURE__ */ defineComponent({
    __name: "MultiPointResult",
    props: {
      segments: {},
      totalLabel: {},
      pointCount: {}
    },
    setup(__props) {
      return (_ctx, _cache) => {
        return openBlock(), createElementBlock("div", _hoisted_1$7, [
          __props.segments.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_2$5, toDisplayString(__props.pointCount === 0 ? "请点击地图添加测量点" : "请继续点击添加更多点"), 1)) : (openBlock(), createElementBlock("div", _hoisted_3$4, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(__props.segments, (seg) => {
              return openBlock(), createElementBlock("div", {
                key: `${seg.from}-${seg.to}`,
                class: "segment-row"
              }, [
                createBaseVNode("span", _hoisted_4$4, toDisplayString(seg.from) + " → " + toDisplayString(seg.to), 1),
                createBaseVNode("span", _hoisted_5$3, toDisplayString(seg.label), 1)
              ]);
            }), 128)),
            createBaseVNode("div", _hoisted_6$3, [
              _cache[0] || (_cache[0] = createBaseVNode("span", { class: "seg-idx" }, "合计", -1)),
              createBaseVNode("span", _hoisted_7$3, toDisplayString(__props.totalLabel), 1)
            ])
          ]))
        ]);
      };
    }
  });
  const _hoisted_1$6 = { class: "polygon-panel" };
  const _hoisted_2$4 = { class: "poly-mode-bar" };
  const _hoisted_3$3 = ["disabled"];
  const _hoisted_4$3 = {
    key: 0,
    class: "poly-draw-controls"
  };
  const _hoisted_5$2 = { class: "poly-draw-actions" };
  const _hoisted_6$2 = ["disabled"];
  const _hoisted_7$2 = ["disabled"];
  const _hoisted_8$2 = { class: "poly-layers" };
  const _hoisted_9$2 = { class: "poly-layers-header" };
  const _hoisted_10$2 = { class: "poly-layer-count" };
  const _hoisted_11$2 = { class: "poly-layer-list" };
  const _hoisted_12$2 = {
    key: 0,
    class: "poly-layer-empty"
  };
  const _hoisted_13$2 = ["onClick"];
  const _hoisted_14$1 = ["title", "onClick"];
  const _hoisted_15$1 = ["value", "onBlur", "onKeydown"];
  const _hoisted_16$1 = ["title", "onDblclick"];
  const _hoisted_17$1 = { class: "poly-layer-actions" };
  const _hoisted_18$1 = ["disabled", "onClick"];
  const _hoisted_19$1 = ["disabled", "onClick"];
  const _hoisted_20$1 = {
    key: 1,
    class: "poly-coords-export"
  };
  const _hoisted_21$1 = {
    key: 0,
    class: "poly-geometry-info"
  };
  const _hoisted_22$1 = { class: "poly-geometry-item" };
  const _hoisted_23 = { class: "poly-geometry-item" };
  const _hoisted_24 = { class: "poly-coords-header" };
  const _hoisted_25 = { class: "poly-coords-fmt-bar" };
  const _hoisted_26 = ["value"];
  const _hoisted_27 = { class: "poly-import-body" };
  const _hoisted_28 = { class: "polygon-actions" };
  const _hoisted_29 = ["disabled"];
  const _hoisted_30 = ["disabled"];
  const _sfc_main$6 = /* @__PURE__ */ defineComponent({
    __name: "PolygonPanel",
    props: {
      polygonMode: {},
      drawingPointCount: {},
      polygonLayers: {},
      editingPolygonId: {}
    },
    emits: ["startDrawing", "finishDrawing", "cancelDrawing", "undoPoint", "deleteLayer", "renameLayer", "toggleVisible", "selectLayer", "drawFromText", "startEdit", "finishEdit", "cancelEdit"],
    setup(__props, { emit: __emit }) {
      const props = __props;
      const emit2 = __emit;
      const coordsExpanded = /* @__PURE__ */ ref(false);
      const localCoords = /* @__PURE__ */ ref("");
      const editingId = /* @__PURE__ */ ref(null);
      const nameInputRef = /* @__PURE__ */ ref(null);
      const setNameInputRef = (el) => {
        nameInputRef.value = el;
      };
      const coordsFmt = /* @__PURE__ */ ref("array");
      const copied = /* @__PURE__ */ ref(false);
      const selectedLayer = computed(() => props.polygonLayers.find((l) => l.selected) ?? null);
      const formattedCoords = computed(() => {
        var _a;
        const coords = ((_a = selectedLayer.value) == null ? void 0 : _a.coords) ?? [];
        if (coords.length === 0) return "";
        if (coordsFmt.value === "array") {
          return JSON.stringify(coords.map((c) => [c.lng, c.lat]));
        }
        return coords.map((c) => `${c.lng},${c.lat}`).join(";");
      });
      async function copyCoords() {
        if (!formattedCoords.value) return;
        try {
          await navigator.clipboard.writeText(formattedCoords.value);
          copied.value = true;
          setTimeout(() => {
            copied.value = false;
          }, 2e3);
        } catch {
        }
      }
      function onSelectLayer(id) {
        if (editingId.value !== null) return;
        emit2("selectLayer", id);
      }
      function startEdit(id) {
        editingId.value = id;
        nextTick(() => {
          var _a;
          (_a = nameInputRef.value) == null ? void 0 : _a.select();
        });
      }
      function onNameBlur(id, evt) {
        const input = evt.target;
        const name = input.value.trim();
        if (name) emit2("renameLayer", id, name);
        editingId.value = null;
      }
      function onDrawFromText() {
        const text = localCoords.value.trim();
        if (!text) return;
        emit2("drawFromText", text);
        localCoords.value = "";
      }
      return (_ctx, _cache) => {
        return openBlock(), createElementBlock("div", _hoisted_1$6, [
          createBaseVNode("div", _hoisted_2$4, [
            createBaseVNode("span", {
              class: normalizeClass(["poly-mode-badge", __props.editingPolygonId ? "editing" : __props.polygonMode])
            }, toDisplayString(__props.editingPolygonId ? "✎ 编辑模式" : __props.polygonMode === "drawing" ? `● 绘制中 ${__props.drawingPointCount}点` : "选择模式"), 3),
            createBaseVNode("button", {
              class: "poly-new-btn",
              disabled: __props.polygonMode === "drawing" || !!__props.editingPolygonId,
              onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("startDrawing"))
            }, " + 新建多边形 ", 8, _hoisted_3$3)
          ]),
          __props.polygonMode === "drawing" ? (openBlock(), createElementBlock("div", _hoisted_4$3, [
            _cache[13] || (_cache[13] = createBaseVNode("div", { class: "poly-draw-hint" }, "单击添加顶点 · 双击完成 · Esc 取消", -1)),
            createBaseVNode("div", _hoisted_5$2, [
              createBaseVNode("button", {
                class: "poly-btn draw-btn",
                disabled: __props.drawingPointCount < 3,
                onClick: _cache[1] || (_cache[1] = ($event) => _ctx.$emit("finishDrawing"))
              }, " ✓ 完成 ", 8, _hoisted_6$2),
              createBaseVNode("button", {
                class: "poly-btn undo-poly-btn",
                disabled: __props.drawingPointCount === 0,
                onClick: _cache[2] || (_cache[2] = ($event) => _ctx.$emit("undoPoint"))
              }, " ↩ 撤销 ", 8, _hoisted_7$2),
              createBaseVNode("button", {
                class: "poly-btn cancel-btn",
                onClick: _cache[3] || (_cache[3] = ($event) => _ctx.$emit("cancelDrawing"))
              }, " ✗ 取消 ")
            ])
          ])) : createCommentVNode("", true),
          createBaseVNode("div", _hoisted_8$2, [
            createBaseVNode("div", _hoisted_9$2, [
              _cache[14] || (_cache[14] = createBaseVNode("span", null, "图层列表", -1)),
              createBaseVNode("span", _hoisted_10$2, toDisplayString(__props.polygonLayers.length), 1)
            ]),
            createBaseVNode("div", _hoisted_11$2, [
              __props.polygonLayers.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_12$2, ' 尚无多边形，点击"新建"开始绘制 ')) : createCommentVNode("", true),
              (openBlock(true), createElementBlock(Fragment, null, renderList(__props.polygonLayers, (layer) => {
                return openBlock(), createElementBlock("div", {
                  key: layer.id,
                  class: normalizeClass(["poly-layer-item", { selected: layer.selected, "hidden-layer": !layer.visible }]),
                  onClick: ($event) => onSelectLayer(layer.id)
                }, [
                  createBaseVNode("button", {
                    class: "poly-layer-vis",
                    title: layer.visible ? "隐藏" : "显示",
                    onClick: withModifiers(($event) => _ctx.$emit("toggleVisible", layer.id), ["stop"])
                  }, toDisplayString(layer.visible ? "👁" : "🚫"), 9, _hoisted_14$1),
                  editingId.value === layer.id ? (openBlock(), createElementBlock("input", {
                    key: 0,
                    ref_for: true,
                    ref: setNameInputRef,
                    class: "poly-name-input",
                    value: layer.name,
                    onBlur: ($event) => onNameBlur(layer.id, $event),
                    onKeydown: [
                      withKeys(($event) => onNameBlur(layer.id, $event), ["enter"]),
                      _cache[4] || (_cache[4] = withKeys(withModifiers(($event) => editingId.value = null, ["stop"]), ["escape"]))
                    ],
                    onClick: _cache[5] || (_cache[5] = withModifiers(() => {
                    }, ["stop"]))
                  }, null, 40, _hoisted_15$1)) : (openBlock(), createElementBlock("span", {
                    key: 1,
                    class: "poly-layer-name",
                    title: layer.name + "（双击重命名）",
                    onDblclick: withModifiers(($event) => startEdit(layer.id), ["stop"])
                  }, toDisplayString(layer.name), 41, _hoisted_16$1)),
                  createBaseVNode("span", _hoisted_17$1, [
                    __props.editingPolygonId === layer.id ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
                      createBaseVNode("button", {
                        class: "poly-layer-edit-done",
                        title: "完成编辑",
                        onClick: _cache[6] || (_cache[6] = withModifiers(($event) => _ctx.$emit("finishEdit"), ["stop"]))
                      }, "✓"),
                      createBaseVNode("button", {
                        class: "poly-layer-edit-cancel",
                        title: "取消编辑",
                        onClick: _cache[7] || (_cache[7] = withModifiers(($event) => _ctx.$emit("cancelEdit"), ["stop"]))
                      }, "✗")
                    ], 64)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                      createBaseVNode("button", {
                        class: "poly-layer-edit",
                        title: "编辑顶点",
                        disabled: !!__props.editingPolygonId || __props.polygonMode === "drawing",
                        onClick: withModifiers(($event) => _ctx.$emit("startEdit", layer.id), ["stop"])
                      }, "✏️", 8, _hoisted_18$1),
                      createBaseVNode("button", {
                        class: "poly-layer-del",
                        title: "删除",
                        disabled: !!__props.editingPolygonId,
                        onClick: withModifiers(($event) => _ctx.$emit("deleteLayer", layer.id), ["stop"])
                      }, "🗑", 8, _hoisted_19$1)
                    ], 64))
                  ])
                ], 10, _hoisted_13$2);
              }), 128))
            ])
          ]),
          selectedLayer.value && selectedLayer.value.coords.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_20$1, [
            selectedLayer.value.area != null ? (openBlock(), createElementBlock("div", _hoisted_21$1, [
              createBaseVNode("span", _hoisted_22$1, "面积 " + toDisplayString(unref(formatArea)(selectedLayer.value.area)), 1),
              createBaseVNode("span", _hoisted_23, "周长 " + toDisplayString(unref(formatDistance)(selectedLayer.value.perimeter)), 1)
            ])) : createCommentVNode("", true),
            createBaseVNode("div", _hoisted_24, [
              _cache[15] || (_cache[15] = createBaseVNode("span", null, "坐标导出", -1)),
              createBaseVNode("div", _hoisted_25, [
                createBaseVNode("button", {
                  class: normalizeClass(["poly-coords-fmt-btn", { active: coordsFmt.value === "array" }]),
                  onClick: _cache[8] || (_cache[8] = ($event) => coordsFmt.value = "array")
                }, "二维数组", 2),
                createBaseVNode("button", {
                  class: normalizeClass(["poly-coords-fmt-btn", { active: coordsFmt.value === "semicolon" }]),
                  onClick: _cache[9] || (_cache[9] = ($event) => coordsFmt.value = "semicolon")
                }, "分号格式", 2)
              ])
            ]),
            createBaseVNode("textarea", {
              class: "poly-coords-textarea",
              readonly: "",
              value: formattedCoords.value,
              rows: "3",
              spellcheck: "false"
            }, null, 8, _hoisted_26),
            createBaseVNode("button", {
              class: "poly-btn draw-btn poly-coords-copy-btn",
              onClick: copyCoords
            }, toDisplayString(copied.value ? "已复制 ✓" : "复制"), 1)
          ])) : createCommentVNode("", true),
          createBaseVNode("div", null, [
            createBaseVNode("div", {
              class: "poly-import-toggle",
              onClick: _cache[10] || (_cache[10] = ($event) => coordsExpanded.value = !coordsExpanded.value)
            }, [
              createBaseVNode("span", {
                class: normalizeClass(["toggle-arrow", { open: coordsExpanded.value }])
              }, "▶", 2),
              _cache[16] || (_cache[16] = createTextVNode(" 坐标导入 ", -1))
            ]),
            withDirectives(createBaseVNode("div", _hoisted_27, [
              withDirectives(createBaseVNode("textarea", {
                class: "coords-input",
                "onUpdate:modelValue": _cache[11] || (_cache[11] = ($event) => localCoords.value = $event),
                placeholder: "[[lng,lat],[lng,lat],...]\n或 lng,lat;lng,lat;...",
                rows: "3",
                spellcheck: "false"
              }, null, 512), [
                [vModelText, localCoords.value]
              ]),
              createBaseVNode("div", _hoisted_28, [
                createBaseVNode("button", {
                  class: "poly-btn draw-btn",
                  disabled: !localCoords.value.trim(),
                  onClick: onDrawFromText
                }, " 绘制 ", 8, _hoisted_29),
                createBaseVNode("button", {
                  class: "poly-btn clear-btn",
                  disabled: !localCoords.value.trim(),
                  onClick: _cache[12] || (_cache[12] = ($event) => localCoords.value = "")
                }, " 清空 ", 8, _hoisted_30)
              ])
            ], 512), [
              [vShow, coordsExpanded.value]
            ])
          ])
        ]);
      };
    }
  });
  const _hoisted_1$5 = { class: "circle-panel" };
  const _hoisted_2$3 = {
    key: 0,
    class: "circle-preview"
  };
  const _hoisted_3$2 = { class: "circle-center-info" };
  const _hoisted_4$2 = { class: "circle-coords" };
  const _hoisted_5$1 = { class: "circle-param" };
  const _hoisted_6$1 = { class: "circle-param-row" };
  const _hoisted_7$1 = ["value"];
  const _hoisted_8$1 = ["value"];
  const _hoisted_9$1 = { class: "circle-param" };
  const _hoisted_10$1 = { class: "circle-param-row" };
  const _hoisted_11$1 = ["value"];
  const _hoisted_12$1 = {
    key: 0,
    class: "circle-geometry-info"
  };
  const _hoisted_13$1 = {
    key: 1,
    class: "circle-hint"
  };
  const _sfc_main$5 = /* @__PURE__ */ defineComponent({
    __name: "CirclePanel",
    props: {
      circlePreview: {},
      previewGeometry: {}
    },
    emits: ["updateCircle", "finishCircle"],
    setup(__props, { emit: __emit }) {
      var _a, _b;
      const props = __props;
      const emit2 = __emit;
      const radius = /* @__PURE__ */ ref(((_a = props.circlePreview) == null ? void 0 : _a.radius) ?? 500);
      const nPoints = /* @__PURE__ */ ref(((_b = props.circlePreview) == null ? void 0 : _b.nPoints) ?? 64);
      watch(() => props.circlePreview, (p2) => {
        if (p2) {
          radius.value = p2.radius;
          nPoints.value = p2.nPoints;
        }
      });
      function sendUpdate() {
        if (props.circlePreview) {
          emit2("updateCircle", props.circlePreview.id, radius.value, nPoints.value);
        }
      }
      function onRadiusSlider(e) {
        radius.value = Number(e.target.value);
        sendUpdate();
      }
      function onRadiusInput(e) {
        const val = Number(e.target.value);
        if (!isNaN(val) && val > 0) {
          radius.value = Math.max(10, Math.min(5e4, val));
          sendUpdate();
        }
      }
      function onNPointsChange(e) {
        nPoints.value = Number(e.target.value);
        sendUpdate();
      }
      return (_ctx, _cache) => {
        return openBlock(), createElementBlock("div", _hoisted_1$5, [
          __props.circlePreview ? (openBlock(), createElementBlock("div", _hoisted_2$3, [
            createBaseVNode("div", _hoisted_3$2, [
              _cache[1] || (_cache[1] = createBaseVNode("span", { class: "circle-label" }, "圆心", -1)),
              createBaseVNode("span", _hoisted_4$2, toDisplayString(__props.circlePreview.lng.toFixed(6)) + ", " + toDisplayString(__props.circlePreview.lat.toFixed(6)), 1)
            ]),
            createBaseVNode("div", _hoisted_5$1, [
              _cache[3] || (_cache[3] = createBaseVNode("label", { class: "circle-param-label" }, "半径", -1)),
              createBaseVNode("div", _hoisted_6$1, [
                createBaseVNode("input", {
                  type: "range",
                  min: 50,
                  max: 1e4,
                  step: 10,
                  value: radius.value,
                  class: "circle-slider",
                  onInput: onRadiusSlider
                }, null, 40, _hoisted_7$1),
                createBaseVNode("input", {
                  type: "number",
                  value: radius.value,
                  class: "circle-number",
                  onChange: onRadiusInput
                }, null, 40, _hoisted_8$1),
                _cache[2] || (_cache[2] = createBaseVNode("span", { class: "circle-unit" }, "m", -1))
              ])
            ]),
            createBaseVNode("div", _hoisted_9$1, [
              _cache[5] || (_cache[5] = createBaseVNode("label", { class: "circle-param-label" }, "拟合点数", -1)),
              createBaseVNode("div", _hoisted_10$1, [
                createBaseVNode("select", {
                  value: nPoints.value,
                  class: "circle-select",
                  onChange: onNPointsChange
                }, [..._cache[4] || (_cache[4] = [
                  createBaseVNode("option", { value: 16 }, "16", -1),
                  createBaseVNode("option", { value: 32 }, "32", -1),
                  createBaseVNode("option", { value: 64 }, "64（推荐）", -1),
                  createBaseVNode("option", { value: 128 }, "128", -1)
                ])], 40, _hoisted_11$1)
              ])
            ]),
            __props.previewGeometry ? (openBlock(), createElementBlock("div", _hoisted_12$1, [
              createBaseVNode("span", null, "面积 " + toDisplayString(unref(formatArea)(__props.previewGeometry.area)), 1),
              createBaseVNode("span", null, "周长 " + toDisplayString(unref(formatDistance)(__props.previewGeometry.perimeter)), 1)
            ])) : createCommentVNode("", true),
            createBaseVNode("button", {
              class: "circle-finish-btn",
              onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("finishCircle"))
            }, " ✓ 完成 ")
          ])) : (openBlock(), createElementBlock("div", _hoisted_13$1, " 点击地图放置圆心 "))
        ]);
      };
    }
  });
  const _hoisted_1$4 = { class: "point-panel" };
  const _hoisted_2$2 = { class: "point-hint" };
  const _hoisted_3$1 = { class: "poly-layers" };
  const _hoisted_4$1 = { class: "poly-layers-header" };
  const _hoisted_5 = { class: "poly-layer-count" };
  const _hoisted_6 = { class: "poly-layer-list" };
  const _hoisted_7 = {
    key: 0,
    class: "poly-layer-empty"
  };
  const _hoisted_8 = ["onClick"];
  const _hoisted_9 = ["title", "onClick"];
  const _hoisted_10 = ["value", "onBlur", "onKeydown"];
  const _hoisted_11 = ["title", "onDblclick"];
  const _hoisted_12 = { class: "poly-layer-actions" };
  const _hoisted_13 = ["onClick"];
  const _hoisted_14 = {
    key: 0,
    class: "point-sel-badge"
  };
  const _hoisted_15 = { class: "poly-import-body" };
  const _hoisted_16 = {
    key: 0,
    class: "poly-layer-empty"
  };
  const _hoisted_17 = {
    class: "poly-coords-fmt-bar",
    style: { "margin-bottom": "6px" }
  };
  const _hoisted_18 = ["value"];
  const _hoisted_19 = { class: "poly-import-body" };
  const _hoisted_20 = { class: "polygon-actions" };
  const _hoisted_21 = ["disabled"];
  const _hoisted_22 = ["disabled"];
  const _sfc_main$4 = /* @__PURE__ */ defineComponent({
    __name: "PointPanel",
    props: {
      pointMarkers: {}
    },
    emits: ["deletePoint", "renamePoint", "toggleVisible", "selectPoint", "importPoints"],
    setup(__props, { emit: __emit }) {
      const props = __props;
      const emit2 = __emit;
      const exportExpanded = /* @__PURE__ */ ref(false);
      const importExpanded = /* @__PURE__ */ ref(false);
      const localCoords = /* @__PURE__ */ ref("");
      const editingId = /* @__PURE__ */ ref(null);
      const nameInputRef = /* @__PURE__ */ ref(null);
      const setNameInputRef = (el) => {
        nameInputRef.value = el;
      };
      const coordsFmt = /* @__PURE__ */ ref("array");
      const copied = /* @__PURE__ */ ref(false);
      const isShiftHeld = /* @__PURE__ */ ref(false);
      function onKeydown(e) {
        if (e.key === "Shift") isShiftHeld.value = true;
      }
      function onKeyup(e) {
        if (e.key === "Shift") isShiftHeld.value = false;
      }
      onMounted(() => {
        window.addEventListener("keydown", onKeydown);
        window.addEventListener("keyup", onKeyup);
      });
      onUnmounted(() => {
        window.removeEventListener("keydown", onKeydown);
        window.removeEventListener("keyup", onKeyup);
      });
      const selectedMarkers = computed(() => props.pointMarkers.filter((m) => m.selected));
      const formattedCoords = computed(() => {
        if (selectedMarkers.value.length === 0) return "";
        if (coordsFmt.value === "array") {
          return JSON.stringify(selectedMarkers.value.map((m) => [m.lng, m.lat]));
        }
        return selectedMarkers.value.map((m) => `${m.lng},${m.lat}`).join(";");
      });
      async function copyCoords() {
        if (!formattedCoords.value) return;
        try {
          await navigator.clipboard.writeText(formattedCoords.value);
          copied.value = true;
          setTimeout(() => {
            copied.value = false;
          }, 2e3);
        } catch {
        }
      }
      function onSelectMarker(id) {
        if (editingId.value !== null) return;
        emit2("selectPoint", id, isShiftHeld.value);
      }
      function startEdit(id) {
        editingId.value = id;
        nextTick(() => {
          var _a;
          (_a = nameInputRef.value) == null ? void 0 : _a.select();
        });
      }
      function onNameBlur(id, evt) {
        const input = evt.target;
        const name = input.value.trim();
        if (name) emit2("renamePoint", id, name);
        editingId.value = null;
      }
      function onImport() {
        const text = localCoords.value.trim();
        if (!text) return;
        emit2("importPoints", text);
        localCoords.value = "";
      }
      return (_ctx, _cache) => {
        return openBlock(), createElementBlock("div", _hoisted_1$4, [
          createBaseVNode("div", _hoisted_2$2, "点击地图添加点位" + toDisplayString(isShiftHeld.value ? " · Shift 多选模式" : ""), 1),
          createBaseVNode("div", _hoisted_3$1, [
            createBaseVNode("div", _hoisted_4$1, [
              _cache[8] || (_cache[8] = createBaseVNode("span", null, "点位列表", -1)),
              createBaseVNode("span", _hoisted_5, toDisplayString(__props.pointMarkers.length), 1)
            ]),
            createBaseVNode("div", _hoisted_6, [
              __props.pointMarkers.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_7, " 尚无点位，点击地图开始标记 ")) : createCommentVNode("", true),
              (openBlock(true), createElementBlock(Fragment, null, renderList(__props.pointMarkers, (marker) => {
                return openBlock(), createElementBlock("div", {
                  key: marker.id,
                  class: normalizeClass(["poly-layer-item", { selected: marker.selected, "hidden-layer": !marker.visible }]),
                  onClick: ($event) => onSelectMarker(marker.id)
                }, [
                  createBaseVNode("button", {
                    class: "poly-layer-vis",
                    title: marker.visible ? "隐藏" : "显示",
                    onClick: withModifiers(($event) => _ctx.$emit("toggleVisible", marker.id), ["stop"])
                  }, toDisplayString(marker.visible ? "👁" : "🚫"), 9, _hoisted_9),
                  editingId.value === marker.id ? (openBlock(), createElementBlock("input", {
                    key: 0,
                    ref_for: true,
                    ref: setNameInputRef,
                    class: "poly-name-input",
                    value: marker.name,
                    onBlur: ($event) => onNameBlur(marker.id, $event),
                    onKeydown: [
                      withKeys(($event) => onNameBlur(marker.id, $event), ["enter"]),
                      _cache[0] || (_cache[0] = withKeys(withModifiers(($event) => editingId.value = null, ["stop"]), ["escape"]))
                    ],
                    onClick: _cache[1] || (_cache[1] = withModifiers(() => {
                    }, ["stop"]))
                  }, null, 40, _hoisted_10)) : (openBlock(), createElementBlock("span", {
                    key: 1,
                    class: "poly-layer-name",
                    title: marker.name + "（双击重命名）",
                    onDblclick: withModifiers(($event) => startEdit(marker.id), ["stop"])
                  }, toDisplayString(marker.name), 41, _hoisted_11)),
                  createBaseVNode("span", _hoisted_12, [
                    createBaseVNode("button", {
                      class: "poly-layer-del",
                      title: "删除",
                      onClick: withModifiers(($event) => _ctx.$emit("deletePoint", marker.id), ["stop"])
                    }, "🗑", 8, _hoisted_13)
                  ])
                ], 10, _hoisted_8);
              }), 128))
            ])
          ]),
          createBaseVNode("div", null, [
            createBaseVNode("div", {
              class: "poly-import-toggle",
              onClick: _cache[2] || (_cache[2] = ($event) => exportExpanded.value = !exportExpanded.value)
            }, [
              createBaseVNode("span", {
                class: normalizeClass(["toggle-arrow", { open: exportExpanded.value }])
              }, "▶", 2),
              _cache[9] || (_cache[9] = createTextVNode(" 坐标导出 ", -1)),
              selectedMarkers.value.length > 0 ? (openBlock(), createElementBlock("span", _hoisted_14, toDisplayString(selectedMarkers.value.length), 1)) : createCommentVNode("", true)
            ]),
            withDirectives(createBaseVNode("div", _hoisted_15, [
              selectedMarkers.value.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_16, " 请先在列表中选中点位 ")) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                createBaseVNode("div", _hoisted_17, [
                  createBaseVNode("button", {
                    class: normalizeClass(["poly-coords-fmt-btn", { active: coordsFmt.value === "array" }]),
                    onClick: _cache[3] || (_cache[3] = ($event) => coordsFmt.value = "array")
                  }, "二维数组", 2),
                  createBaseVNode("button", {
                    class: normalizeClass(["poly-coords-fmt-btn", { active: coordsFmt.value === "semicolon" }]),
                    onClick: _cache[4] || (_cache[4] = ($event) => coordsFmt.value = "semicolon")
                  }, "分号格式", 2)
                ]),
                createBaseVNode("textarea", {
                  class: "poly-coords-textarea",
                  readonly: "",
                  value: formattedCoords.value,
                  rows: "3",
                  spellcheck: "false"
                }, null, 8, _hoisted_18),
                createBaseVNode("button", {
                  class: "poly-btn draw-btn poly-coords-copy-btn",
                  onClick: copyCoords
                }, toDisplayString(copied.value ? "已复制 ✓" : "复制"), 1)
              ], 64))
            ], 512), [
              [vShow, exportExpanded.value]
            ])
          ]),
          createBaseVNode("div", null, [
            createBaseVNode("div", {
              class: "poly-import-toggle",
              onClick: _cache[5] || (_cache[5] = ($event) => importExpanded.value = !importExpanded.value)
            }, [
              createBaseVNode("span", {
                class: normalizeClass(["toggle-arrow", { open: importExpanded.value }])
              }, "▶", 2),
              _cache[10] || (_cache[10] = createTextVNode(" 坐标导入 ", -1))
            ]),
            withDirectives(createBaseVNode("div", _hoisted_19, [
              withDirectives(createBaseVNode("textarea", {
                class: "coords-input",
                "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => localCoords.value = $event),
                placeholder: "[lng,lat]\n[[lng,lat],[lng,lat],...]\n或 lng,lat;lng,lat;...",
                rows: "3",
                spellcheck: "false"
              }, null, 512), [
                [vModelText, localCoords.value]
              ]),
              createBaseVNode("div", _hoisted_20, [
                createBaseVNode("button", {
                  class: "poly-btn draw-btn",
                  disabled: !localCoords.value.trim(),
                  onClick: onImport
                }, " 导入 ", 8, _hoisted_21),
                createBaseVNode("button", {
                  class: "poly-btn clear-btn",
                  disabled: !localCoords.value.trim(),
                  onClick: _cache[7] || (_cache[7] = ($event) => localCoords.value = "")
                }, " 清空 ", 8, _hoisted_22)
              ])
            ], 512), [
              [vShow, importExpanded.value]
            ])
          ])
        ]);
      };
    }
  });
  const _hoisted_1$3 = {
    key: 0,
    class: "result-panel"
  };
  const _sfc_main$3 = /* @__PURE__ */ defineComponent({
    __name: "ResultPanel",
    props: {
      activeTool: {},
      segments: {},
      totalLabel: {},
      pointCount: {},
      polygonMode: {},
      drawingPointCount: {},
      polygonLayers: {},
      editingPolygonId: {},
      pointMarkers: {},
      circlePreview: {},
      circlePreviewGeometry: {}
    },
    emits: ["startDrawing", "finishDrawing", "cancelDrawing", "undoPoint", "deleteLayer", "renameLayer", "toggleVisible", "selectLayer", "drawFromText", "startEdit", "finishEdit", "cancelEdit", "updateCircle", "finishCircle", "deletePoint", "renamePoint", "togglePointVisible", "selectPoint", "importPoints"],
    setup(__props, { emit: __emit }) {
      const props = __props;
      const emit2 = __emit;
      const showResult = computed(
        () => props.activeTool !== "" || props.segments.length > 0 || props.pointMarkers.length > 0
      );
      return (_ctx, _cache) => {
        return showResult.value ? (openBlock(), createElementBlock("div", _hoisted_1$3, [
          __props.activeTool === unref(TOOL_IDS).MULTI_POINT || __props.segments.length > 0 && !__props.activeTool ? (openBlock(), createBlock(_sfc_main$7, {
            key: 0,
            segments: __props.segments,
            "total-label": __props.totalLabel,
            "point-count": __props.pointCount
          }, null, 8, ["segments", "total-label", "point-count"])) : __props.activeTool === unref(TOOL_IDS).POLYGON ? (openBlock(), createBlock(_sfc_main$6, {
            key: 1,
            "polygon-mode": __props.polygonMode,
            "drawing-point-count": __props.drawingPointCount,
            "polygon-layers": __props.polygonLayers,
            "editing-polygon-id": __props.editingPolygonId,
            onStartDrawing: _cache[0] || (_cache[0] = ($event) => emit2("startDrawing")),
            onFinishDrawing: _cache[1] || (_cache[1] = ($event) => emit2("finishDrawing")),
            onCancelDrawing: _cache[2] || (_cache[2] = ($event) => emit2("cancelDrawing")),
            onUndoPoint: _cache[3] || (_cache[3] = ($event) => emit2("undoPoint")),
            onDeleteLayer: _cache[4] || (_cache[4] = (id) => emit2("deleteLayer", id)),
            onRenameLayer: _cache[5] || (_cache[5] = (id, name) => emit2("renameLayer", id, name)),
            onToggleVisible: _cache[6] || (_cache[6] = (id) => emit2("toggleVisible", id)),
            onSelectLayer: _cache[7] || (_cache[7] = (id) => emit2("selectLayer", id)),
            onDrawFromText: _cache[8] || (_cache[8] = (input) => emit2("drawFromText", input)),
            onStartEdit: _cache[9] || (_cache[9] = (id) => emit2("startEdit", id)),
            onFinishEdit: _cache[10] || (_cache[10] = ($event) => emit2("finishEdit")),
            onCancelEdit: _cache[11] || (_cache[11] = ($event) => emit2("cancelEdit"))
          }, null, 8, ["polygon-mode", "drawing-point-count", "polygon-layers", "editing-polygon-id"])) : __props.activeTool === unref(TOOL_IDS).CIRCLE ? (openBlock(), createBlock(_sfc_main$5, {
            key: 2,
            "circle-preview": __props.circlePreview,
            "preview-geometry": __props.circlePreviewGeometry,
            onUpdateCircle: _cache[12] || (_cache[12] = (id, r, n) => emit2("updateCircle", id, r, n)),
            onFinishCircle: _cache[13] || (_cache[13] = ($event) => emit2("finishCircle"))
          }, null, 8, ["circle-preview", "preview-geometry"])) : __props.activeTool === unref(TOOL_IDS).POINT_MARKER ? (openBlock(), createBlock(_sfc_main$4, {
            key: 3,
            "point-markers": __props.pointMarkers,
            onDeletePoint: _cache[14] || (_cache[14] = (id) => emit2("deletePoint", id)),
            onRenamePoint: _cache[15] || (_cache[15] = (id, name) => emit2("renamePoint", id, name)),
            onToggleVisible: _cache[16] || (_cache[16] = (id) => emit2("togglePointVisible", id)),
            onSelectPoint: _cache[17] || (_cache[17] = (id, multi) => emit2("selectPoint", id, multi)),
            onImportPoints: _cache[18] || (_cache[18] = (input) => emit2("importPoints", input))
          }, null, 8, ["point-markers"])) : createCommentVNode("", true)
        ])) : createCommentVNode("", true);
      };
    }
  });
  const _hoisted_1$2 = {
    key: 0,
    class: "action-bar"
  };
  const _sfc_main$2 = /* @__PURE__ */ defineComponent({
    __name: "ActionBar",
    props: {
      activeTool: {},
      pointCount: {},
      segments: {}
    },
    emits: ["finish", "undo", "clear"],
    setup(__props, { emit: __emit }) {
      const props = __props;
      const emit2 = __emit;
      const showBar = computed(() => props.activeTool !== TOOL_IDS.POLYGON);
      const hasAnyData = computed(
        () => props.pointCount > 0 || props.segments.length > 0
      );
      return (_ctx, _cache) => {
        return showBar.value ? (openBlock(), createElementBlock("div", _hoisted_1$2, [
          __props.activeTool === unref(TOOL_IDS).MULTI_POINT && __props.pointCount >= 2 ? (openBlock(), createElementBlock("button", {
            key: 0,
            class: "action-btn finish-btn",
            onClick: _cache[0] || (_cache[0] = ($event) => emit2("finish"))
          }, " 完成 ")) : createCommentVNode("", true),
          __props.activeTool === unref(TOOL_IDS).MULTI_POINT && __props.pointCount > 0 ? (openBlock(), createElementBlock("button", {
            key: 1,
            class: "action-btn undo-btn",
            onClick: _cache[1] || (_cache[1] = ($event) => emit2("undo"))
          }, " 撤销 ")) : createCommentVNode("", true),
          hasAnyData.value ? (openBlock(), createElementBlock("button", {
            key: 2,
            class: "action-btn clear-btn",
            onClick: _cache[2] || (_cache[2] = ($event) => emit2("clear"))
          }, " 清除 ")) : createCommentVNode("", true)
        ])) : createCommentVNode("", true);
      };
    }
  });
  const _hoisted_1$1 = { class: "settings-panel" };
  const _hoisted_2$1 = { class: "settings-item" };
  const _hoisted_3 = { class: "settings-item" };
  const _hoisted_4 = ["value"];
  const _sfc_main$1 = /* @__PURE__ */ defineComponent({
    __name: "Settings",
    emits: ["debugChange", "themeChange"],
    setup(__props, { emit: __emit }) {
      function loadSettings() {
        try {
          const raw = localStorage.getItem(SETTINGS_KEY);
          return raw ? JSON.parse(raw) : { debug: false };
        } catch {
          return { debug: false };
        }
      }
      function saveSettings(settings) {
        localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
      }
      const debug = /* @__PURE__ */ ref(loadSettings().debug);
      const theme = /* @__PURE__ */ ref("system");
      onMounted(async () => {
        try {
          const result = await chrome.storage.local.get(THEME_KEY);
          const stored = result[THEME_KEY];
          if (stored === "system" || stored === "light" || stored === "dark") {
            theme.value = stored;
          }
        } catch {
          const local = localStorage.getItem(THEME_KEY);
          if (local === "system" || local === "light" || local === "dark") {
            theme.value = local;
          }
        }
      });
      const emit2 = __emit;
      function onDebugChange() {
        saveSettings({ ...loadSettings(), debug: debug.value });
        emit2("debugChange", debug.value);
      }
      function onThemeChange(e) {
        const val = e.target.value;
        theme.value = val;
        emit2("themeChange", val);
      }
      return (_ctx, _cache) => {
        return openBlock(), createElementBlock("div", _hoisted_1$1, [
          _cache[4] || (_cache[4] = createBaseVNode("div", { class: "settings-title" }, "设置", -1)),
          createBaseVNode("label", _hoisted_2$1, [
            _cache[1] || (_cache[1] = createBaseVNode("span", { class: "settings-item-label" }, "开启调试", -1)),
            withDirectives(createBaseVNode("input", {
              type: "checkbox",
              class: "settings-checkbox",
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => debug.value = $event),
              onChange: onDebugChange
            }, null, 544), [
              [vModelCheckbox, debug.value]
            ])
          ]),
          createBaseVNode("div", _hoisted_3, [
            _cache[3] || (_cache[3] = createBaseVNode("span", { class: "settings-item-label" }, "主题", -1)),
            createBaseVNode("select", {
              class: "settings-select",
              value: theme.value,
              onChange: onThemeChange
            }, [..._cache[2] || (_cache[2] = [
              createBaseVNode("option", { value: "system" }, "跟随系统", -1),
              createBaseVNode("option", { value: "light" }, "亮色", -1),
              createBaseVNode("option", { value: "dark" }, "暗色", -1)
            ])], 40, _hoisted_4)
          ])
        ]);
      };
    }
  });
  const _hoisted_1 = { class: "header-actions" };
  const _hoisted_2 = {
    key: 1,
    class: "coords-display"
  };
  const COLLAPSE_KEY = "__tmh_collapsed__";
  const MINI_Y_KEY = "__tmh_mini_y__";
  const _sfc_main = /* @__PURE__ */ defineComponent({
    __name: "App",
    setup(__props) {
      const {
        isMapReady,
        mapStatus,
        activeTool,
        segments,
        totalLabel,
        pointCount,
        polygonMode,
        drawingPointCount,
        polygonLayers,
        editingPolygonId,
        pointMarkers,
        setTool,
        finish,
        undo,
        clear,
        startDrawingPolygon,
        finishDrawingPolygon,
        cancelDrawingPolygon,
        undoPolygonPoint,
        drawPolygon,
        deletePolygon,
        selectPolygonFromPanel,
        togglePolygonVisible,
        renamePolygon,
        startEditPolygon,
        finishEditPolygon,
        cancelEditPolygon,
        deletePointMarker,
        selectPointMarkerFromPanel,
        togglePointMarkerVisible,
        renamePointMarker,
        importPointMarkers,
        updateCircle,
        finishCircle,
        setDebug,
        mouseCoords,
        circlePreview,
        circlePreviewGeometry
      } = useTool();
      const isCollapsed = /* @__PURE__ */ ref(localStorage.getItem(COLLAPSE_KEY) === "true");
      const statusClass = computed(() => ({
        ready: mapStatus.value === "ready",
        lost: mapStatus.value === "lost",
        restored: mapStatus.value === "restored"
      }));
      const statusText = computed(() => {
        switch (mapStatus.value) {
          case "ready":
            return "已就绪";
          case "lost":
            return "地图已断开";
          case "restored":
            return "已恢复";
          default:
            return "未检测";
        }
      });
      function collapse() {
        isCollapsed.value = true;
        localStorage.setItem(COLLAPSE_KEY, "true");
      }
      function expand() {
        isCollapsed.value = false;
        localStorage.setItem(COLLAPSE_KEY, "false");
      }
      const savedMiniY = localStorage.getItem(MINI_Y_KEY);
      const miniTabY = /* @__PURE__ */ ref(savedMiniY !== null ? Number(savedMiniY) : Math.max(0, window.innerHeight / 2 - 40));
      let miniDragging = false;
      let miniDragOffsetY = 0;
      let miniHasMoved = false;
      function startMiniDrag(e) {
        miniDragging = true;
        miniHasMoved = false;
        miniDragOffsetY = e.clientY - miniTabY.value;
      }
      function onMiniTabClick() {
        if (miniHasMoved) {
          miniHasMoved = false;
          return;
        }
        expand();
      }
      const showSettings = /* @__PURE__ */ ref(false);
      function toggleSettings() {
        showSettings.value = !showSettings.value;
      }
      const posY = /* @__PURE__ */ ref(20);
      let dragging = false;
      let dragOffsetY = 0;
      function startDrag(e) {
        dragging = true;
        dragOffsetY = e.clientY - posY.value;
      }
      function onMouseMove(e) {
        if (dragging) {
          posY.value = Math.max(0, Math.min(window.innerHeight - 100, e.clientY - dragOffsetY));
        }
        if (miniDragging) {
          miniHasMoved = true;
          miniTabY.value = Math.max(0, Math.min(window.innerHeight - 80, e.clientY - miniDragOffsetY));
        }
      }
      function onMouseUp() {
        dragging = false;
        if (miniDragging) {
          localStorage.setItem(MINI_Y_KEY, String(miniTabY.value));
        }
        miniDragging = false;
      }
      function onResize() {
        posY.value = Math.max(0, Math.min(window.innerHeight - 100, posY.value));
      }
      const themePref = /* @__PURE__ */ ref("system");
      const systemDark = window.matchMedia("(prefers-color-scheme: dark)");
      function applyTheme() {
        const host = document.getElementById(HOST_ID);
        if (!host) return;
        const isDark = themePref.value === "system" ? systemDark.matches : themePref.value === "dark";
        host.classList.toggle("theme-light", !isDark);
        host.classList.toggle("theme-dark", isDark);
      }
      async function loadTheme() {
        try {
          const result = await chrome.storage.local.get(THEME_KEY);
          const stored = result[THEME_KEY];
          if (stored === "system" || stored === "light" || stored === "dark") {
            themePref.value = stored;
          }
        } catch {
          const local = localStorage.getItem(THEME_KEY);
          if (local === "system" || local === "light" || local === "dark") {
            themePref.value = local;
          }
        }
        applyTheme();
      }
      function onSystemThemeChange() {
        if (themePref.value === "system") applyTheme();
      }
      function onStorageChanged(changes, area) {
        if (area !== "local") return;
        const c = changes[THEME_KEY];
        if (!c) return;
        const v = c.newValue;
        if (v === "system" || v === "light" || v === "dark") {
          themePref.value = v;
          applyTheme();
        }
      }
      function onThemeChange(theme) {
        themePref.value = theme;
        chrome.storage.local.set({ [THEME_KEY]: theme }).catch(() => {
          localStorage.setItem(THEME_KEY, theme);
        });
        applyTheme();
      }
      onMounted(async () => {
        await loadTheme();
        systemDark.addEventListener("change", onSystemThemeChange);
        chrome.storage.onChanged.addListener(onStorageChanged);
        document.addEventListener("mousemove", onMouseMove);
        document.addEventListener("mouseup", onMouseUp);
        window.addEventListener("resize", onResize);
      });
      onUnmounted(() => {
        systemDark.removeEventListener("change", onSystemThemeChange);
        chrome.storage.onChanged.removeListener(onStorageChanged);
        document.removeEventListener("mousemove", onMouseMove);
        document.removeEventListener("mouseup", onMouseUp);
        window.removeEventListener("resize", onResize);
      });
      return (_ctx, _cache) => {
        return isCollapsed.value ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: "mini-tab",
          style: normalizeStyle({ top: miniTabY.value + "px" }),
          onMousedown: withModifiers(startMiniDrag, ["prevent"]),
          onClick: withModifiers(onMiniTabClick, ["stop"]),
          title: "展开 TMap 工具"
        }, [..._cache[12] || (_cache[12] = [
          createBaseVNode("span", null, "📍", -1),
          createBaseVNode("span", { class: "mini-tab-text" }, "TMap工具", -1)
        ])], 36)) : (openBlock(), createElementBlock("div", {
          key: 1,
          class: "floating-panel",
          style: normalizeStyle({ right: "10px", top: posY.value + "px" })
        }, [
          createBaseVNode("div", {
            class: "panel-header",
            onMousedown: withModifiers(startDrag, ["prevent"])
          }, [
            _cache[13] || (_cache[13] = createBaseVNode("span", { class: "panel-title" }, "📍 TMap 工具", -1)),
            createBaseVNode("div", _hoisted_1, [
              createBaseVNode("span", {
                class: normalizeClass(["map-status", statusClass.value])
              }, toDisplayString(statusText.value), 3),
              createBaseVNode("button", {
                class: normalizeClass(["icon-btn", { active: showSettings.value }]),
                onClick: withModifiers(toggleSettings, ["stop"]),
                title: "设置"
              }, " ⚙️ ", 2),
              createBaseVNode("button", {
                class: "icon-btn",
                onClick: withModifiers(collapse, ["stop"]),
                title: "收起"
              }, " ⟩ ")
            ])
          ], 32),
          showSettings.value ? (openBlock(), createBlock(_sfc_main$1, {
            key: 0,
            onDebugChange: unref(setDebug),
            onThemeChange
          }, null, 8, ["onDebugChange"])) : createCommentVNode("", true),
          createVNode(_sfc_main$8, {
            "active-tool": unref(activeTool),
            "is-map-ready": unref(isMapReady),
            onSelect: unref(setTool)
          }, null, 8, ["active-tool", "is-map-ready", "onSelect"]),
          createVNode(_sfc_main$3, {
            "active-tool": unref(activeTool),
            segments: unref(segments),
            "total-label": unref(totalLabel),
            "point-count": unref(pointCount),
            "polygon-mode": unref(polygonMode),
            "drawing-point-count": unref(drawingPointCount),
            "polygon-layers": unref(polygonLayers),
            "editing-polygon-id": unref(editingPolygonId),
            "point-markers": unref(pointMarkers),
            "circle-preview": unref(circlePreview),
            "circle-preview-geometry": unref(circlePreviewGeometry),
            onStartDrawing: unref(startDrawingPolygon),
            onFinishDrawing: unref(finishDrawingPolygon),
            onCancelDrawing: unref(cancelDrawingPolygon),
            onUndoPoint: unref(undoPolygonPoint),
            onDeleteLayer: _cache[0] || (_cache[0] = (id) => unref(deletePolygon)(id)),
            onRenameLayer: _cache[1] || (_cache[1] = (id, name) => unref(renamePolygon)(id, name)),
            onToggleVisible: _cache[2] || (_cache[2] = (id) => unref(togglePolygonVisible)(id)),
            onSelectLayer: _cache[3] || (_cache[3] = (id) => unref(selectPolygonFromPanel)(id)),
            onDrawFromText: _cache[4] || (_cache[4] = (input) => unref(drawPolygon)(input)),
            onStartEdit: _cache[5] || (_cache[5] = (id) => unref(startEditPolygon)(id)),
            onFinishEdit: unref(finishEditPolygon),
            onCancelEdit: unref(cancelEditPolygon),
            onUpdateCircle: _cache[6] || (_cache[6] = (id, r, n) => unref(updateCircle)(id, r, n)),
            onFinishCircle: unref(finishCircle),
            onDeletePoint: _cache[7] || (_cache[7] = (id) => unref(deletePointMarker)(id)),
            onRenamePoint: _cache[8] || (_cache[8] = (id, name) => unref(renamePointMarker)(id, name)),
            onTogglePointVisible: _cache[9] || (_cache[9] = (id) => unref(togglePointMarkerVisible)(id)),
            onSelectPoint: _cache[10] || (_cache[10] = (id, multi) => unref(selectPointMarkerFromPanel)(id, multi)),
            onImportPoints: _cache[11] || (_cache[11] = (input) => unref(importPointMarkers)(input))
          }, null, 8, ["active-tool", "segments", "total-label", "point-count", "polygon-mode", "drawing-point-count", "polygon-layers", "editing-polygon-id", "point-markers", "circle-preview", "circle-preview-geometry", "onStartDrawing", "onFinishDrawing", "onCancelDrawing", "onUndoPoint", "onFinishEdit", "onCancelEdit", "onFinishCircle"]),
          createVNode(_sfc_main$2, {
            "active-tool": unref(activeTool),
            "point-count": unref(pointCount),
            segments: unref(segments),
            onFinish: unref(finish),
            onUndo: unref(undo),
            onClear: unref(clear)
          }, null, 8, ["active-tool", "point-count", "segments", "onFinish", "onUndo", "onClear"]),
          unref(mouseCoords) ? (openBlock(), createElementBlock("div", _hoisted_2, toDisplayString(unref(mouseCoords).lng.toFixed(6)) + ", " + toDisplayString(unref(mouseCoords).lat.toFixed(6)), 1)) : createCommentVNode("", true)
        ], 4));
      };
    }
  });
  const panelCss = "/* ── CSS 变量（暗色主题默认值） ─────────────────────────────────────────── */\n:host {\n  --c-bg: #1a1a2e;\n  --c-bg-alt: #16213e;\n  --c-bg-input: #12122a;\n  --c-border: #2d2d5e;\n  --c-border-dim: #3a3a5e;\n  --c-text: #e8e8f0;\n  --c-text-dim: #b0b0d0;\n  --c-text-muted: #888;\n  --c-text-label: #666;\n  --c-accent: #FF6B35;\n  --c-accent-bg: rgba(255, 107, 53, 0.08);\n  --c-accent-border: rgba(255, 107, 53, 0.5);\n  --c-blue: #4A90D9;\n  --c-blue-bg: rgba(74, 144, 217, 0.1);\n  --c-blue-border: rgba(74, 144, 217, 0.25);\n  --c-blue-bright: #5c9ce0;\n  --c-green: #4caf80;\n  --c-green-bg: #1a3a2e;\n  --c-red: #e06060;\n  --c-red-bg: #3a1a1a;\n  --c-red-border: #5a2a2a;\n  --c-shadow: rgba(0, 0, 0, 0.5);\n  --c-mono: 'SF Mono', 'Menlo', 'Consolas', monospace;\n}\n\n/* ── 亮色主题变量覆盖 ──────────────────────────────────────────────────── */\n:host(.theme-light) {\n  --c-bg: #f0f2f5;\n  --c-bg-alt: #ffffff;\n  --c-bg-input: #ffffff;\n  --c-border: #d0d5dd;\n  --c-border-dim: #ddd;\n  --c-text: #1a1a2e;\n  --c-text-dim: #555;\n  --c-text-muted: #999;\n  --c-text-label: #777;\n  --c-accent: #e05520;\n  --c-accent-bg: rgba(224, 85, 32, 0.06);\n  --c-accent-border: rgba(224, 85, 32, 0.4);\n  --c-blue: #2563eb;\n  --c-blue-bg: rgba(37, 99, 235, 0.08);\n  --c-blue-border: rgba(37, 99, 235, 0.2);\n  --c-blue-bright: #1d4ed8;\n  --c-green: #16a34a;\n  --c-green-bg: #dcfce7;\n  --c-red: #dc2626;\n  --c-red-bg: #fef2f2;\n  --c-red-border: #fecaca;\n  --c-shadow: rgba(0, 0, 0, 0.12);\n}\n\n*, *::before, *::after {\n  box-sizing: border-box;\n  margin: 0;\n  padding: 0;\n}\n\n/* ── Mini tab (collapsed state) ──────────────────────────────────────────── */\n.mini-tab {\n  position: fixed;\n  z-index: 2147483647;\n  right: 0;\n  background: var(--c-bg);\n  border: 1px solid var(--c-border);\n  border-right: none;\n  border-radius: 8px 0 0 8px;\n  padding: 12px 8px;\n  cursor: grab;\n  color: var(--c-text);\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 5px;\n  font-size: 16px;\n  box-shadow: -4px 0 16px var(--c-shadow);\n  transition: background 0.15s, box-shadow 0.15s;\n  user-select: none;\n}\n\n.mini-tab:active { cursor: grabbing; }\n\n.mini-tab:hover {\n  background: var(--c-bg-alt);\n  box-shadow: -6px 0 20px var(--c-shadow);\n}\n\n.mini-tab-text {\n  font-size: 9px;\n  color: var(--c-text-muted);\n  writing-mode: vertical-rl;\n  letter-spacing: 0.08em;\n}\n\n/* ── Floating panel ──────────────────────────────────────────────────────── */\n.floating-panel {\n  position: fixed;\n  z-index: 2147483647;\n  width: 248px;\n  background: var(--c-bg);\n  border: 1px solid var(--c-border);\n  border-radius: 10px;\n  box-shadow: 0 8px 32px var(--c-shadow);\n  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;\n  font-size: 13px;\n  color: var(--c-text);\n  overflow: hidden;\n  user-select: none;\n}\n\n/* ── Header ──────────────────────────────────────────────────────────────── */\n.panel-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 8px 10px;\n  background: var(--c-bg-alt);\n  cursor: grab;\n  border-bottom: 1px solid var(--c-border);\n  gap: 6px;\n}\n\n.panel-header:active { cursor: grabbing; }\n\n.panel-title {\n  font-weight: 600;\n  font-size: 13px;\n  flex: 1;\n}\n\n.header-actions {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n}\n\n.map-status {\n  font-size: 10px;\n  padding: 2px 6px;\n  border-radius: 10px;\n  background: var(--c-border-dim);\n  color: var(--c-text-muted);\n  white-space: nowrap;\n}\n\n.map-status.ready {\n  background: var(--c-green-bg);\n  color: var(--c-green);\n}\n\n.map-status.lost {\n  background: var(--c-red-bg);\n  color: var(--c-red);\n}\n\n.map-status.restored {\n  background: rgba(74, 144, 217, 0.18);\n  color: var(--c-blue-bright);\n  animation: statusPulse 0.5s ease 2;\n}\n\n@keyframes statusPulse {\n  0%, 100% { opacity: 1; }\n  50% { opacity: 0.5; }\n}\n\n.icon-btn {\n  background: none;\n  border: 1px solid transparent;\n  border-radius: 5px;\n  color: var(--c-text-muted);\n  cursor: pointer;\n  font-size: 14px;\n  padding: 2px 5px;\n  line-height: 1;\n  transition: background 0.12s, color 0.12s;\n}\n\n.icon-btn:hover {\n  background: var(--c-border);\n  color: var(--c-text-dim);\n}\n\n.icon-btn.active {\n  background: var(--c-border);\n  color: var(--c-accent);\n  border-color: var(--c-accent);\n}\n\n/* ── Settings panel ──────────────────────────────────────────────────────── */\n.settings-panel {\n  background: var(--c-bg-input);\n  border-bottom: 1px solid var(--c-border);\n  padding: 10px 12px;\n}\n\n.settings-title {\n  font-size: 11px;\n  color: var(--c-text-muted);\n  text-transform: uppercase;\n  letter-spacing: 0.05em;\n  margin-bottom: 8px;\n}\n\n.settings-item {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  margin-bottom: 6px;\n}\n\n.settings-item:last-child { margin-bottom: 0; }\n\n.settings-item-label {\n  font-size: 12px;\n  color: var(--c-text-dim);\n}\n\n.settings-checkbox {\n  width: 14px;\n  height: 14px;\n  accent-color: var(--c-accent);\n  cursor: pointer;\n}\n\n.settings-select {\n  background: var(--c-bg);\n  border: 1px solid var(--c-border);\n  border-radius: 5px;\n  color: var(--c-text);\n  font-size: 12px;\n  padding: 3px 6px;\n  outline: none;\n  cursor: pointer;\n}\n\n.settings-select:focus {\n  border-color: var(--c-accent);\n}\n\n.settings-hint {\n  font-size: 10px;\n  color: var(--c-text-muted);\n  text-align: center;\n  padding-top: 4px;\n}\n\n/* ── Toolbar ─────────────────────────────────────────────────────────────── */\n.toolbar {\n  display: flex;\n  gap: 5px;\n  padding: 8px 8px 0;\n}\n\n.tool-btn {\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  align-items: center;\n  gap: 3px;\n  padding: 7px 2px;\n  background: var(--c-bg-alt);\n  border: 1px solid var(--c-border);\n  border-radius: 8px;\n  color: var(--c-text-dim);\n  cursor: pointer;\n  transition: background 0.15s, border-color 0.15s, color 0.15s;\n  font-size: 11px;\n  line-height: 1.2;\n}\n\n.tool-btn:hover:not(.disabled) {\n  background: rgba(74, 144, 217, 0.15);\n  border-color: var(--c-blue);\n  color: var(--c-text);\n}\n\n.tool-btn.active {\n  background: rgba(74, 144, 217, 0.18);\n  border-color: var(--c-accent);\n  color: var(--c-accent);\n}\n\n.tool-btn.disabled {\n  opacity: 0.4;\n  cursor: not-allowed;\n}\n\n.tool-icon { font-size: 16px; line-height: 1; }\n\n.tool-name { font-size: 10px; white-space: nowrap; }\n\n/* ── Result panel ────────────────────────────────────────────────────────── */\n.result-panel {\n  padding: 10px;\n  border-top: 1px solid var(--c-border);\n  margin-top: 8px;\n}\n\n.result-block {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n\n.result-hint {\n  color: var(--c-text-muted);\n  font-size: 11px;\n  text-align: center;\n  padding: 4px 0;\n}\n\n.result-distance {\n  display: flex;\n  align-items: baseline;\n  justify-content: space-between;\n}\n\n.result-label { color: var(--c-text-muted); font-size: 11px; }\n\n.result-value {\n  font-size: 18px;\n  font-weight: 700;\n  color: var(--c-accent);\n}\n\n/* ── Segment list ────────────────────────────────────────────────────────── */\n.segment-list {\n  display: flex;\n  flex-direction: column;\n  gap: 3px;\n  max-height: 140px;\n  overflow-y: auto;\n}\n\n.segment-list::-webkit-scrollbar { width: 4px; }\n.segment-list::-webkit-scrollbar-thumb {\n  background: var(--c-border);\n  border-radius: 2px;\n}\n\n.segment-row {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 3px 4px;\n  border-radius: 4px;\n  background: var(--c-bg-alt);\n}\n\n.segment-row.segment-total {\n  border-top: 1px solid var(--c-border);\n  margin-top: 2px;\n  background: transparent;\n}\n\n.seg-idx { color: var(--c-text-muted); font-size: 11px; }\n\n.seg-dist { color: var(--c-accent); font-size: 12px; font-weight: 600; }\n\n.segment-total .seg-idx { color: var(--c-text-dim); font-weight: 600; }\n.segment-total .seg-dist { font-size: 14px; }\n\n/* ── Polygon panel ───────────────────────────────────────────────────────── */\n.polygon-panel {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n\n.poly-mode-bar {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  gap: 6px;\n}\n\n.poly-mode-badge {\n  font-size: 10px;\n  padding: 2px 8px;\n  border-radius: 8px;\n  font-weight: 500;\n  flex-shrink: 0;\n}\n\n.poly-mode-badge.idle {\n  background: var(--c-border);\n  color: var(--c-text-muted);\n}\n\n.poly-mode-badge.drawing {\n  background: var(--c-accent-bg);\n  color: var(--c-accent);\n  border: 1px solid var(--c-accent-border);\n  animation: poly-pulse 1.6s ease infinite;\n}\n\n.poly-mode-badge.editing {\n  background: var(--c-blue-bg);\n  color: var(--c-blue);\n  border: 1px solid var(--c-blue-border);\n}\n\n@keyframes poly-pulse {\n  0%, 100% { opacity: 1; }\n  50% { opacity: 0.55; }\n}\n\n.poly-new-btn {\n  flex: 1;\n  padding: 4px 8px;\n  border-radius: 5px;\n  border: 1px solid var(--c-accent);\n  background: transparent;\n  color: var(--c-accent);\n  font-size: 11px;\n  font-weight: 500;\n  cursor: pointer;\n  transition: background 0.15s;\n  white-space: nowrap;\n}\n\n.poly-new-btn:hover:not(:disabled) { background: rgba(255, 107, 53, 0.15); }\n\n.poly-new-btn:disabled { opacity: 0.35; cursor: not-allowed; }\n\n.poly-draw-controls {\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n  padding: 7px 8px;\n  background: var(--c-accent-bg);\n  border: 1px solid var(--c-accent-border);\n  border-radius: 6px;\n}\n\n.poly-draw-hint {\n  font-size: 10px;\n  color: var(--c-accent);\n  opacity: 0.75;\n  text-align: center;\n}\n\n.poly-draw-actions { display: flex; gap: 4px; }\n\n.poly-btn {\n  flex: 1;\n  padding: 4px 2px;\n  border-radius: 5px;\n  border: 1px solid transparent;\n  font-size: 11px;\n  cursor: pointer;\n  font-weight: 500;\n  transition: opacity 0.15s;\n  white-space: nowrap;\n}\n\n.poly-btn:disabled { opacity: 0.35; cursor: not-allowed; }\n.poly-btn:not(:disabled):hover { opacity: 0.82; }\n\n.draw-btn { background: var(--c-accent); color: #fff; border-color: var(--c-accent); }\n\n.undo-poly-btn {\n  background: var(--c-border);\n  color: var(--c-text-dim);\n  border-color: var(--c-border-dim);\n}\n\n.cancel-btn { background: var(--c-red-bg); color: var(--c-red); border-color: var(--c-red-border); }\n\n.clear-btn { background: var(--c-border); color: var(--c-text-dim); border-color: var(--c-border-dim); }\n\n/* 图层列表 */\n.poly-layers { display: flex; flex-direction: column; gap: 5px; }\n\n.poly-layers-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  color: var(--c-text-label);\n  font-size: 10px;\n  text-transform: uppercase;\n  letter-spacing: 0.05em;\n}\n\n.poly-layer-count {\n  background: var(--c-border);\n  padding: 1px 6px;\n  border-radius: 8px;\n  color: var(--c-text-muted);\n  font-size: 10px;\n}\n\n.poly-layer-list {\n  max-height: 148px;\n  overflow-y: auto;\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n}\n\n.poly-layer-list::-webkit-scrollbar { width: 4px; }\n.poly-layer-list::-webkit-scrollbar-thumb {\n  background: var(--c-border);\n  border-radius: 2px;\n}\n\n.poly-layer-empty {\n  text-align: center;\n  color: var(--c-text-label);\n  font-size: 11px;\n  padding: 12px 0;\n}\n\n.poly-layer-item {\n  display: flex;\n  align-items: center;\n  gap: 5px;\n  padding: 5px 6px;\n  border-radius: 5px;\n  cursor: pointer;\n  background: var(--c-bg-alt);\n  border: 1px solid transparent;\n  transition: background 0.12s, border-color 0.12s;\n}\n\n.poly-layer-item:hover { background: rgba(74, 144, 217, 0.08); }\n\n.poly-layer-item.selected {\n  background: var(--c-blue-bg);\n  border-color: var(--c-blue);\n}\n\n.poly-layer-item.hidden-layer { opacity: 0.45; }\n\n.poly-layer-vis {\n  background: none;\n  border: none;\n  cursor: pointer;\n  font-size: 12px;\n  flex-shrink: 0;\n}\n\n.poly-name-input {\n  flex: 1;\n  background: var(--c-bg-input);\n  border: 1px solid var(--c-blue);\n  border-radius: 4px;\n  color: var(--c-text);\n  font-size: 11px;\n  padding: 2px 4px;\n  outline: none;\n  min-width: 0;\n}\n\n.poly-layer-name {\n  flex: 1;\n  font-size: 11px;\n  color: var(--c-text-dim);\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  min-width: 0;\n}\n\n.poly-layer-actions { display: flex; gap: 2px; flex-shrink: 0; }\n\n.poly-layer-edit,\n.poly-layer-edit-done,\n.poly-layer-edit-cancel,\n.poly-layer-del {\n  background: none;\n  border: none;\n  cursor: pointer;\n  font-size: 12px;\n  padding: 2px 3px;\n  border-radius: 3px;\n  transition: background 0.12s;\n}\n\n.poly-layer-edit { color: var(--c-text-muted); }\n.poly-layer-edit:hover { background: var(--c-border); color: var(--c-text); }\n.poly-layer-edit:disabled { opacity: 0.3; cursor: not-allowed; }\n\n.poly-layer-edit-done { color: var(--c-green); }\n.poly-layer-edit-done:hover { background: var(--c-green-bg); }\n\n.poly-layer-edit-cancel { color: var(--c-red); }\n.poly-layer-edit-cancel:hover { background: var(--c-red-bg); }\n\n.poly-layer-del { color: var(--c-text-muted); }\n.poly-layer-del:hover { background: var(--c-red-bg); color: var(--c-red); }\n.poly-layer-del:disabled { opacity: 0.3; cursor: not-allowed; }\n\n/* 坐标导出 */\n.poly-coords-export {\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n  padding-top: 4px;\n  border-top: 1px solid var(--c-border);\n}\n\n.poly-coords-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  font-size: 10px;\n  color: var(--c-text-label);\n  text-transform: uppercase;\n  letter-spacing: 0.05em;\n}\n\n.poly-coords-fmt-bar { display: flex; gap: 2px; }\n\n.poly-coords-fmt-btn {\n  background: var(--c-bg-alt);\n  border: 1px solid var(--c-border);\n  border-radius: 4px;\n  color: var(--c-text-muted);\n  font-size: 9px;\n  padding: 1px 6px;\n  cursor: pointer;\n  transition: background 0.12s, color 0.12s;\n}\n\n.poly-coords-fmt-btn:hover { color: var(--c-text); }\n.poly-coords-fmt-btn.active {\n  background: var(--c-accent);\n  color: #fff;\n  border-color: var(--c-accent);\n}\n\n.poly-coords-textarea {\n  background: var(--c-bg-input);\n  border: 1px solid var(--c-border);\n  border-radius: 5px;\n  color: var(--c-text);\n  font-size: 10px;\n  font-family: var(--c-mono);\n  padding: 6px 8px;\n  resize: vertical;\n  outline: none;\n}\n\n.poly-coords-copy-btn { padding: 5px 0; }\n\n/* 坐标导入 */\n.poly-import-toggle {\n  display: flex;\n  align-items: center;\n  gap: 5px;\n  font-size: 10px;\n  color: var(--c-text-label);\n  text-transform: uppercase;\n  letter-spacing: 0.05em;\n  cursor: pointer;\n  user-select: none;\n}\n\n.toggle-arrow { font-size: 8px; transition: transform 0.15s; }\n.toggle-arrow.open { transform: rotate(90deg); }\n\n.poly-import-body {\n  margin-top: 6px;\n  display: flex;\n  flex-direction: column;\n  gap: 6px;\n}\n\n.coords-input {\n  background: var(--c-bg-input);\n  border: 1px solid var(--c-border);\n  border-radius: 5px;\n  color: var(--c-text);\n  font-size: 10px;\n  font-family: var(--c-mono);\n  padding: 6px 8px;\n  resize: vertical;\n  outline: none;\n}\n\n.polygon-actions { display: flex; gap: 4px; }\n\n/* ── Action bar ──────────────────────────────────────────────────────────── */\n.action-bar {\n  display: flex;\n  gap: 5px;\n  padding: 8px 10px 10px;\n  border-top: 1px solid var(--c-border);\n}\n\n.action-btn {\n  flex: 1;\n  padding: 6px 4px;\n  border-radius: 5px;\n  border: 1px solid transparent;\n  font-size: 12px;\n  cursor: pointer;\n  font-weight: 500;\n  transition: opacity 0.15s;\n}\n\n.action-btn:hover { opacity: 0.85; }\n\n.finish-btn { background: var(--c-accent); color: #fff; border-color: var(--c-accent); }\n\n.undo-btn {\n  background: var(--c-border);\n  color: var(--c-text-dim);\n  border-color: var(--c-border-dim);\n}\n\n.action-bar .clear-btn {\n  background: var(--c-red-bg);\n  color: var(--c-red);\n  border-color: var(--c-red-border);\n}\n\n/* ── Point Panel ─────────────────────────────────────────────────────────── */\n.point-panel { display: flex; flex-direction: column; gap: 8px; }\n\n.point-hint {\n  font-size: 11px;\n  color: var(--c-text-dim);\n  text-align: center;\n  padding: 6px 8px;\n  background: var(--c-accent-bg);\n  border: 1px dashed var(--c-accent-border);\n  border-radius: 4px;\n}\n\n.point-sel-badge {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  min-width: 16px;\n  height: 16px;\n  padding: 0 4px;\n  margin-left: 4px;\n  background: var(--c-accent);\n  color: #fff;\n  font-size: 10px;\n  border-radius: 8px;\n  vertical-align: middle;\n}\n\n/* ── Polygon geometry info ───────────────────────────────────────────────── */\n.poly-geometry-info {\n  display: flex;\n  gap: 10px;\n  padding: 6px 8px;\n  margin-bottom: 6px;\n  background: var(--c-blue-bg);\n  border: 1px solid var(--c-blue-border);\n  border-radius: 6px;\n}\n\n.poly-geometry-item {\n  font-size: 12px;\n  font-weight: 600;\n  color: var(--c-blue);\n}\n\n/* ── Mouse coordinate display ────────────────────────────────────────────── */\n.coords-display {\n  padding: 4px 10px;\n  background: var(--c-bg-alt);\n  border-top: 1px solid var(--c-border);\n  font-size: 11px;\n  font-family: var(--c-mono);\n  color: var(--c-blue-bright);\n  text-align: center;\n  letter-spacing: 0.03em;\n}\n\n/* ── Circle Panel ────────────────────────────────────────────────────────── */\n.circle-panel { display: flex; flex-direction: column; gap: 8px; }\n\n.circle-hint {\n  font-size: 11px;\n  color: var(--c-text-dim);\n  text-align: center;\n  padding: 8px;\n}\n\n.circle-preview { display: flex; flex-direction: column; gap: 8px; }\n\n.circle-center-info { display: flex; align-items: center; gap: 8px; }\n\n.circle-label {\n  font-size: 10px;\n  color: var(--c-text-label);\n  text-transform: uppercase;\n  letter-spacing: 0.05em;\n}\n\n.circle-coords {\n  font-size: 12px;\n  font-family: var(--c-mono);\n  color: var(--c-blue-bright);\n  background: var(--c-blue-bg);\n  padding: 2px 8px;\n  border-radius: 4px;\n}\n\n.circle-param { display: flex; flex-direction: column; gap: 4px; }\n\n.circle-param-label {\n  font-size: 10px;\n  color: var(--c-text-muted);\n  text-transform: uppercase;\n  letter-spacing: 0.05em;\n}\n\n.circle-param-row { display: flex; align-items: center; gap: 6px; }\n\n.circle-slider { flex: 1; accent-color: var(--c-blue); height: 6px; }\n\n.circle-number {\n  width: 70px;\n  background: var(--c-bg-input);\n  border: 1px solid var(--c-border);\n  border-radius: 5px;\n  color: var(--c-text);\n  font-size: 12px;\n  padding: 3px 6px;\n  text-align: right;\n  outline: none;\n  font-family: var(--c-mono);\n}\n\n.circle-number:focus { border-color: var(--c-blue); }\n\n.circle-unit { font-size: 11px; color: var(--c-text-muted); min-width: 14px; }\n\n.circle-select {\n  background: var(--c-bg-input);\n  border: 1px solid var(--c-border);\n  border-radius: 5px;\n  color: var(--c-text);\n  font-size: 12px;\n  padding: 4px 6px;\n  outline: none;\n}\n\n.circle-select:focus { border-color: var(--c-blue); }\n\n.circle-geometry-info {\n  display: flex;\n  gap: 10px;\n  padding: 6px 8px;\n  background: var(--c-blue-bg);\n  border: 1px solid var(--c-blue-border);\n  border-radius: 6px;\n  font-size: 12px;\n  font-weight: 600;\n  color: var(--c-blue);\n}\n\n.circle-finish-btn {\n  padding: 6px 12px;\n  border-radius: 5px;\n  border: 1px solid var(--c-blue);\n  background: var(--c-blue);\n  color: #fff;\n  font-size: 12px;\n  font-weight: 600;\n  cursor: pointer;\n  transition: opacity 0.15s;\n}\n\n.circle-finish-btn:hover { opacity: 0.85; }\n";
  const DEFAULT_WHITELIST = ["lbs.qq.com"];
  let vueApp = null;
  async function isWhitelisted() {
    try {
      const result = await chrome.storage.local.get("whitelist");
      const wl = Array.isArray(result.whitelist) ? result.whitelist : DEFAULT_WHITELIST;
      return wl.some((d) => location.hostname.includes(d));
    } catch {
      return true;
    }
  }
  function mount() {
    if (document.getElementById(HOST_ID)) return;
    const host = document.createElement("div");
    host.id = HOST_ID;
    document.body.appendChild(host);
    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = panelCss;
    shadow.appendChild(style);
    const mountPoint = document.createElement("div");
    shadow.appendChild(mountPoint);
    vueApp = createApp(_sfc_main);
    vueApp.mount(mountPoint);
  }
  function unmount() {
    var _a;
    vueApp == null ? void 0 : vueApp.unmount();
    vueApp = null;
    (_a = document.getElementById(HOST_ID)) == null ? void 0 : _a.remove();
  }
  async function syncMount() {
    const allowed = await isWhitelisted();
    const mounted = !!document.getElementById(HOST_ID);
    if (allowed && !mounted) mount();
    else if (!allowed && mounted) unmount();
  }
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && "whitelist" in changes) syncMount();
  });
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if ((msg == null ? void 0 : msg.type) === "PING") {
      sendResponse({ type: "PONG" });
      return true;
    }
  });
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", syncMount);
  } else {
    syncMount();
  }
})();
