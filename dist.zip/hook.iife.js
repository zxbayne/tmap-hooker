(function() {
  "use strict";
  const SETTINGS_KEY = "__tmh_settings__";
  let debugEnabled = false;
  function initLogger() {
    try {
      const raw = localStorage.getItem(SETTINGS_KEY);
      debugEnabled = raw ? JSON.parse(raw).debug === true : false;
    } catch {
      debugEnabled = false;
    }
  }
  function setDebug(enabled) {
    debugEnabled = enabled;
  }
  function log(...args) {
    if (debugEnabled) console.log("[TMapHooker]", ...args);
  }
  class OverlayManager {
    constructor(map, TMap) {
      this.markerLayer = null;
      this.polylineLayer = null;
      this.labelMarkers = /* @__PURE__ */ new Map();
      this.polygonLayer = null;
      this.rubberBandLayer = null;
      this.pointMarkerLayer = null;
      this.pointLabelLayer = null;
      this.markers = /* @__PURE__ */ new Map();
      this.polylines = /* @__PURE__ */ new Map();
      this.polygons = /* @__PURE__ */ new Map();
      this.previewPaths = null;
      this.rubberBands = /* @__PURE__ */ new Map();
      this.pointMarkers = /* @__PURE__ */ new Map();
      this.pointMarkerNames = /* @__PURE__ */ new Map();
      this.pointMarkerVisible = /* @__PURE__ */ new Map();
      this.highlightedPointId = null;
      this.polygonVisible = /* @__PURE__ */ new Map();
      this.highlightedId = null;
      this.onPolygonClick = null;
      this.onPolygonMousedown = null;
      this.onCircleClick = null;
      this.onCircleMousedown = null;
      this._mousedownAttached = false;
      this.measurePolylineLayer = null;
      this.measureMarkerLayer = null;
      this.measureLabelMarkers = /* @__PURE__ */ new Map();
      this.measures = /* @__PURE__ */ new Map();
      this.measureVisible = /* @__PURE__ */ new Map();
      this.highlightedMeasureId = null;
      this.onMeasureClick = null;
      this.map = map;
      this.TMap = TMap;
    }
    // ── Markers ──────────────────────────────────────────────────────────────
    ensureMarkerLayer() {
      if (this.markerLayer) return;
      this.markerLayer = new this.TMap.MultiMarker({
        id: "tmap-hooker-markers",
        map: this.map,
        styles: {
          default: new this.TMap.MarkerStyle({
            width: 14,
            height: 14,
            anchor: { x: 7, y: 7 },
            src: this._hollowCircleSvg()
          })
        },
        geometries: []
      });
    }
    /** 统一的 add-or-update 操作：track 有记录则 update，否则 add 并记录。 */
    _upsert(layer, track, id, geometry) {
      if (track.has(id)) {
        layer.updateGeometries([geometry]);
      } else {
        layer.add([geometry]);
        track.set(id, true);
      }
    }
    addMarker(id, latlng, label = "") {
      this.ensureMarkerLayer();
      const geometry = {
        id,
        styleId: "default",
        position: new this.TMap.LatLng(latlng.lat, latlng.lng)
      };
      this._upsert(this.markerLayer, this.markers, id, geometry);
    }
    removeMarker(id) {
      if (!this.markerLayer || !this.markers.has(id)) return;
      this.markerLayer.remove([id]);
      this.markers.delete(id);
    }
    // ── Polylines ─────────────────────────────────────────────────────────────
    ensurePolylineLayer() {
      if (this.polylineLayer) return;
      this.polylineLayer = new this.TMap.MultiPolyline({
        id: "tmap-hooker-lines",
        map: this.map,
        styles: {
          default: new this.TMap.PolylineStyle({
            color: "#4A90D9",
            width: 2,
            lineCap: "butt",
            dashArray: [10, 6]
          })
        },
        geometries: []
      });
    }
    setPolyline(id, points) {
      if (points.length < 2) return;
      this.ensurePolylineLayer();
      const path = points.map((p) => new this.TMap.LatLng(p.lat, p.lng));
      this._upsert(this.polylineLayer, this.polylines, id, { id, styleId: "default", paths: path });
    }
    removePolyline(id) {
      if (!this.polylineLayer || !this.polylines.has(id)) return;
      this.polylineLayer.remove([id]);
      this.polylines.delete(id);
    }
    // ── Labels (per-marker with SVG cards) ────────────────────────────────────
    addLabel(id, latlng, text, _styleId = "default") {
      if (this.labelMarkers.has(id)) {
        this.labelMarkers.get(id).setMap(null);
      }
      const svg = this._labelCardSvg(text);
      const w = this._labelCardWidth(text);
      const layer = new this.TMap.MultiMarker({
        map: this.map,
        styles: {
          default: new this.TMap.MarkerStyle({
            width: w,
            height: 24,
            anchor: { x: Math.round(w / 2), y: 30 },
            // 标签底部在坐标点上方 6px
            src: svg
          })
        },
        geometries: [{
          id,
          styleId: "default",
          position: new this.TMap.LatLng(latlng.lat, latlng.lng)
        }]
      });
      this.labelMarkers.set(id, layer);
    }
    removeLabel(id) {
      const marker = this.labelMarkers.get(id);
      if (!marker) return;
      marker.setMap(null);
      this.labelMarkers.delete(id);
    }
    // ── Polygons ──────────────────────────────────────────────────────────────
    _attachMousedownHandler() {
      if (this._mousedownAttached || !this.polygonLayer) {
        log("[overlay] _attachMousedownHandler SKIP — attached:", this._mousedownAttached, "layer:", !!this.polygonLayer);
        return;
      }
      this._mousedownAttached = true;
      log("[overlay] _attachMousedownHandler DONE — mousedown listener registered");
      this.polygonLayer.on("mousedown", (evt) => {
        var _a, _b, _c;
        const id = (_a = evt.geometry) == null ? void 0 : _a.id;
        log("[overlay] mousedown event:", id, "circleCb:", !!this.onCircleMousedown, "polyCb:", !!this.onPolygonMousedown);
        if (!id) return;
        (_b = evt.originalEvent) == null ? void 0 : _b.stopPropagation();
        if (id.startsWith("circle-") && this.onCircleMousedown) {
          this.onCircleMousedown(id, evt.latLng);
          return;
        }
        (_c = this.onPolygonMousedown) == null ? void 0 : _c.call(this, id, evt.latLng);
      });
    }
    ensurePolygonLayer(onClickCb, onMousedownCb, initialGeometries) {
      if (this.polygonLayer) {
        if (onMousedownCb) this.onPolygonMousedown = onMousedownCb;
        this._attachMousedownHandler();
        if (initialGeometries && initialGeometries.length > 0) {
          this.polygonLayer.add(initialGeometries);
        }
        return;
      }
      this.polygonLayer = new this.TMap.MultiPolygon({
        id: "tmap-hooker-polygons",
        map: this.map,
        styles: {
          default: new this.TMap.PolygonStyle({
            color: "rgba(74, 144, 217, 0.18)",
            borderColor: "#4A90D9",
            borderWidth: 2,
            borderDashArray: [0, 0]
          }),
          highlight: new this.TMap.PolygonStyle({
            color: "rgba(74, 144, 217, 0.30)",
            borderColor: "#2B6CB0",
            borderWidth: 3,
            borderDashArray: [0, 0]
          }),
          /** 绘制中的实时预览多边形，使用更低透明度以区分已提交的多边形。 */
          preview: new this.TMap.PolygonStyle({
            color: "rgba(74, 144, 217, 0.12)",
            borderColor: "rgba(74, 144, 217, 0.7)",
            borderWidth: 2,
            borderDashArray: [8, 6]
          }),
          /** 隐藏样式：完全透明，用于实现单个多边形的可见性切换。 */
          hidden: new this.TMap.PolygonStyle({
            color: "rgba(0,0,0,0)",
            borderColor: "rgba(0,0,0,0)",
            borderWidth: 1,
            borderDashArray: [0, 0]
          })
        },
        geometries: initialGeometries ?? []
      });
      this.onPolygonClick = onClickCb;
      this.polygonLayer.on("click", (evt) => {
        var _a, _b;
        const id = (_a = evt.geometry) == null ? void 0 : _a.id;
        if (!id) return;
        if (id.startsWith("circle-") && this.onCircleClick) {
          this.onCircleClick(id);
          return;
        }
        (_b = this.onPolygonClick) == null ? void 0 : _b.call(this, id);
      });
      this.polygonLayer.setZIndex(9999);
      if (onMousedownCb) {
        this.onPolygonMousedown = onMousedownCb;
      }
      this._attachMousedownHandler();
    }
    _closedPath(points) {
      const closed = [...points];
      const first = closed[0];
      const last = closed[closed.length - 1];
      if (first.lat !== last.lat || first.lng !== last.lng) closed.push(first);
      return closed.map((p) => new this.TMap.LatLng(p.lat, p.lng));
    }
    /**
     * 在地图上添加或更新真实多边形（非预览）。
     * auto-close：自动追加第一个点到末尾以闭合路径。
     */
    addPolygon(id, points, onClickCb, onMousedownCb) {
      this.ensurePolygonLayer(onClickCb, onMousedownCb);
      if (onMousedownCb) this.setPolygonMousedownHandler(onMousedownCb);
      const path = this._closedPath(points);
      const geometry = { id, styleId: "default", paths: [path] };
      if (this.polygons.has(id)) {
        this.polygonLayer.updateGeometries([geometry]);
      } else {
        this.polygonLayer.add([geometry]);
      }
      this.polygons.set(id, [path]);
      this.polygonVisible.set(id, true);
    }
    removePolygon(id) {
      if (!this.polygonLayer || !this.polygons.has(id)) return;
      this.polygonLayer.remove([id]);
      this.polygons.delete(id);
      this.polygonVisible.delete(id);
      if (this.highlightedId === id) this.highlightedId = null;
    }
    /** 实时更新多边形路径，用于拖拽过程中的位置预览。不更新 polygons 缓存，由调用方在拖拽结束后调 addPolygon 提交。 */
    updatePolygonPath(id, points) {
      if (!this.polygonLayer) return;
      this.polygonLayer.updateGeometries([{ id, styleId: "highlight", paths: [this._closedPath(points)] }]);
    }
    /**
     * 添加或更新绘制中的预览多边形（使用 preview 样式，不参与高亮/可见性管理）。
     * 预览多边形不写入 polygons / polygonVisible，因此 setPolygonHighlight 会自动跳过它。
     */
    setPreviewPolygon(id, points, onClickCb, onMousedownCb) {
      if (points.length < 3) return;
      this.ensurePolygonLayer(onClickCb, onMousedownCb);
      const geometry = { id, styleId: "preview", paths: [this._closedPath(points)] };
      if (this.previewPaths !== null) {
        this.polygonLayer.updateGeometries([geometry]);
      } else {
        this.polygonLayer.add([geometry]);
      }
      this.previewPaths = [];
    }
    /** 移除预览多边形。 */
    removePreviewPolygon(id) {
      if (!this.polygonLayer || this.previewPaths === null) return;
      this.polygonLayer.remove([id]);
      this.previewPaths = null;
    }
    /**
     * 切换多边形高亮：将新 id 设为 highlight，将前一个高亮的多边形恢复 default。
     * 传入 null 则只清除当前高亮。只需更新最多 2 个几何体（O(1)）。
     */
    setPolygonHighlight(id) {
      if (!this.polygonLayer || this.polygons.size === 0) return;
      const prev = this.highlightedId;
      this.highlightedId = id;
      const updates = [];
      if (prev !== null && prev !== id) {
        const paths = this.polygons.get(prev);
        if (paths && this.polygonVisible.get(prev) !== false) {
          updates.push({ id: prev, styleId: "default", paths });
        }
      }
      if (id !== null) {
        const paths = this.polygons.get(id);
        if (paths && this.polygonVisible.get(id) !== false) {
          updates.push({ id, styleId: "highlight", paths });
        }
      }
      if (updates.length > 0) {
        this.polygonLayer.updateGeometries(updates);
      }
    }
    /**
     * 切换指定多边形的可见性（通过切换 styleId 到 hidden 实现，避免 remove/re-add）。
     */
    setPolygonVisible(id, visible) {
      if (!this.polygonLayer || !this.polygons.has(id)) return;
      this.polygonVisible.set(id, visible);
      const paths = this.polygons.get(id);
      const styleId = !visible ? "hidden" : this.highlightedId === id ? "highlight" : "default";
      this.polygonLayer.updateGeometries([{ id, styleId, paths }]);
    }
    // ── Rubber band ───────────────────────────────────────────────────────────
    /** 懒初始化橡皮筋线图层（绘制预览专用，样式区别于测量折线）。 */
    ensureRubberBandLayer() {
      if (this.rubberBandLayer) return;
      this.rubberBandLayer = new this.TMap.MultiPolyline({
        id: "tmap-hooker-rubberband",
        map: this.map,
        styles: {
          default: new this.TMap.PolylineStyle({
            color: "#4A90D9",
            width: 2,
            lineCap: "butt",
            dashArray: [10, 6]
          })
        },
        geometries: []
      });
      this.rubberBandLayer.setZIndex(9996);
    }
    /**
     * 添加或更新橡皮筋预览线。
     * points 为全部已打点 + 鼠标当前位置，至少 2 个点才有效。
     */
    setRubberBand(id, points) {
      if (points.length < 2) return;
      this.ensureRubberBandLayer();
      const path = points.map((p) => new this.TMap.LatLng(p.lat, p.lng));
      this._upsert(this.rubberBandLayer, this.rubberBands, id, { id, styleId: "default", paths: path });
    }
    removeRubberBand(id) {
      if (!this.rubberBandLayer || !this.rubberBands.has(id)) return;
      this.rubberBandLayer.remove([id]);
      this.rubberBands.delete(id);
    }
    // ── Point Markers (persistent) ───────────────────────────────────────────
    ensurePointMarkerLayer(initialGeometries) {
      if (this.pointMarkerLayer) {
        if (initialGeometries && initialGeometries.length > 0) {
          this.pointMarkerLayer.add(initialGeometries);
        }
        return;
      }
      this.pointMarkerLayer = new this.TMap.MultiMarker({
        id: "tmap-hooker-point-markers",
        map: this.map,
        styles: {
          default: new this.TMap.MarkerStyle({
            width: 24,
            height: 30,
            anchor: { x: 12, y: 30 },
            src: this._pinDefaultSvg()
          }),
          highlight: new this.TMap.MarkerStyle({
            width: 24,
            height: 30,
            anchor: { x: 12, y: 30 },
            src: this._pinHighlightSvg()
          }),
          hidden: new this.TMap.MarkerStyle({
            width: 1,
            height: 1,
            anchor: { x: 0, y: 0 },
            src: this._pinSvg("rgba(0,0,0,0)")
          })
        },
        geometries: initialGeometries ?? []
      });
      this.pointMarkerLayer.setZIndex(9998);
    }
    ensurePointLabelLayer(initialGeometries) {
      if (this.pointLabelLayer) {
        if (initialGeometries && initialGeometries.length > 0) {
          this.pointLabelLayer.add(initialGeometries);
        }
        return;
      }
      this.pointLabelLayer = new this.TMap.MultiLabel({
        id: "tmap-hooker-point-labels",
        map: this.map,
        styles: {
          default: new this.TMap.LabelStyle({
            color: "#4A90D9",
            size: 14,
            angle: 0,
            offset: { x: 0, y: 6 }
          }),
          highlight: new this.TMap.LabelStyle({
            color: "#FF3500",
            size: 14,
            angle: 0,
            offset: { x: 0, y: 6 }
          }),
          hidden: new this.TMap.LabelStyle({
            color: "rgba(0,0,0,0)",
            size: 1,
            offset: { x: 0, y: 0 }
          })
        },
        geometries: initialGeometries ?? []
      });
      this.pointLabelLayer.setZIndex(9997);
    }
    addPointMarker(id, latlng, name) {
      this.ensurePointMarkerLayer();
      this.ensurePointLabelLayer();
      const pos = new this.TMap.LatLng(latlng.lat, latlng.lng);
      const styleId = this.highlightedPointId === id ? "highlight" : "default";
      const markerGeo = { id, styleId, position: pos };
      if (this.pointMarkers.has(id)) {
        this.pointMarkerLayer.updateGeometries([markerGeo]);
        this.pointLabelLayer.updateGeometries([{ id, styleId, position: pos, content: name }]);
      } else {
        this.pointMarkerLayer.add([markerGeo]);
        this.pointLabelLayer.add([{ id, styleId, position: pos, content: name }]);
      }
      this.pointMarkers.set(id, latlng);
      this.pointMarkerNames.set(id, name);
      this.pointMarkerVisible.set(id, true);
    }
    removePointMarker(id) {
      var _a;
      if (!this.pointMarkerLayer || !this.pointMarkers.has(id)) return;
      this.pointMarkerLayer.remove([id]);
      (_a = this.pointLabelLayer) == null ? void 0 : _a.remove([id]);
      this.pointMarkers.delete(id);
      this.pointMarkerNames.delete(id);
      this.pointMarkerVisible.delete(id);
      if (this.highlightedPointId === id) this.highlightedPointId = null;
    }
    updatePointMarkerName(id, name) {
      if (!this.pointLabelLayer || !this.pointMarkers.has(id)) return;
      this.pointMarkerNames.set(id, name);
      const latlng = this.pointMarkers.get(id);
      const pos = new this.TMap.LatLng(latlng.lat, latlng.lng);
      const styleId = !this.pointMarkerVisible.get(id) ? "hidden" : this.highlightedPointId === id ? "highlight" : "default";
      this.pointLabelLayer.updateGeometries([{ id, styleId, position: pos, content: name }]);
    }
    setPointMarkerHighlight(id) {
      var _a;
      if (!this.pointMarkerLayer) return;
      const prev = this.highlightedPointId;
      this.highlightedPointId = id;
      const markerUpdates = [];
      const labelUpdates = [];
      if (prev !== null && prev !== id && this.pointMarkers.has(prev)) {
        const latlng = this.pointMarkers.get(prev);
        const pos = new this.TMap.LatLng(latlng.lat, latlng.lng);
        const visible = this.pointMarkerVisible.get(prev) !== false;
        const styleId = visible ? "default" : "hidden";
        markerUpdates.push({ id: prev, styleId, position: pos });
        labelUpdates.push({ id: prev, styleId, position: pos, content: this.pointMarkerNames.get(prev) ?? "" });
      }
      if (id !== null && this.pointMarkers.has(id)) {
        const latlng = this.pointMarkers.get(id);
        const pos = new this.TMap.LatLng(latlng.lat, latlng.lng);
        const visible = this.pointMarkerVisible.get(id) !== false;
        const styleId = visible ? "highlight" : "hidden";
        markerUpdates.push({ id, styleId, position: pos });
        labelUpdates.push({ id, styleId, position: pos, content: this.pointMarkerNames.get(id) ?? "" });
      }
      if (markerUpdates.length > 0) this.pointMarkerLayer.updateGeometries(markerUpdates);
      if (labelUpdates.length > 0) (_a = this.pointLabelLayer) == null ? void 0 : _a.updateGeometries(labelUpdates);
    }
    setPointMarkerVisible(id, visible) {
      if (!this.pointMarkerLayer || !this.pointMarkers.has(id)) return;
      this.pointMarkerVisible.set(id, visible);
      const latlng = this.pointMarkers.get(id);
      const pos = new this.TMap.LatLng(latlng.lat, latlng.lng);
      const styleId = !visible ? "hidden" : this.highlightedPointId === id ? "highlight" : "default";
      this.pointMarkerLayer.updateGeometries([{ id, styleId, position: pos }]);
      if (this.pointLabelLayer) {
        const name = this.pointMarkerNames.get(id) ?? "";
        this.pointLabelLayer.updateGeometries([{ id, styleId, position: pos, content: name }]);
      }
    }
    // ── Measure layers (persistent) ────────────────────────────────────────────
    ensureMeasurePolylineLayer() {
      if (this.measurePolylineLayer) return;
      this.measurePolylineLayer = new this.TMap.MultiPolyline({
        id: "tmap-hooker-measure-lines",
        map: this.map,
        styles: {
          default: new this.TMap.PolylineStyle({
            color: "#4A90D9",
            width: 2,
            lineCap: "butt",
            dashArray: [10, 6]
          }),
          highlight: new this.TMap.PolylineStyle({
            color: "#2B6CB0",
            width: 3,
            lineCap: "butt",
            dashArray: [0, 0]
          }),
          hidden: new this.TMap.PolylineStyle({
            color: "rgba(0,0,0,0)",
            width: 1,
            dashArray: [0, 0]
          })
        },
        geometries: []
      });
      this.measurePolylineLayer.setZIndex(9995);
      this.measurePolylineLayer.on("click", (evt) => {
        var _a, _b;
        const id = (_a = evt.geometry) == null ? void 0 : _a.id;
        if (id) (_b = this.onMeasureClick) == null ? void 0 : _b.call(this, id);
      });
    }
    ensureMeasureMarkerLayer() {
      if (this.measureMarkerLayer) return;
      this.measureMarkerLayer = new this.TMap.MultiMarker({
        id: "tmap-hooker-measure-markers",
        map: this.map,
        styles: {
          default: new this.TMap.MarkerStyle({
            width: 14,
            height: 14,
            anchor: { x: 7, y: 7 },
            src: this._hollowCircleSvg()
          }),
          hidden: new this.TMap.MarkerStyle({
            width: 1,
            height: 1,
            anchor: { x: 0, y: 0 },
            src: this._pinSvg("rgba(0,0,0,0)")
          })
        },
        geometries: []
      });
      this.measureMarkerLayer.setZIndex(9994);
    }
    /** 新建或更新一条测距图层（折线 + 顶点标记 + 距离标签）。 */
    addMeasure(id, points, segmentDistances, onClickCb) {
      if (points.length < 2) return;
      this.onMeasureClick = onClickCb;
      this.ensureMeasurePolylineLayer();
      this.ensureMeasureMarkerLayer();
      const path = points.map((p) => new this.TMap.LatLng(p.lat, p.lng));
      const styleId = this.highlightedMeasureId === id ? "highlight" : "default";
      const isUpdate = this.measures.has(id);
      const oldPoints = isUpdate ? this.measures.get(id) : null;
      const lineGeo = { id, styleId, paths: [path] };
      if (isUpdate) {
        this.measurePolylineLayer.updateGeometries([lineGeo]);
      } else {
        this.measurePolylineLayer.add([lineGeo]);
      }
      this.measures.set(id, [...points]);
      this.measureVisible.set(id, true);
      const markerGeos = points.map((p, i) => ({
        id: `${id}-v-${i}`,
        styleId: "default",
        position: new this.TMap.LatLng(p.lat, p.lng)
      }));
      if (this.measureMarkerLayer) {
        if (isUpdate && oldPoints) {
          const oldIds = oldPoints.map((_p, i) => `${id}-v-${i}`);
          this.measureMarkerLayer.remove(oldIds);
        }
        this.measureMarkerLayer.add(markerGeos);
      }
      this._updateMeasureLabels(id, points, segmentDistances);
    }
    /** 更新测距距离标签。 */
    _updateMeasureLabels(id, points, segmentDistances) {
      this._destroyMeasureLabels(id);
      const labels = [];
      for (let i = 0; i < points.length - 1; i++) {
        const a = points[i];
        const b = points[i + 1];
        const midLat = (a.lat + b.lat) / 2;
        const midLng = (a.lng + b.lng) / 2;
        const dist = segmentDistances[i] ?? 0;
        let text;
        if (dist >= 1e3) {
          text = `${(dist / 1e3).toFixed(2)} km`;
        } else {
          text = `${Math.round(dist)} m`;
        }
        const svg = this._labelCardSvg(text);
        const w = this._labelCardWidth(text);
        const labelLayer = new this.TMap.MultiMarker({
          map: this.map,
          styles: {
            default: new this.TMap.MarkerStyle({
              width: w,
              height: 24,
              anchor: { x: Math.round(w / 2), y: 30 },
              src: svg
            })
          },
          geometries: [{
            id: `${id}-label-${i}`,
            styleId: "default",
            position: new this.TMap.LatLng(midLat, midLng)
          }]
        });
        labels.push(labelLayer);
      }
      this.measureLabelMarkers.set(id, labels);
    }
    /** 销毁某条测距的所有标签。 */
    _destroyMeasureLabels(id) {
      const labels = this.measureLabelMarkers.get(id);
      if (!labels) return;
      for (const l of labels) l.setMap(null);
      this.measureLabelMarkers.delete(id);
    }
    /** 移除测距图层。 */
    removeMeasure(id) {
      if (!this.measures.has(id)) return;
      if (this.measurePolylineLayer) {
        this.measurePolylineLayer.remove([id]);
      }
      if (this.measureMarkerLayer) {
        const points = this.measures.get(id);
        const ids = points.map((_, i) => `${id}-v-${i}`);
        this.measureMarkerLayer.remove(ids);
      }
      this._destroyMeasureLabels(id);
      this.measures.delete(id);
      this.measureVisible.delete(id);
      if (this.highlightedMeasureId === id) this.highlightedMeasureId = null;
    }
    /** 切换测距可见性。 */
    setMeasureVisible(id, visible) {
      if (!this.measurePolylineLayer || !this.measures.has(id)) return;
      this.measureVisible.set(id, visible);
      const points = this.measures.get(id);
      const path = points.map((p) => new this.TMap.LatLng(p.lat, p.lng));
      const lineStyle = !visible ? "hidden" : this.highlightedMeasureId === id ? "highlight" : "default";
      this.measurePolylineLayer.updateGeometries([{ id, styleId: lineStyle, paths: [path] }]);
      const markerStyle = visible ? "default" : "hidden";
      if (this.measureMarkerLayer) {
        const markerGeos = points.map((p, i) => ({
          id: `${id}-v-${i}`,
          styleId: markerStyle,
          position: new this.TMap.LatLng(p.lat, p.lng)
        }));
        this.measureMarkerLayer.updateGeometries(markerGeos);
      }
      const labels = this.measureLabelMarkers.get(id);
      if (labels) {
        for (const l of labels) {
          if (visible) l.setMap(this.map);
          else l.setMap(null);
        }
      }
    }
    /** 切换测距高亮。 */
    setMeasureHighlight(id) {
      const prev = this.highlightedMeasureId;
      this.highlightedMeasureId = id;
      const lineUpdates = [];
      if (prev !== null && prev !== id && this.measures.has(prev) && this.measureVisible.get(prev) !== false) {
        const pts = this.measures.get(prev);
        lineUpdates.push({ id: prev, styleId: "default", paths: [pts.map((p) => new this.TMap.LatLng(p.lat, p.lng))] });
      }
      if (id !== null && this.measures.has(id) && this.measureVisible.get(id) !== false) {
        const pts = this.measures.get(id);
        lineUpdates.push({ id, styleId: "highlight", paths: [pts.map((p) => new this.TMap.LatLng(p.lat, p.lng))] });
      }
      if (lineUpdates.length > 0 && this.measurePolylineLayer) {
        this.measurePolylineLayer.updateGeometries(lineUpdates);
      }
    }
    // ── Lifecycle ─────────────────────────────────────────────────────────────
    /** 销毁测量图层（标记、折线、标签）并清空对应 track Map。clearAll 和 clearMeasurement 的共同实现。 */
    _destroyMeasurementLayers() {
      if (this.markerLayer) {
        this.markerLayer.setMap(null);
        this.markerLayer = null;
        this.markers.clear();
      }
      if (this.polylineLayer) {
        this.polylineLayer.setMap(null);
        this.polylineLayer = null;
        this.polylines.clear();
      }
      for (const marker of this.labelMarkers.values()) {
        marker.setMap(null);
      }
      this.labelMarkers.clear();
    }
    clearAll() {
      this._destroyMeasurementLayers();
      if (this.rubberBandLayer) {
        this.rubberBandLayer.setMap(null);
        this.rubberBandLayer = null;
        this.rubberBands.clear();
      }
      if (this.polygonLayer) {
        this.polygonLayer.setMap(null);
        this.polygonLayer = null;
        this.polygons.clear();
        this.polygonVisible.clear();
        this.previewPaths = null;
        this.highlightedId = null;
        this.onPolygonClick = null;
      }
      if (this.pointMarkerLayer) {
        this.pointMarkerLayer.setMap(null);
        this.pointMarkerLayer = null;
        this.pointMarkers.clear();
        this.pointMarkerNames.clear();
        this.pointMarkerVisible.clear();
        this.highlightedPointId = null;
      }
      if (this.pointLabelLayer) {
        this.pointLabelLayer.setMap(null);
        this.pointLabelLayer = null;
      }
      if (this.measurePolylineLayer) {
        this.measurePolylineLayer.setMap(null);
        this.measurePolylineLayer = null;
      }
      if (this.measureMarkerLayer) {
        this.measureMarkerLayer.setMap(null);
        this.measureMarkerLayer = null;
      }
      for (const labels of this.measureLabelMarkers.values()) {
        for (const l of labels) l.setMap(null);
      }
      this.measureLabelMarkers.clear();
      this.measures.clear();
      this.measureVisible.clear();
      this.highlightedMeasureId = null;
    }
    /**
     * 只清除测量覆盖物（标记、折线、标签），保留多边形图层和橡皮筋线。
     * 用于工具切换时：多边形是用户持久内容，测量覆盖物是临时的。
     */
    clearMeasurement() {
      this._destroyMeasurementLayers();
    }
    // ── Snapshot / Restore ────────────────────────────────────────────────────
    /**
     * 导出所有持久覆盖物数据为可序列化快照。
     * 用于 SPA 页面切换前保存数据，切换后通过 restoreSnapshot() 恢复。
     */
    snapshot() {
      return {
        polygons: Array.from(this.polygons.entries()).map(([id, paths]) => ({
          id,
          points: (paths[0] ?? []).map((p) => ({ lat: p.lat, lng: p.lng })),
          visible: this.polygonVisible.get(id) ?? true
        })),
        pointMarkers: Array.from(this.pointMarkers.entries()).map(([id, latlng]) => ({
          id,
          lat: latlng.lat,
          lng: latlng.lng,
          name: this.pointMarkerNames.get(id) ?? "",
          visible: this.pointMarkerVisible.get(id) ?? true
        })),
        measures: Array.from(this.measures.entries()).map(([id, points]) => ({
          id,
          points: points.map((p) => ({ lat: p.lat, lng: p.lng })),
          visible: this.measureVisible.get(id) ?? true
        })),
        circles: []
      };
    }
    /**
     * 从快照恢复所有持久覆盖物数据到当前地图。
     */
    restore(data, polygonClickCb, polygonMousedownCb, measureClickCb) {
      if (data.polygons.length > 0) {
        const geos = data.polygons.map((poly) => {
          const path = this._closedPath(poly.points);
          this.polygons.set(poly.id, [path]);
          this.polygonVisible.set(poly.id, poly.visible);
          return { id: poly.id, styleId: poly.visible ? "default" : "hidden", paths: [path] };
        });
        this.ensurePolygonLayer(polygonClickCb, polygonMousedownCb, geos);
      }
      if (data.pointMarkers.length > 0) {
        const sorted = [...data.pointMarkers].sort((a, b) => a.id.localeCompare(b.id));
        const markerGeos = [];
        const labelGeos = [];
        for (const pm of sorted) {
          const pos = new this.TMap.LatLng(pm.lat, pm.lng);
          const styleId = pm.visible ? "default" : "hidden";
          this.pointMarkers.set(pm.id, { lat: pm.lat, lng: pm.lng });
          this.pointMarkerNames.set(pm.id, pm.name);
          this.pointMarkerVisible.set(pm.id, pm.visible);
          markerGeos.push({ id: pm.id, styleId, position: pos });
          labelGeos.push({ id: pm.id, styleId, position: pos, content: pm.name });
        }
        this.ensurePointMarkerLayer(markerGeos);
        this.ensurePointLabelLayer(labelGeos);
      }
      if (data.measures && data.measures.length > 0) {
        for (const m of data.measures) {
          if (m.points.length < 2) continue;
          const segDists = [];
          for (let i = 0; i < m.points.length - 1; i++) {
            const a = m.points[i];
            const b = m.points[i + 1];
            const R2 = 6371e3;
            const dLat = (b.lat - a.lat) * Math.PI / 180;
            const dLng = (b.lng - a.lng) * Math.PI / 180;
            const lat1 = a.lat * Math.PI / 180;
            const lat2 = b.lat * Math.PI / 180;
            const sinDLat = Math.sin(dLat / 2);
            const sinDLng = Math.sin(dLng / 2);
            const a2 = sinDLat * sinDLat + Math.cos(lat1) * Math.cos(lat2) * sinDLng * sinDLng;
            segDists.push(R2 * 2 * Math.atan2(Math.sqrt(a2), Math.sqrt(1 - a2)));
          }
          this.addMeasure(m.id, m.points, segDists, measureClickCb ?? (() => {
          }));
          if (!m.visible) this.setMeasureVisible(m.id, false);
        }
      }
    }
    /** 从地图移除所有图层（不清除数据），用于地图实例销毁前的清理。 */
    detachFromMap() {
      const layers = [
        this.markerLayer,
        this.polylineLayer,
        this.polygonLayer,
        this.rubberBandLayer,
        this.pointMarkerLayer,
        this.pointLabelLayer,
        this.measurePolylineLayer,
        this.measureMarkerLayer
      ];
      for (const layer of layers) {
        if (layer) layer.setMap(null);
      }
      for (const marker of this.labelMarkers.values()) {
        marker.setMap(null);
      }
      for (const labels of this.measureLabelMarkers.values()) {
        for (const l of labels) l.setMap(null);
      }
    }
    /** 获取多边形图层引用（供 CircleTool 等注册直连事件）。 */
    getPolygonLayer() {
      return this.polygonLayer;
    }
    /** 设置圆形专有点击回调（由 CircleTool 注册）。 */
    setCircleClickHandler(cb) {
      this.onCircleClick = cb;
    }
    /** 设置圆形专有 mousedown 回调（由 CircleTool 注册，用于拖拽移动）。 */
    setCircleMousedownHandler(cb) {
      this.onCircleMousedown = cb;
      this._attachMousedownHandler();
    }
    /** 设置多边形专有 mousedown 回调（由 PolygonTool 注册，用于拖拽移动）。 */
    setPolygonMousedownHandler(cb) {
      this.onPolygonMousedown = cb;
      this._attachMousedownHandler();
    }
    // ── Helpers ───────────────────────────────────────────────────────────────
    /** 测距距离标签：白底圆角卡片 + 深灰文字，匹配 MeasureTool 官方样式。 */
    _labelCardSvg(text) {
      const w = this._labelCardWidth(text);
      const h = 22;
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">
      <rect x="1" y="1" width="${w - 2}" height="${h - 2}" rx="4" fill="#FFFFFF" stroke="#CCCCCC" stroke-width="1"/>
      <text x="${Math.round(w / 2)}" y="15" text-anchor="middle" fill="#333333" font-size="11" font-family="sans-serif">${this._xmlEscape(text)}</text>
    </svg>`;
      return `data:image/svg+xml;base64,${btoa(svg)}`;
    }
    /** 估算标签文本宽度，用于生成合适尺寸的 SVG。中文约 12px，英文/数字约 7px。 */
    _labelCardWidth(text) {
      let w = 0;
      for (const ch of text) {
        w += /[\u4e00-\u9fff]/.test(ch) ? 12 : 7;
      }
      return w + 16;
    }
    /** 转义 XML 特殊字符，防止 SVG 注入。 */
    _xmlEscape(s) {
      return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
    }
    /** 测距标记：蓝色空心圆，匹配 TMap MeasureTool 官方样式。 */
    _hollowCircleSvg() {
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 14 14">
      <circle cx="7" cy="7" r="5" fill="#FFFFFF" stroke="#4A90D9" stroke-width="2"/>
    </svg>`;
      return `data:image/svg+xml;base64,${btoa(svg)}`;
    }
    _markerSvg(label) {
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22">
      <circle cx="11" cy="11" r="9" fill="#FF6B35" stroke="#fff" stroke-width="2"/>
      <text x="11" y="15" text-anchor="middle" fill="#fff" font-size="10" font-family="sans-serif" font-weight="bold">${label}</text>
    </svg>`;
      return `data:image/svg+xml;base64,${btoa(svg)}`;
    }
    /** 未选中点位图标：亮蓝色大图钉。 */
    _pinDefaultSvg() {
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="30" viewBox="0 0 24 30">
      <path d="M12 0C6.48 0 2 4.48 2 10c0 7 10 20 10 20S22 17 22 10c0-5.52-4.48-10-10-10z" fill="#4488FF" stroke="#fff" stroke-width="1.5"/>
      <circle cx="12" cy="10" r="4" fill="#fff" opacity="0.9"/>
    </svg>`;
      return `data:image/svg+xml;base64,${btoa(svg)}`;
    }
    /** 选中点位图标：红色大图钉 + 红色光晕，醒目突出。 */
    _pinHighlightSvg() {
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="30" viewBox="0 0 24 30">
      <defs>
        <filter id="glow" x="-50%" y="-20%" width="200%" height="150%">
          <feDropShadow dx="0" dy="1" stdDeviation="2" flood-color="#FF3500" flood-opacity="0.5"/>
        </filter>
      </defs>
      <path d="M12 0C6.48 0 2 4.48 2 10c0 7 10 20 10 20S22 17 22 10c0-5.52-4.48-10-10-10z" fill="#FF3500" stroke="#fff" stroke-width="2" filter="url(#glow)"/>
      <circle cx="12" cy="10" r="4" fill="#fff" opacity="0.95"/>
    </svg>`;
      return `data:image/svg+xml;base64,${btoa(svg)}`;
    }
    _pinSvg(color) {
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="30" viewBox="0 0 24 30">
      <path d="M12 0C6.48 0 2 4.48 2 10c0 7 10 20 10 20S22 17 22 10c0-5.52-4.48-10-10-10z" fill="${color}" stroke="#fff" stroke-width="1.5"/>
      <circle cx="12" cy="10" r="4" fill="#fff" opacity="0.9"/>
    </svg>`;
      return `data:image/svg+xml;base64,${btoa(svg)}`;
    }
  }
  const R = 6371e3;
  function haversine(lat1, lng1, lat2, lng2) {
    const toRad = Math.PI / 180;
    const φ1 = lat1 * toRad;
    const φ2 = lat2 * toRad;
    const Δφ = (lat2 - lat1) * toRad;
    const Δλ = (lng2 - lng1) * toRad;
    const a = Math.sin(Δφ / 2) ** 2 + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) ** 2;
    return R * 2 * Math.asin(Math.sqrt(a));
  }
  function formatDistance(meters) {
    if (meters >= 1e3) {
      return `${(meters / 1e3).toFixed(2)} km`;
    }
    return `${Math.round(meters)} m`;
  }
  function getLabelStyleId(a, b) {
    const dLng = b.lng - a.lng;
    const dLat = b.lat - a.lat;
    let angle = Math.atan2(dLat, dLng) * 180 / Math.PI;
    angle = (angle % 180 + 180) % 180;
    if (angle < 22.5 || angle >= 157.5) return "label-up";
    if (angle < 67.5) return "label-up-left";
    if (angle < 112.5) return "label-right";
    return "label-up-right";
  }
  const HOOK_SOURCE = "tmap-hook";
  const PANEL_SOURCE = "tmap-panel";
  var HookEvent = /* @__PURE__ */ ((HookEvent2) => {
    HookEvent2["MAP_READY"] = "MAP_READY";
    HookEvent2["MAP_LOST"] = "MAP_LOST";
    HookEvent2["MAP_RESTORED"] = "MAP_RESTORED";
    HookEvent2["MOUSE_MOVE"] = "MOUSE_MOVE";
    HookEvent2["POINT_ADDED"] = "POINT_ADDED";
    HookEvent2["SEGMENT_ADDED"] = "SEGMENT_ADDED";
    HookEvent2["MEASUREMENT_RESULT"] = "MEASUREMENT_RESULT";
    HookEvent2["POINT_REMOVED"] = "POINT_REMOVED";
    HookEvent2["POLYGON_POINT_ADDED"] = "POLYGON_POINT_ADDED";
    HookEvent2["POLYGON_POINT_REMOVED"] = "POLYGON_POINT_REMOVED";
    HookEvent2["POLYGON_MODE_CHANGED"] = "POLYGON_MODE_CHANGED";
    HookEvent2["POLYGON_GEOMETRY"] = "POLYGON_GEOMETRY";
    HookEvent2["CIRCLE_CENTER_SET"] = "CIRCLE_CENTER_SET";
    HookEvent2["CIRCLE_UPDATED"] = "CIRCLE_UPDATED";
    HookEvent2["LAYER_DRAWN"] = "LAYER_DRAWN";
    HookEvent2["LAYER_SELECTED"] = "LAYER_SELECTED";
    HookEvent2["LAYER_DELETED"] = "LAYER_DELETED";
    HookEvent2["LAYER_EDIT_STARTED"] = "LAYER_EDIT_STARTED";
    HookEvent2["LAYER_EDIT_COMMITTED"] = "LAYER_EDIT_COMMITTED";
    HookEvent2["LAYER_EDIT_CANCELLED"] = "LAYER_EDIT_CANCELLED";
    return HookEvent2;
  })(HookEvent || {});
  var PanelCmd = /* @__PURE__ */ ((PanelCmd2) => {
    PanelCmd2["PANEL_READY"] = "PANEL_READY";
    PanelCmd2["SET_TOOL"] = "SET_TOOL";
    PanelCmd2["FINISH"] = "FINISH";
    PanelCmd2["UNDO"] = "UNDO";
    PanelCmd2["CLEAR"] = "CLEAR";
    PanelCmd2["SET_DEBUG"] = "SET_DEBUG";
    PanelCmd2["LAYER_SELECT"] = "LAYER_SELECT";
    PanelCmd2["LAYER_DELETE"] = "LAYER_DELETE";
    PanelCmd2["LAYER_TOGGLE"] = "LAYER_TOGGLE";
    PanelCmd2["LAYER_RENAME"] = "LAYER_RENAME";
    PanelCmd2["LAYER_EDIT"] = "LAYER_EDIT";
    PanelCmd2["START_DRAWING_POLYGON"] = "START_DRAWING_POLYGON";
    PanelCmd2["FINISH_DRAWING_POLYGON"] = "FINISH_DRAWING_POLYGON";
    PanelCmd2["CANCEL_DRAWING_POLYGON"] = "CANCEL_DRAWING_POLYGON";
    PanelCmd2["UNDO_POLYGON_POINT"] = "UNDO_POLYGON_POINT";
    PanelCmd2["DRAW_POLYGON"] = "DRAW_POLYGON";
    PanelCmd2["FINISH_EDIT_POLYGON"] = "FINISH_EDIT_POLYGON";
    PanelCmd2["CANCEL_EDIT_POLYGON"] = "CANCEL_EDIT_POLYGON";
    PanelCmd2["START_DRAWING_CIRCLE"] = "START_DRAWING_CIRCLE";
    PanelCmd2["CANCEL_DRAWING_CIRCLE"] = "CANCEL_DRAWING_CIRCLE";
    PanelCmd2["UPDATE_CIRCLE"] = "UPDATE_CIRCLE";
    PanelCmd2["FINISH_CIRCLE"] = "FINISH_CIRCLE";
    PanelCmd2["COMMIT_EDIT_CIRCLE"] = "COMMIT_EDIT_CIRCLE";
    PanelCmd2["CANCEL_EDIT_CIRCLE"] = "CANCEL_EDIT_CIRCLE";
    PanelCmd2["COMMIT_EDIT_MEASURE"] = "COMMIT_EDIT_MEASURE";
    PanelCmd2["CANCEL_EDIT_MEASURE"] = "CANCEL_EDIT_MEASURE";
    PanelCmd2["UPDATE_MEASURE_VERTEX"] = "UPDATE_MEASURE_VERTEX";
    PanelCmd2["IMPORT_POINT_MARKERS"] = "IMPORT_POINT_MARKERS";
    return PanelCmd2;
  })(PanelCmd || {});
  function sendToPanel(msg) {
    window.postMessage({ ...msg, source: HOOK_SOURCE }, "*");
  }
  const TOOL_IDS = {
    MULTI_POINT: "multi-point",
    CIRCLE: "circle",
    POLYGON: "polygon",
    POINT_MARKER: "point-marker"
  };
  const RUBBER_BAND_ID = "mp-rubber";
  class MultiPointTool {
    constructor() {
      this.id = TOOL_IDS.MULTI_POINT;
      this.ctx = null;
      this.points = [];
      this.totalM = 0;
      this.clickHandler = null;
      this.mousemoveHandler = null;
      this.dblClickHandler = null;
      this.keydownHandler = null;
      this.mapContainer = null;
      this.measureCount = 0;
      this.measureId = null;
      this.editMode = false;
      this.editMeasureId = null;
      this.editMeasureName = null;
    }
    /** 注册地图事件监听器，初始化点列表和累计距离。 */
    activate(ctx) {
      this.ctx = ctx;
      this.points = [];
      this.totalM = 0;
      this.clickHandler = (evt) => this.onMapClick(evt);
      ctx.map.on("click", this.clickHandler);
      this.mousemoveHandler = (evt) => this.onMouseMove(evt);
      ctx.map.on("mousemove", this.mousemoveHandler);
      this.dblClickHandler = (evt) => this.onDblClick(evt);
      ctx.map.on("dblclick", this.dblClickHandler);
      this.keydownHandler = (evt) => this.onKeydown(evt);
      document.addEventListener("keydown", this.keydownHandler);
      this.setCrosshair(true);
      log("MultiPointTool activated — crosshair + rubber band + dblclick + escape");
    }
    /**
     * 加载已有测距数据进行编辑。
     * 移除持久测距图层，将顶点数据注入临时绘制层，后续操作与新建绘制一致。
     */
    loadForEdit(ctx, id, name, points, segDists) {
      this.deactivate();
      this.ctx = ctx;
      this.editMode = true;
      this.editMeasureId = id;
      this.editMeasureName = name;
      this.points = [...points];
      this.totalM = segDists.reduce((a, b) => a + b, 0);
      ctx.overlays.removeMeasure(id);
      for (let i = 0; i < points.length; i++) {
        const pt = points[i];
        ctx.overlays.addMarker(`mp-${i}`, pt, String(i + 1));
        sendToPanel({ type: HookEvent.POINT_ADDED, payload: { index: i, lat: pt.lat, lng: pt.lng } });
        if (i > 0) {
          const prev = points[i - 1];
          const dist = segDists[i - 1];
          ctx.overlays.setPolyline(`mp-line-${i - 1}`, [prev, pt]);
          const midLat = (prev.lat + pt.lat) / 2;
          const midLng = (prev.lng + pt.lng) / 2;
          ctx.overlays.addLabel(
            `mp-label-${i - 1}`,
            { lat: midLat, lng: midLng },
            formatDistance(dist),
            getLabelStyleId(prev, pt)
          );
          sendToPanel({
            type: HookEvent.SEGMENT_ADDED,
            payload: { fromIdx: i - 1, toIdx: i, distanceM: dist, totalM: this.totalM }
          });
        }
      }
      this.clickHandler = (evt) => this.onMapClick(evt);
      ctx.map.on("click", this.clickHandler);
      this.mousemoveHandler = (evt) => this.onMouseMove(evt);
      ctx.map.on("mousemove", this.mousemoveHandler);
      this.dblClickHandler = (evt) => this.onDblClick(evt);
      ctx.map.on("dblclick", this.dblClickHandler);
      this.keydownHandler = (evt) => this.onKeydown(evt);
      document.addEventListener("keydown", this.keydownHandler);
      this.setCrosshair(true);
      sendToPanel({ type: HookEvent.LAYER_EDIT_STARTED, payload: { id, kind: "measure" } });
      log("MultiPointTool loadForEdit —", id, points.length, "points");
    }
    /** 注销所有地图事件监听器，清空内部状态。 */
    deactivate() {
      if (this.ctx) {
        if (this.clickHandler) {
          this.ctx.map.off("click", this.clickHandler);
          this.clickHandler = null;
        }
        if (this.mousemoveHandler) {
          this.ctx.map.off("mousemove", this.mousemoveHandler);
          this.mousemoveHandler = null;
        }
        if (this.dblClickHandler) {
          this.ctx.map.off("dblclick", this.dblClickHandler);
          this.dblClickHandler = null;
        }
        this.ctx.overlays.removeRubberBand(RUBBER_BAND_ID);
      }
      if (this.keydownHandler) {
        document.removeEventListener("keydown", this.keydownHandler);
        this.keydownHandler = null;
      }
      this.setCrosshair(false);
      this.ctx = null;
    }
    /** 清除所有覆盖物和测量数据，重新挂载点击监听器以继续测量。 */
    reset() {
      if (this.ctx) {
        this.ctx.overlays.clearMeasurement();
      }
      this.points = [];
      this.totalM = 0;
      if (this.ctx && !this.clickHandler) {
        this.clickHandler = (evt) => this.onMapClick(evt);
        this.ctx.map.on("click", this.clickHandler);
        this.mousemoveHandler = (evt) => this.onMouseMove(evt);
        this.ctx.map.on("mousemove", this.mousemoveHandler);
        this.dblClickHandler = (evt) => this.onDblClick(evt);
        this.ctx.map.on("dblclick", this.dblClickHandler);
      }
    }
    /** 停止接收新点击（保留已绘制的覆盖物），对应双击/面板"完成"按钮。 */
    finish() {
      if (!this.ctx) return;
      if (this.clickHandler) {
        this.ctx.map.off("click", this.clickHandler);
        this.clickHandler = null;
      }
      if (this.mousemoveHandler) {
        this.ctx.map.off("mousemove", this.mousemoveHandler);
        this.mousemoveHandler = null;
        this.ctx.overlays.removeRubberBand(RUBBER_BAND_ID);
      }
      if (this.dblClickHandler) {
        this.ctx.map.off("dblclick", this.dblClickHandler);
        this.dblClickHandler = null;
      }
      if (this.keydownHandler) {
        document.removeEventListener("keydown", this.keydownHandler);
        this.keydownHandler = null;
      }
      this.setCrosshair(false);
      if (this.points.length >= 2) {
        const isEdit = this.editMode;
        const id = isEdit ? this.editMeasureId : `measure-${Date.now()}`;
        isEdit ? this.editMeasureName : `测距 ${this.measureCount + 1}`;
        if (!isEdit) {
          this.measureCount++;
        }
        const segDists = [];
        for (let i = 0; i < this.points.length - 1; i++) {
          const a = this.points[i];
          const b = this.points[i + 1];
          segDists.push(haversine(a.lat, a.lng, b.lat, b.lng));
        }
        this.ctx.overlays.addMeasure(id, [...this.points], segDists, (clickedId) => {
          sendToPanel({ type: HookEvent.LAYER_SELECTED, payload: { id: clickedId } });
        });
        this.ctx.overlays.clearMeasurement();
        if (isEdit) {
          sendToPanel({ type: HookEvent.LAYER_EDIT_COMMITTED, payload: { id, kind: "measure" } });
        }
        sendToPanel({
          type: HookEvent.LAYER_DRAWN,
          payload: {
            id,
            kind: "measure",
            data: {
              kind: "measure",
              paths: [[...this.points]],
              segmentDistances: segDists,
              totalDistance: this.totalM
            }
          }
        });
        this.editMode = false;
        this.editMeasureId = null;
        this.editMeasureName = null;
      }
      log("MultiPointTool finished");
    }
    /**
     * 撤销最后一个点：移除对应的标记、线段和标签，并从累计距离中减去该段。
     * 索引 0 的点没有对应线段，只删除标记。
     */
    undo() {
      if (!this.ctx || this.points.length === 0) return;
      const idx = this.points.length - 1;
      this.ctx.overlays.removeMarker(`mp-${idx}`);
      if (idx > 0) {
        this.ctx.overlays.removePolyline(`mp-line-${idx - 1}`);
        this.ctx.overlays.removeLabel(`mp-label-${idx - 1}`);
        const a = this.points[idx - 1];
        const b = this.points[idx];
        this.totalM -= haversine(a.lat, a.lng, b.lat, b.lng);
      }
      this.points.pop();
      if (this.points.length === 0) {
        this.ctx.overlays.removeRubberBand(RUBBER_BAND_ID);
      }
      sendToPanel({ type: HookEvent.POINT_REMOVED, payload: { newCount: this.points.length } });
      log("MultiPointTool undo, remaining:", this.points.length);
    }
    // ── Event handlers ───────────────────────────────────────────────────────
    /**
     * 处理地图点击事件：追加新点，绘制标记；若已有前一点则计算并绘制线段+距离标签。
     */
    onMapClick(evt) {
      if (!this.ctx) return;
      const latlng = { lat: evt.latLng.lat, lng: evt.latLng.lng };
      const idx = this.points.length;
      this.points.push(latlng);
      this.ctx.overlays.addMarker(`mp-${idx}`, latlng, String(idx + 1));
      sendToPanel({ type: HookEvent.POINT_ADDED, payload: { index: idx, ...latlng } });
      if (idx > 0) {
        const prev = this.points[idx - 1];
        const segDist = haversine(prev.lat, prev.lng, latlng.lat, latlng.lng);
        this.totalM += segDist;
        this.ctx.overlays.setPolyline(`mp-line-${idx - 1}`, [prev, latlng]);
        const midLat = (prev.lat + latlng.lat) / 2;
        const midLng = (prev.lng + latlng.lng) / 2;
        this.ctx.overlays.addLabel(
          `mp-label-${idx - 1}`,
          { lat: midLat, lng: midLng },
          formatDistance(segDist),
          getLabelStyleId(prev, latlng)
        );
        sendToPanel({
          type: HookEvent.SEGMENT_ADDED,
          payload: {
            fromIdx: idx - 1,
            toIdx: idx,
            distanceM: segDist,
            totalM: this.totalM
          }
        });
      }
    }
    /**
     * 鼠标移动时更新橡皮筋预览线（最后一个点 → 鼠标当前位置）。
     * 配合 MeasureTool 体验，提供实时预览。
     */
    onMouseMove(evt) {
      if (!this.ctx || this.points.length === 0) return;
      const cursor = { lat: evt.latLng.lat, lng: evt.latLng.lng };
      this.ctx.overlays.setRubberBand(RUBBER_BAND_ID, [this.points[this.points.length - 1], cursor]);
    }
    /**
     * 双击结束测量。
     * TMap 双击事件触发顺序：click（第一下）→ click（第二下）→ dblclick。
     * 第一下 click 已经向 points 添加了一个点，这里需要先撤销再完成。
     */
    onDblClick(_evt) {
      this.undo();
      this.finish();
      log("MultiPointTool dblclick finish");
    }
    /** Escape 取消：清空所有覆盖物，回到初始测量状态。编辑模式下恢复原图层。 */
    onKeydown(evt) {
      if (evt.key !== "Escape") return;
      evt.preventDefault();
      if (this.editMode && this.editMeasureId && this.ctx) {
        const id = this.editMeasureId;
        this.editMeasureName;
        const pts = [...this.points];
        const segDists = [];
        for (let i = 0; i < pts.length - 1; i++) {
          segDists.push(haversine(pts[i].lat, pts[i].lng, pts[i + 1].lat, pts[i + 1].lng));
        }
        this.ctx.overlays.addMeasure(id, pts, segDists, (clickedId) => {
          sendToPanel({ type: HookEvent.LAYER_SELECTED, payload: { id: clickedId } });
        });
        this.ctx.overlays.clearMeasurement();
        sendToPanel({ type: HookEvent.LAYER_EDIT_CANCELLED, payload: { id, kind: "measure" } });
        sendToPanel({
          type: HookEvent.LAYER_DRAWN,
          payload: {
            id,
            kind: "measure",
            data: {
              kind: "measure",
              paths: [[...pts]],
              segmentDistances: segDists,
              totalDistance: segDists.reduce((a, b) => a + b, 0)
            }
          }
        });
        this.editMode = false;
        this.editMeasureId = null;
        this.editMeasureName = null;
        log("MultiPointTool edit cancelled — restored", id);
      } else {
        this.reset();
      }
      log("MultiPointTool Escape — reset");
    }
    // ── Crosshair cursor ─────────────────────────────────────────────────────
    /** 在地图容器上切换十字准星光标。 */
    setCrosshair(on) {
      var _a, _b, _c;
      try {
        if (!this.mapContainer) {
          this.mapContainer = ((_c = (_b = (_a = this.ctx) == null ? void 0 : _a.map) == null ? void 0 : _b.getContainer) == null ? void 0 : _c.call(_b)) ?? document.getElementById("container");
        }
        if (this.mapContainer) {
          if (on) {
            this.mapContainer.classList.add("__tmh-crosshair");
          } else {
            this.mapContainer.classList.remove("__tmh-crosshair");
          }
        }
      } catch {
      }
    }
  }
  const DEFAULT_N = 64;
  const DEFAULT_R = 500;
  const CIRCLE_PREFIX = "circle-";
  const PREVIEW_ID = "circle-preview";
  class CircleTool {
    constructor() {
      this.id = TOOL_IDS.CIRCLE;
      this.ctx = null;
      this.overlays = null;
      this.idCounter = 0;
      this.mode = "idle";
      this.pending = null;
      this.mousedownHandler = null;
      this.mousemoveHandler = null;
      this.mouseupHandler = null;
      this.isDragging = false;
      this._placedMdHandler = null;
      this._placedMmHandler = null;
      this._placedMuHandler = null;
      this._placedDragging = false;
      this._commitDragId = null;
      this._commitDragMoved = false;
      this._commitDragStartLatLng = null;
      this._commitDragOrigCenter = null;
      this._commitMmHandler = null;
      this._commitMuHandler = null;
      this.editingId = null;
      this.editCenter = null;
      this.editRadius = 0;
      this.editNPoints = DEFAULT_N;
      this.editSnapshot = null;
      this.centerHandleId = null;
      this.dragendHandler = null;
      this.circleIds = /* @__PURE__ */ new Set();
      this.circleCenters = /* @__PURE__ */ new Map();
      this.circleParams = /* @__PURE__ */ new Map();
      this.circleCoords = /* @__PURE__ */ new Map();
    }
    // 供 ToolManager 在 snapshot/restore 时提取多边形点击回调
    getClickHandler() {
      return () => {
      };
    }
    getMousedownHandler() {
      return void 0;
    }
    // ══════════════════════════════════════════════════════════════════
    // Lifecycle
    // ══════════════════════════════════════════════════════════════════
    activate(ctx) {
      this.ctx = ctx;
      this.overlays = ctx.overlays;
      this.mode = "idle";
      this.pending = null;
      ctx.overlays.setCircleClickHandler(this._onCircleClick.bind(this));
      ctx.overlays.setCircleMousedownHandler(this._onCircleMousedown.bind(this));
      log("CircleTool activated (idle)");
    }
    deactivate() {
      var _a;
      this._cleanupAll();
      this._cancelCommitDrag();
      if (this.pending) {
        (_a = this.ctx) == null ? void 0 : _a.overlays.removePreviewPolygon(PREVIEW_ID);
        this.pending = null;
      }
      if (this.editingId) this.cancelEditCircle();
      this.ctx = null;
      log("CircleTool deactivated");
    }
    reset() {
      var _a;
      this._cleanupAll();
      this._cancelCommitDrag();
      if (this.pending) {
        (_a = this.ctx) == null ? void 0 : _a.overlays.removePreviewPolygon(PREVIEW_ID);
        this.pending = null;
      }
      if (this.ctx) {
        for (const id of this.circleIds) {
          this.ctx.overlays.removePolygon(id);
        }
      }
      this.circleIds.clear();
      this.circleCenters.clear();
      this.circleParams.clear();
      this.circleCoords.clear();
      this.idCounter = 0;
      this.mode = "idle";
      this.editingId = null;
      log("CircleTool reset");
    }
    // ══════════════════════════════════════════════════════════════════
    // 绘制流程（panel 驱动）
    // ══════════════════════════════════════════════════════════════════
    /** 进入绘制模式：监听 mousedown/mousemove/mouseup 用于拖拽画圆。 */
    startDrawing() {
      if (this.mode !== "idle" || !this.ctx) return;
      this.mode = "drawing";
      this._listenDrag();
      log("CircleTool: enter drawing mode");
    }
    /** 取消绘制，回到 idle。 */
    cancelDrawing() {
      var _a;
      if (this.mode === "idle") return;
      this._stopDrag();
      this._stopPlacedDrag();
      this.isDragging = false;
      if (this.pending) {
        (_a = this.ctx) == null ? void 0 : _a.overlays.removePreviewPolygon(PREVIEW_ID);
        this.pending = null;
      }
      this.mode = "idle";
      log("CircleTool: cancel drawing → idle");
    }
    // ══════════════════════════════════════════════════════════════════
    // 拖拽绘制内部实现
    // ══════════════════════════════════════════════════════════════════
    _listenDrag() {
      if (!this.ctx) return;
      this.mousedownHandler = (evt) => this._onDragStart(evt);
      this.mousemoveHandler = (evt) => this._onDragMove(evt);
      this.mouseupHandler = () => this._onDragEnd();
      const map = this.ctx.map;
      map.on("mousedown", this.mousedownHandler);
      map.on("mousemove", this.mousemoveHandler);
      map.on("mouseup", this.mouseupHandler);
    }
    _stopDrag() {
      if (!this.ctx) return;
      const map = this.ctx.map;
      if (this.mousedownHandler) {
        map.off("mousedown", this.mousedownHandler);
        this.mousedownHandler = null;
      }
      if (this.mousemoveHandler) {
        map.off("mousemove", this.mousemoveHandler);
        this.mousemoveHandler = null;
      }
      if (this.mouseupHandler) {
        map.off("mouseup", this.mouseupHandler);
        this.mouseupHandler = null;
      }
    }
    _onDragStart(evt) {
      if (this.mode !== "drawing" || !this.ctx) return;
      this._stopPlacedDrag();
      this.isDragging = true;
      const center = { lat: evt.latLng.lat, lng: evt.latLng.lng };
      const id = `${CIRCLE_PREFIX}${++this.idCounter}`;
      this.pending = { id, center, radius: DEFAULT_R, nPoints: DEFAULT_N };
      this._updatePreview(center, DEFAULT_R, DEFAULT_N);
      sendToPanel({
        type: HookEvent.CIRCLE_CENTER_SET,
        payload: { id, lat: center.lat, lng: center.lng, radius: DEFAULT_R, nPoints: DEFAULT_N }
      });
    }
    _onDragMove(evt) {
      if (!this.isDragging || !this.pending || !this.ctx) return;
      const TMap = window.TMap;
      const from = new TMap.LatLng(this.pending.center.lat, this.pending.center.lng);
      const to = new TMap.LatLng(evt.latLng.lat, evt.latLng.lng);
      let radius = DEFAULT_R;
      try {
        radius = TMap.geometry.computeDistance([from, to]);
      } catch {
      }
      if (radius < 10) radius = 10;
      this.pending.radius = radius;
      this._updatePreview(this.pending.center, radius, this.pending.nPoints);
      const { area, perimeter } = this._computeGeometry(
        this._generatePoints(this.pending.center, radius, this.pending.nPoints)
      );
      sendToPanel({
        type: HookEvent.CIRCLE_UPDATED,
        payload: { id: this.pending.id, radius, nPoints: this.pending.nPoints, area, perimeter }
      });
    }
    _onDragEnd() {
      if (!this.isDragging) return;
      this.isDragging = false;
      if (this.pending) {
        this.mode = "placed";
        const { id, center, radius, nPoints } = this.pending;
        const points = this._generatePoints(center, radius, nPoints);
        const { area, perimeter } = this._computeGeometry(points);
        sendToPanel({
          type: HookEvent.CIRCLE_UPDATED,
          payload: { id, radius, nPoints, area, perimeter, lat: center.lat, lng: center.lng }
        });
        log("CircleTool: placed, center=", this.pending.center, "radius=", this.pending.radius);
      }
      this._listenPlacedDrag();
    }
    // ── placed-mode 圆心拖拽 ──────────────────────────────────────────────────
    _listenPlacedDrag() {
      if (!this.ctx) return;
      const polyLayer = this.ctx.overlays.getPolygonLayer();
      if (!polyLayer) return;
      this._placedMdHandler = (evt) => {
        var _a, _b;
        if (((_a = evt.geometry) == null ? void 0 : _a.id) !== PREVIEW_ID || !this.pending || !this.ctx) return;
        (_b = evt.originalEvent) == null ? void 0 : _b.stopPropagation();
        this._placedDragging = true;
        const map = this.ctx.map;
        map.on("mousemove", this._placedMmHandler);
        map.on("mouseup", this._placedMuHandler);
      };
      this._placedMmHandler = (evt) => {
        if (!this._placedDragging || !this.pending || !this.ctx) return;
        const center = { lat: evt.latLng.lat, lng: evt.latLng.lng };
        this.pending.center = center;
        this._updatePreview(center, this.pending.radius, this.pending.nPoints);
        const points = this._generatePoints(center, this.pending.radius, this.pending.nPoints);
        const { area, perimeter } = this._computeGeometry(points);
        sendToPanel({
          type: HookEvent.CIRCLE_UPDATED,
          // 补充 lat/lng，让 panel 端 circlePreview 坐标实时跟随圆心拖拽
          payload: { id: this.pending.id, radius: this.pending.radius, nPoints: this.pending.nPoints, area, perimeter, lat: center.lat, lng: center.lng }
        });
      };
      this._placedMuHandler = () => {
        if (!this._placedDragging || !this.pending || !this.ctx) return;
        this._placedDragging = false;
        const map = this.ctx.map;
        map.off("mousemove", this._placedMmHandler);
        map.off("mouseup", this._placedMuHandler);
        const { id, center, radius, nPoints } = this.pending;
        const points = this._generatePoints(center, radius, nPoints);
        const { area, perimeter } = this._computeGeometry(points);
        sendToPanel({
          type: HookEvent.CIRCLE_UPDATED,
          payload: { id, radius, nPoints, area, perimeter, lat: center.lat, lng: center.lng }
        });
        log("CircleTool: center dragged to", center);
      };
      polyLayer.on("mousedown", this._placedMdHandler);
    }
    _stopPlacedDrag() {
      var _a;
      const polyLayer = (_a = this.ctx) == null ? void 0 : _a.overlays.getPolygonLayer();
      if (polyLayer && this._placedMdHandler) {
        polyLayer.off("mousedown", this._placedMdHandler);
      }
      if (this.ctx) {
        const map = this.ctx.map;
        if (this._placedMmHandler) map.off("mousemove", this._placedMmHandler);
        if (this._placedMuHandler) map.off("mouseup", this._placedMuHandler);
      }
      this._placedMdHandler = null;
      this._placedMmHandler = null;
      this._placedMuHandler = null;
      this._placedDragging = false;
    }
    // ══════════════════════════════════════════════════════════════════
    // 完成 / 滑块更新（panel 驱动）
    // ══════════════════════════════════════════════════════════════════
    updateCircle(id, radius, nPoints) {
      if (this.editingId === id) {
        this.updateEditCircle(void 0, radius, nPoints);
        return;
      }
      if (!this.pending || this.pending.id !== id || !this.ctx) return;
      this.pending.radius = radius;
      this.pending.nPoints = nPoints;
      this._updatePreview(this.pending.center, radius, nPoints);
      const points = this._generatePoints(this.pending.center, radius, nPoints);
      const { area, perimeter } = this._computeGeometry(points);
      sendToPanel({
        type: HookEvent.CIRCLE_UPDATED,
        payload: { id, radius, nPoints, area, perimeter }
      });
    }
    finishCircle() {
      if (!this.pending || !this.ctx) return;
      this._stopDrag();
      this._stopPlacedDrag();
      const { id, center, radius, nPoints } = this.pending;
      const points = this._generatePoints(center, radius, nPoints);
      this.ctx.overlays.removePreviewPolygon(PREVIEW_ID);
      this.ctx.overlays.addPolygon(id, points, () => {
      }, void 0);
      this.circleIds.add(id);
      this.circleCenters.set(id, center);
      this.circleParams.set(id, { radius, nPoints });
      this.circleCoords.set(id, points);
      const { area, perimeter } = this._computeGeometry(points);
      sendToPanel({
        type: HookEvent.LAYER_DRAWN,
        payload: { id, kind: "circle", data: { kind: "circle", center, radius, nPoints, area, perimeter } }
      });
      this.pending = null;
      this.mode = "idle";
      log("CircleTool finishCircle:", id, "r=", radius, "n=", nPoints);
    }
    // ══════════════════════════════════════════════════════════════════
    // 圆形编辑（参数化）
    // ══════════════════════════════════════════════════════════════════
    startEditCircle(id) {
      const center = this.circleCenters.get(id);
      const params = this.circleParams.get(id);
      if (!center || !params || !this.ctx) return;
      this.editingId = id;
      this.editCenter = { ...center };
      this.editRadius = params.radius;
      this.editNPoints = params.nPoints;
      this.editSnapshot = { center: { ...center }, radius: params.radius, nPoints: params.nPoints };
      this._showCenterHandle();
      this._updateEditPreview();
      sendToPanel({ type: HookEvent.LAYER_EDIT_STARTED, payload: { id, kind: "circle" } });
      log("CircleTool startEditCircle:", id);
    }
    /** 编辑中被 panel 拖拽圆心或调滑块时调用。 */
    updateEditCircle(center, radius, nPoints) {
      if (!this.editingId || !this.ctx) return;
      if (center) this.editCenter = center;
      if (radius !== void 0) this.editRadius = radius;
      if (nPoints !== void 0) this.editNPoints = nPoints;
      this._updateEditPreview();
      const points = this._generatePoints(this.editCenter, this.editRadius, this.editNPoints);
      const { area, perimeter } = this._computeGeometry(points);
      sendToPanel({
        type: HookEvent.CIRCLE_UPDATED,
        payload: { id: this.editingId, radius: this.editRadius, nPoints: this.editNPoints, area, perimeter }
      });
    }
    commitEditCircle() {
      var _a;
      if (!this.editingId || !this.editCenter) return;
      const id = this.editingId;
      this.circleCenters.set(id, this.editCenter);
      this.circleParams.set(id, { radius: this.editRadius, nPoints: this.editNPoints });
      const points = this._generatePoints(this.editCenter, this.editRadius, this.editNPoints);
      this.circleCoords.set(id, points);
      (_a = this.ctx) == null ? void 0 : _a.overlays.addPolygon(id, points, () => {
      }, void 0);
      this._removeCenterHandle();
      const { area, perimeter } = this._computeGeometry(points);
      sendToPanel({ type: HookEvent.LAYER_EDIT_COMMITTED, payload: { id, kind: "circle" } });
      sendToPanel({
        type: HookEvent.LAYER_DRAWN,
        payload: { id, kind: "circle", data: { kind: "circle", center: this.editCenter, radius: this.editRadius, nPoints: this.editNPoints, area, perimeter } }
      });
      this.editingId = null;
      this.editSnapshot = null;
      log("CircleTool commitEditCircle:", id);
    }
    cancelEditCircle() {
      var _a;
      if (!this.editingId || !this.editSnapshot) return;
      const id = this.editingId;
      const snap = this.editSnapshot;
      this.circleCenters.set(id, snap.center);
      this.circleParams.set(id, { radius: snap.radius, nPoints: snap.nPoints });
      const points = this._generatePoints(snap.center, snap.radius, snap.nPoints);
      this.circleCoords.set(id, points);
      (_a = this.ctx) == null ? void 0 : _a.overlays.addPolygon(id, points, () => {
      }, void 0);
      this._removeCenterHandle();
      sendToPanel({ type: HookEvent.LAYER_EDIT_CANCELLED, payload: { id, kind: "circle" } });
      this.editingId = null;
      this.editSnapshot = null;
      log("CircleTool cancelEditCircle:", id);
    }
    // ══════════════════════════════════════════════════════════════════
    // 圆心拖拽手柄
    // ══════════════════════════════════════════════════════════════════
    _showCenterHandle() {
      if (!this.editCenter || !this.ctx) return;
      const TMap = window.TMap;
      this.centerHandleId = "__tmh_circle_center_handle__";
      this.ctx.overlays;
      const styles = {
        [this.centerHandleId]: new TMap.MarkerStyle({
          width: 16,
          height: 16,
          anchor: { x: 8, y: 8 },
          src: this._centerPinSvg()
        })
      };
      const layer = this.ctx.overlays.markerLayer;
      if (!layer) return;
      const geometries = [{
        id: this.centerHandleId,
        styleId: this.centerHandleId,
        position: new TMap.LatLng(this.editCenter.lat, this.editCenter.lng)
      }];
      if (!layer._centerHandleGeoms) {
        layer.add(geometries);
        layer._centerHandleGeoms = true;
        layer.setStyles(styles);
      } else {
        layer.updateGeometries(geometries);
      }
      this.dragendHandler = (evt) => {
        if (!evt.geometry) return;
        const pos = evt.geometry.position;
        this.editCenter = { lat: pos.lat, lng: pos.lng };
        this.updateEditCircle(this.editCenter);
      };
      layer.on("dragend", this.dragendHandler);
    }
    _removeCenterHandle() {
      var _a, _b;
      const layer = (_b = (_a = this.ctx) == null ? void 0 : _a.overlays) == null ? void 0 : _b.markerLayer;
      if (!layer || !this.centerHandleId) return;
      if (this.dragendHandler) {
        layer.off("dragend", this.dragendHandler);
        this.dragendHandler = null;
      }
      layer.remove([this.centerHandleId]);
      layer._centerHandleGeoms = false;
      this.centerHandleId = null;
    }
    _centerPinSvg() {
      return "data:image/svg+xml," + encodeURIComponent(
        `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><circle cx="8" cy="8" r="6" fill="#4A90D9" stroke="#fff" stroke-width="2"/></svg>`
      );
    }
    _onCircleClick(id) {
      log("[circle] click — id:", id, "editing:", !!this.editingId);
      if (!this.circleIds.has(id) || !this.ctx) return;
      const center = this.circleCenters.get(id);
      const params = this.circleParams.get(id);
      if (!center || !params) return;
      this.overlays.setPolygonHighlight(id);
      const points = this.circleCoords.get(id);
      const { area, perimeter } = this._computeGeometry(points);
      sendToPanel({
        type: HookEvent.LAYER_SELECTED,
        payload: { id, data: { kind: "circle", center, radius: params.radius, nPoints: params.nPoints, area, perimeter } }
      });
      log("[circle] selected:", id);
    }
    _onCircleMousedown(id, latLng) {
      log("[circle] mousedown — id:", id, "editing:", !!this.editingId);
      if (!this.circleIds.has(id) || !this.ctx) return;
      if (this.editingId) {
        log("[circle] mousedown SKIP — editing");
        return;
      }
      this.overlays.setPolygonHighlight(id);
      const origCenter = this.circleCenters.get(id);
      if (!origCenter) {
        log("[circle] mousedown SKIP — no origCenter");
        return;
      }
      this._commitDragId = id;
      this._commitDragMoved = false;
      this._commitDragStartLatLng = { lat: latLng.lat, lng: latLng.lng };
      this._commitDragOrigCenter = { ...origCenter };
      const map = this.ctx.map;
      try {
        map.setDraggable(false);
      } catch {
      }
      this._commitMmHandler = (evt) => {
        if (!this._commitDragId || !this.ctx || !this._commitDragStartLatLng || !this._commitDragOrigCenter) return;
        const container = this.ctx.map.getContainer();
        const rect = container.getBoundingClientRect();
        const TMap = window.TMap;
        let lat, lng;
        try {
          const point = new TMap.Point(evt.clientX - rect.left, evt.clientY - rect.top);
          const projected = this.ctx.map.unprojectFromContainer(point);
          lat = projected.lat;
          lng = projected.lng;
        } catch (e) {
          log("[circle] commit-drag unproject FAILED:", (e == null ? void 0 : e.message) ?? e);
          return;
        }
        this._commitDragMoved = true;
        const dLat = lat - this._commitDragStartLatLng.lat;
        const dLng = lng - this._commitDragStartLatLng.lng;
        const center = {
          lat: this._commitDragOrigCenter.lat + dLat,
          lng: this._commitDragOrigCenter.lng + dLng
        };
        this.circleCenters.set(this._commitDragId, center);
        const params = this.circleParams.get(this._commitDragId);
        const points = this._generatePoints(center, params.radius, params.nPoints);
        this.circleCoords.set(this._commitDragId, points);
        const polyLayer = this.ctx.overlays.getPolygonLayer();
        if (polyLayer) {
          const path = this._tmapClosedPath(points, TMap);
          polyLayer.updateGeometries([{ id: this._commitDragId, styleId: "default", paths: [path] }]);
        }
      };
      this._commitMuHandler = () => {
        log("[circle] drag-end — id:", this._commitDragId, "moved:", this._commitDragMoved);
        if (!this._commitDragId || !this.ctx) return;
        const map2 = this.ctx.map;
        document.removeEventListener("mousemove", this._commitMmHandler);
        document.removeEventListener("mouseup", this._commitMuHandler);
        try {
          map2.setDraggable(true);
        } catch {
        }
        if (this._commitDragMoved) {
          const center = this.circleCenters.get(this._commitDragId);
          const params = this.circleParams.get(this._commitDragId);
          const points = this.circleCoords.get(this._commitDragId);
          const { area, perimeter } = this._computeGeometry(points);
          this.ctx.overlays.addPolygon(this._commitDragId, points, () => {
          }, void 0);
          this.overlays.setPolygonHighlight(this._commitDragId);
          sendToPanel({
            type: HookEvent.LAYER_DRAWN,
            payload: { id: this._commitDragId, kind: "circle", data: { kind: "circle", center, radius: params.radius, nPoints: params.nPoints, area, perimeter } }
          });
          log("CircleTool: commit-dragged", this._commitDragId, "to", center);
        }
        this._commitDragId = null;
        this._commitDragStartLatLng = null;
        this._commitDragOrigCenter = null;
        this._commitMmHandler = null;
        this._commitMuHandler = null;
      };
      document.addEventListener("mousemove", this._commitMmHandler);
      document.addEventListener("mouseup", this._commitMuHandler);
    }
    _tmapClosedPath(points, TMap) {
      const closed = [...points];
      const first = closed[0];
      const last = closed[closed.length - 1];
      if (first.lat !== last.lat || first.lng !== last.lng) closed.push(first);
      return closed.map((p) => new TMap.LatLng(p.lat, p.lng));
    }
    _cancelCommitDrag() {
      if (this._commitDragId && this.ctx) {
        this.ctx.map;
        if (this._commitMmHandler) document.removeEventListener("mousemove", this._commitMmHandler);
        if (this._commitMuHandler) document.removeEventListener("mouseup", this._commitMuHandler);
      }
      this._commitDragId = null;
      this._commitDragStartLatLng = null;
      this._commitDragOrigCenter = null;
      this._commitMmHandler = null;
      this._commitMuHandler = null;
    }
    // ══════════════════════════════════════════════════════════════════
    // 查询
    // ══════════════════════════════════════════════════════════════════
    isCircle(id) {
      return this.circleIds.has(id);
    }
    getCircleInfo(id) {
      const center = this.circleCenters.get(id);
      const params = this.circleParams.get(id);
      if (!center || !params) return null;
      return { center, ...params };
    }
    /**
     * 导出所有已提交圆形的内部状态，供 ToolManager 补充到快照里。
     * overlay-manager.snapshot() 只保存几何（polygon 形式），
     * 丢失了 center/radius/nPoints，SPA 恢复后圆形无法再交互。
     */
    getAllCircles() {
      const result = [];
      for (const id of this.circleIds) {
        const center = this.circleCenters.get(id);
        const params = this.circleParams.get(id);
        if (center && params) {
          result.push({ id, center: { ...center }, radius: params.radius, nPoints: params.nPoints });
        }
      }
      return result;
    }
    /**
     * SPA 切换后地图重建，从快照恢复 CircleTool 内部状态。
     * overlay-manager.restore() 会重建多边形图层（几何），这里只补充内部 Map。
     * 同时重新注册点击 / mousedown 回调，让圆形可交互。
     * 注意：此方法不依赖 this.ctx，直接接收外部 ctx 参数，避免 activate/deactivate 的 ctx 生命周期问题。
     */
    registerFromSnapshot(items, ctx) {
      for (const item of items) {
        const points = this._generatePoints(item.center, item.radius, item.nPoints);
        ctx.overlays.addPolygon(item.id, points, () => {
        }, void 0);
        this.circleIds.add(item.id);
        this.circleCenters.set(item.id, item.center);
        this.circleParams.set(item.id, { radius: item.radius, nPoints: item.nPoints });
        this.circleCoords.set(item.id, points);
        const { area, perimeter } = points.length >= 3 ? this._computeGeometry(points) : { area: 0, perimeter: 0 };
        sendToPanel({
          type: HookEvent.LAYER_DRAWN,
          payload: {
            id: item.id,
            kind: "circle",
            data: { kind: "circle", center: item.center, radius: item.radius, nPoints: item.nPoints, area, perimeter }
          }
        });
      }
      ctx.overlays.setCircleClickHandler((id) => {
        if (!this.circleIds.has(id)) return;
        const info = this.getCircleInfo(id);
        if (!info) return;
        const coords = this.circleCoords.get(id);
        const { area, perimeter } = coords ? this._computeGeometry(coords) : { area: 0, perimeter: 0 };
        sendToPanel({
          type: HookEvent.LAYER_SELECTED,
          payload: { id, data: { kind: "circle", center: info.center, radius: info.radius, nPoints: info.nPoints, area, perimeter } }
        });
      });
      ctx.overlays.setCircleMousedownHandler((id, latLng) => {
        if (!this.ctx) {
          this.ctx = ctx;
        }
        this._onCircleMousedown(id, latLng);
      });
      log("CircleTool.registerFromSnapshot:", items.length, "circles");
    }
    getMode() {
      return this.mode;
    }
    // ══════════════════════════════════════════════════════════════════
    // 几何计算（与旧版相同）
    // ══════════════════════════════════════════════════════════════════
    _updatePreview(center, radius, nPoints) {
      var _a;
      const points = this._generatePoints(center, radius, nPoints);
      (_a = this.ctx) == null ? void 0 : _a.overlays.setPreviewPolygon(PREVIEW_ID, points, () => {
      });
    }
    _updateEditPreview() {
      var _a;
      if (!this.editCenter || !this.editingId) return;
      const points = this._generatePoints(this.editCenter, this.editRadius, this.editNPoints);
      (_a = this.ctx) == null ? void 0 : _a.overlays.setPreviewPolygon(this.editingId, points, () => {
      }, void 0);
    }
    _generatePoints(center, radius, n) {
      var _a;
      const TMap = window.TMap;
      if (!((_a = TMap == null ? void 0 : TMap.geometry) == null ? void 0 : _a.computeDestination)) {
        log("_generatePoints: TMap.geometry.computeDestination not available, using fallback");
        return this._fallbackPoints(center, radius, n);
      }
      const points = [];
      const step = 360 / n;
      const tmapCenter = new TMap.LatLng(center.lat, center.lng);
      for (let i = 0; i < n; i++) {
        const raw = i * step;
        const heading = raw > 180 ? raw - 360 : raw;
        try {
          const dest = TMap.geometry.computeDestination(tmapCenter, heading, radius);
          if (dest) points.push({ lat: dest.getLat(), lng: dest.getLng() });
        } catch {
          log("_generatePoints: computeDestination threw, falling back to local");
          return this._fallbackPoints(center, radius, n);
        }
      }
      return points;
    }
    _fallbackPoints(center, radius, n) {
      const points = [];
      const step = 2 * Math.PI / n;
      const latPerM = 1 / 111320;
      for (let i = 0; i < n; i++) {
        const angle = i * step;
        const cosA = Math.cos(angle);
        const lngPerM = 1 / (111320 * Math.cos(center.lat * Math.PI / 180));
        points.push({
          lat: center.lat + radius * Math.sin(angle) * latPerM,
          lng: center.lng + radius * cosA * lngPerM
        });
      }
      return points;
    }
    _computeGeometry(points) {
      try {
        const TMap = window.TMap;
        if (!(TMap == null ? void 0 : TMap.geometry)) return { area: 0, perimeter: 0 };
        const path = points.map((p) => new TMap.LatLng(p.lat, p.lng));
        const closedPath = [...path, path[0]];
        return {
          area: TMap.geometry.computeArea(closedPath),
          perimeter: TMap.geometry.computeDistance(closedPath)
        };
      } catch {
        return { area: 0, perimeter: 0 };
      }
    }
    _cleanupAll() {
      this._stopDrag();
      this._stopPlacedDrag();
      this.isDragging = false;
      this._removeCenterHandle();
    }
  }
  function parseCoords(input) {
    const s = input.trim();
    if (!s) return null;
    if (s.startsWith("[")) {
      try {
        const arr = JSON.parse(s);
        if (!Array.isArray(arr) || arr.length < 3) return null;
        if (!Array.isArray(arr[0])) return null;
        const result = arr.map(([lng, lat]) => ({ lat, lng }));
        if (result.some((p) => isNaN(p.lat) || isNaN(p.lng))) return null;
        return result;
      } catch {
      }
    }
    if (s.includes(";")) {
      const pairs = s.split(";").map((p) => p.trim()).filter(Boolean);
      if (pairs.length < 3) return null;
      const result = pairs.map((p) => {
        const parts = p.split(",").map(Number);
        return { lat: parts[1], lng: parts[0] };
      });
      if (result.some((p) => isNaN(p.lat) || isNaN(p.lng))) return null;
      return result;
    }
    return null;
  }
  function coordsToText(points) {
    return JSON.stringify(points.map((p) => [p.lng, p.lat]));
  }
  function parsePointCoords(input) {
    const s = input.trim();
    if (!s) return null;
    if (s.startsWith("[")) {
      try {
        const arr = JSON.parse(s);
        if (!Array.isArray(arr) || arr.length === 0) return null;
        if (Array.isArray(arr[0])) {
          const result = arr.map(([lng2, lat2]) => ({ lat: lat2, lng: lng2 }));
          if (result.some((p) => isNaN(p.lat) || isNaN(p.lng))) return null;
          return result;
        }
        if (arr.length < 2) return null;
        const lng = Number(arr[0]);
        const lat = Number(arr[1]);
        if (isNaN(lat) || isNaN(lng)) return null;
        return [{ lat, lng }];
      } catch {
      }
    }
    if (s.includes(";")) {
      const pairs = s.split(";").map((p) => p.trim()).filter(Boolean);
      if (pairs.length === 0) return null;
      const result = pairs.map((p) => {
        const parts = p.split(",").map(Number);
        return { lat: parts[1], lng: parts[0] };
      });
      if (result.some((p) => isNaN(p.lat) || isNaN(p.lng))) return null;
      return result;
    }
    return null;
  }
  const _PolygonTool = class _PolygonTool {
    constructor() {
      this.id = TOOL_IDS.POLYGON;
      this.ctx = null;
      this.overlays = null;
      this.mapRef = null;
      this.mode = "idle";
      this.drawingPoints = [];
      this.selectedId = null;
      this.polygonIds = /* @__PURE__ */ new Set();
      this.polygonCoords = /* @__PURE__ */ new Map();
      this.idCounter = 0;
      this.drawClickHandler = null;
      this.mousemoveHandler = null;
      this.dblClickHandler = null;
      this.keydownHandler = null;
      this.editingId = null;
      this.editOriginalCoords = null;
      this.editCurrentCoords = null;
      this.editor = null;
      this.editLayer = null;
      this.isDragging = false;
      this.dragStartLatLng = null;
      this.dragOriginalCoords = null;
      this.draggingId = null;
      this.dragCurrentCoords = null;
      this._justFinishedDrag = false;
      this.dragMoveHandler = null;
      this.dragUpHandler = null;
      this.idleMapClickHandler = null;
      this._polygonClickFired = false;
    }
    // ── ITool interface ───────────────────────────────────────────────────────
    /** 供 OverlayManager.restore() 使用的多边形点击回调。 */
    getClickHandler() {
      return (id) => this._onPolygonClick(id);
    }
    /** 供 OverlayManager.restore() 使用的多边形 mousedown 回调。 */
    getMousedownHandler() {
      return (id, latLng) => this._onPolygonMousedown(id, latLng);
    }
    /**
     * SPA 切换后从快照恢复 PolygonTool 内部状态。
     * overlay-manager.restore() 只重建了图层几何体和内部 polygons Map，
     * PolygonTool.polygonCoords 和 Panel 的 layers 列表需要重新同步。
     */
    registerFromRestore(items) {
      for (const item of items) {
        this.polygonCoords.set(item.id, item.points);
        const { area, perimeter } = this._tryComputeGeometry(item.points);
        sendToPanel({
          type: HookEvent.LAYER_DRAWN,
          payload: {
            id: item.id,
            kind: "polygon",
            data: { kind: "polygon", coords: item.points, area, perimeter }
          }
        });
      }
      log("PolygonTool.registerFromRestore:", items.length, "polygons");
    }
    activate(ctx) {
      this.ctx = ctx;
      this.overlays = ctx.overlays;
      this.mapRef = ctx.map;
      this.mode = "idle";
      this._registerIdleClick();
      log("PolygonTool activated (idle mode)");
    }
    deactivate() {
      if (this.editingId !== null) {
        this._cancelEditInternal();
      }
      if (this.mode === "drawing") {
        this._cleanupDrawingState();
      }
      this._unregisterIdleClick();
      this._cleanupDrag();
      this.ctx = null;
      log("PolygonTool deactivated");
    }
    /**
     * 清除所有已绘制多边形及绘制状态，响应 CLEAR 命令。
     * Panel 层的 clear() 已重置 polygonLayers，此处只负责清理地图覆盖物。
     */
    reset() {
      if (this.editingId !== null) {
        this._cancelEditInternal();
      }
      if (this.mode === "drawing") {
        this._cleanupDrawingState();
      }
      if (this.ctx) {
        for (const id of this.polygonIds) {
          this.ctx.overlays.removePolygon(id);
        }
      }
      this.polygonIds.clear();
      this.polygonCoords.clear();
      this.selectedId = null;
      this.idCounter = 0;
      log("PolygonTool reset — all polygons cleared");
    }
    // ── Mode transitions ──────────────────────────────────────────────────────
    /** 进入绘制模式：注册所有绘制相关事件监听器，取消当前选中。 */
    enterDrawingMode() {
      if (!this.ctx) return;
      if (this.editingId !== null) {
        this._cancelEditInternal();
      }
      this._cleanupDrawingState();
      this._unregisterIdleClick();
      this.mode = "drawing";
      this.drawingPoints = [];
      this.selectedId = null;
      this.ctx.overlays.setPolygonHighlight(null);
      this.drawClickHandler = (evt) => this.onMapClick(evt);
      this.ctx.map.on("click", this.drawClickHandler);
      this.mousemoveHandler = (evt) => this.onMouseMove(evt);
      this.ctx.map.on("mousemove", this.mousemoveHandler);
      this.dblClickHandler = (evt) => this.onDblClick(evt);
      this.ctx.map.on("dblclick", this.dblClickHandler);
      this.keydownHandler = (evt) => this.onKeydown(evt);
      document.addEventListener("keydown", this.keydownHandler);
      sendToPanel({ type: HookEvent.POLYGON_MODE_CHANGED, payload: { mode: "drawing", drawingPointCount: 0 } });
      log("PolygonTool enterDrawingMode");
    }
    /** 完成当前绘制：至少需要 3 个顶点，生成多边形后进入 idle 模式。 */
    finishDrawing() {
      if (this.drawingPoints.length < 3 || !this.ctx) return;
      const id = `poly-${++this.idCounter}`;
      const count = this.drawingPoints.length;
      const coords = [...this.drawingPoints];
      this.ctx.overlays.addPolygon(
        id,
        coords,
        (clickedId) => this._onPolygonClick(clickedId),
        (clickedId, latLng) => this._onPolygonMousedown(clickedId, latLng)
      );
      this.polygonIds.add(id);
      this.polygonCoords.set(id, coords);
      sendToPanel({ type: HookEvent.LAYER_DRAWN, payload: { id, kind: "polygon", data: { kind: "polygon", coords, area: null, perimeter: null } } });
      this._sendGeometryInfo(id, coords);
      log("polygon finished, id =", id, "points =", count);
      this.enterIdleMode();
    }
    /** 取消当前绘制：丢弃所有打点，进入 idle 模式。 */
    cancelDrawing() {
      log("PolygonTool cancelDrawing");
      this.enterIdleMode();
    }
    /** 进入 idle（选择）模式：注销绘制事件，清理临时覆盖物。 */
    enterIdleMode() {
      this._cleanupDrawingState();
      this._registerIdleClick();
      sendToPanel({ type: HookEvent.POLYGON_MODE_CHANGED, payload: { mode: "idle", drawingPointCount: 0 } });
      log("PolygonTool enterIdleMode");
    }
    /**
     * 清理绘制状态（注销事件监听、移除临时覆盖物）而不发送 mode 事件。
     * 供 enterIdleMode、deactivate、reset 内部调用，避免代码重复。
     */
    _cleanupDrawingState() {
      this.mode = "idle";
      if (this.ctx) {
        if (this.drawClickHandler) {
          this.ctx.map.off("click", this.drawClickHandler);
          this.drawClickHandler = null;
        }
        if (this.mousemoveHandler) {
          this.ctx.map.off("mousemove", this.mousemoveHandler);
          this.mousemoveHandler = null;
        }
        if (this.dblClickHandler) {
          this.ctx.map.off("dblclick", this.dblClickHandler);
          this.dblClickHandler = null;
        }
        this._clearDrawingMarkers();
        this.ctx.overlays.removeRubberBand(_PolygonTool.RUBBER_BAND_ID);
        this.ctx.overlays.removePreviewPolygon(_PolygonTool.PREVIEW_POLY_ID);
      }
      if (this.keydownHandler) {
        document.removeEventListener("keydown", this.keydownHandler);
        this.keydownHandler = null;
      }
      this.drawingPoints = [];
    }
    // ── Public commands ───────────────────────────────────────────────────────
    /**
     * 从坐标文本直接绘制多边形（坐标导入入口）。
     * 若当前在绘制模式则先取消，解析成功后立即进入 idle 模式。
     */
    drawFromInput(input) {
      if (!this.ctx) return;
      if (this.mode === "drawing") {
        this.enterIdleMode();
      }
      const points = parseCoords(input);
      if (!points || points.length < 3) {
        log("drawFromInput: failed to parse or too few points:", input);
        return;
      }
      const id = `poly-${++this.idCounter}`;
      this.ctx.overlays.addPolygon(
        id,
        points,
        (clickedId) => this._onPolygonClick(clickedId),
        (clickedId, latLng) => this._onPolygonMousedown(clickedId, latLng)
      );
      this.polygonIds.add(id);
      this.polygonCoords.set(id, points);
      sendToPanel({ type: HookEvent.LAYER_DRAWN, payload: { id, kind: "polygon", data: { kind: "polygon", coords: points, area: null, perimeter: null } } });
      this._sendGeometryInfo(id, points);
      log("polygon drawn from input, id =", id, "points =", points.length);
    }
    /** 撤销绘制中的最后一个顶点。 */
    undoDrawingPoint() {
      var _a, _b, _c;
      if (this.mode !== "drawing" || this.drawingPoints.length === 0) return;
      this._popLastDrawingPoint();
      if (this.drawingPoints.length === 0) {
        (_a = this.ctx) == null ? void 0 : _a.overlays.removeRubberBand(_PolygonTool.RUBBER_BAND_ID);
      }
      if (this.drawingPoints.length >= 3) {
        (_b = this.ctx) == null ? void 0 : _b.overlays.setPreviewPolygon(
          _PolygonTool.PREVIEW_POLY_ID,
          this.drawingPoints,
          (id) => this._onPolygonClick(id)
        );
      } else {
        (_c = this.ctx) == null ? void 0 : _c.overlays.removePreviewPolygon(_PolygonTool.PREVIEW_POLY_ID);
      }
      const coordsText = coordsToText(this.drawingPoints);
      sendToPanel({
        type: HookEvent.POLYGON_POINT_REMOVED,
        payload: { newCount: this.drawingPoints.length, coordsText }
      });
      log("polygon point undone, remaining:", this.drawingPoints.length);
    }
    /** 按 id 删除指定多边形（Panel 图层列表删除按钮触发）。 */
    deleteById(id) {
      if (!this.ctx) return;
      if (this.editingId === id) {
        this._cancelEditInternal();
      }
      this.ctx.overlays.removePolygon(id);
      this.polygonIds.delete(id);
      this.polygonCoords.delete(id);
      if (this.selectedId === id) {
        this.selectedId = null;
      }
      sendToPanel({ type: HookEvent.LAYER_DELETED, payload: { id } });
      log("polygon deleted by id:", id);
    }
    /** 切换指定多边形的地图可见性。 */
    setVisible(id, visible) {
      var _a;
      (_a = this.ctx) == null ? void 0 : _a.overlays.setPolygonVisible(id, visible);
    }
    /** Panel 图层列表选中某行时主动触发高亮（非地图点击路径）。 */
    selectById(id, panToLocation = false) {
      var _a;
      if (this.mode === "drawing") return;
      if (this.selectedId === id) return;
      this.selectedId = id;
      (_a = this.overlays) == null ? void 0 : _a.setPolygonHighlight(id);
      const coords = this.polygonCoords.get(id) ?? [];
      if (panToLocation && coords.length > 0 && this.ctx) {
        this._panToCenter(coords);
      }
      sendToPanel({ type: HookEvent.LAYER_SELECTED, payload: { id, data: { kind: "polygon", coords, area: null, perimeter: null } } });
      this._sendGeometryInfo(id, coords);
      log("polygon selected by panel:", id);
    }
    // ── Map event handlers ────────────────────────────────────────────────────
    onMapClick(evt) {
      if (!this.ctx || this.mode !== "drawing") return;
      const latlng = { lat: evt.latLng.lat, lng: evt.latLng.lng };
      const index = this.drawingPoints.length;
      this.drawingPoints.push(latlng);
      this.ctx.overlays.addMarker(`poly-drawing-${index}`, latlng, String(index + 1));
      if (this.drawingPoints.length >= 3) {
        this.ctx.overlays.setPreviewPolygon(
          _PolygonTool.PREVIEW_POLY_ID,
          this.drawingPoints,
          (id) => this._onPolygonClick(id)
        );
      }
      const coordsText = coordsToText(this.drawingPoints);
      sendToPanel({
        type: HookEvent.POLYGON_POINT_ADDED,
        payload: { lat: latlng.lat, lng: latlng.lng, index, coordsText }
      });
      log("polygon point added:", latlng, "total:", this.drawingPoints.length);
    }
    /** 鼠标移动时更新橡皮筋预览线（所有已打点 + 当前光标位置）。 */
    onMouseMove(evt) {
      if (!this.ctx || this.mode !== "drawing" || this.drawingPoints.length === 0) return;
      const cursor = { lat: evt.latLng.lat, lng: evt.latLng.lng };
      this.ctx.overlays.setRubberBand(_PolygonTool.RUBBER_BAND_ID, [...this.drawingPoints, cursor]);
    }
    /**
     * 双击完成多边形。
     * TMap 双击事件触发顺序：click（第一下）→ click（第二下）→ dblclick。
     * 第二下 click 已经向 drawingPoints 添加了一个点，这里需要先弹出再提交。
     */
    onDblClick(_evt) {
      if (this.mode !== "drawing") return;
      this._popLastDrawingPoint();
      this.finishDrawing();
    }
    onKeydown(evt) {
      if (evt.key === "Escape") {
        evt.preventDefault();
        this.cancelDrawing();
      }
    }
    /** 点击已有多边形时的回调（图层级注册，通过 evt.geometry.id 路由）。 */
    _onPolygonClick(id) {
      var _a;
      this._polygonClickFired = true;
      if (id === _PolygonTool.PREVIEW_POLY_ID) return;
      if (this.mode === "drawing") return;
      if (this.editingId !== null) return;
      if (this._justFinishedDrag) return;
      if (this.selectedId === id) return;
      this.selectedId = id;
      (_a = this.overlays) == null ? void 0 : _a.setPolygonHighlight(id);
      const coords = this.polygonCoords.get(id) ?? [];
      sendToPanel({ type: HookEvent.LAYER_SELECTED, payload: { id, data: { kind: "polygon", coords, area: null, perimeter: null } } });
      this._sendGeometryInfo(id, coords);
      log("polygon selected:", id);
    }
    // ── Idle-click deselect ───────────────────────────────────────────────────
    _registerIdleClick() {
      if (this.idleMapClickHandler || !this.ctx) return;
      this.idleMapClickHandler = (_evt) => {
        var _a;
        if (this._polygonClickFired) {
          this._polygonClickFired = false;
          return;
        }
        if (this.selectedId !== null) {
          this.selectedId = null;
          (_a = this.ctx) == null ? void 0 : _a.overlays.setPolygonHighlight(null);
          sendToPanel({ type: HookEvent.LAYER_SELECTED, payload: { id: "" } });
          log("polygon deselected (map click)");
        }
      };
      this.ctx.map.on("click", this.idleMapClickHandler);
    }
    _unregisterIdleClick() {
      if (!this.idleMapClickHandler || !this.ctx) return;
      this.ctx.map.off("click", this.idleMapClickHandler);
      this.idleMapClickHandler = null;
    }
    // ── Polygon drag ──────────────────────────────────────────────────────────
    _onPolygonMousedown(id, latLng) {
      log("[drag] mousedown — id:", id, "mode:", this.mode, "selectedId:", this.selectedId);
      if (this.editingId !== null) return;
      if (this.mode !== "idle") return;
      if (id === _PolygonTool.PREVIEW_POLY_ID) return;
      if (!this.overlays || !this.mapRef) {
        log("[drag] SKIP — missing overlays/mapRef");
        return;
      }
      if (id !== this.selectedId) {
        this.selectedId = id;
        this.overlays.setPolygonHighlight(id);
        const coords = this.polygonCoords.get(id) ?? [];
        sendToPanel({ type: HookEvent.LAYER_SELECTED, payload: { id, data: { kind: "polygon", coords, area: null, perimeter: null } } });
        this._sendGeometryInfo(id, coords);
      }
      const originalCoords = this.polygonCoords.get(id);
      if (!originalCoords) return;
      this.isDragging = true;
      this.draggingId = id;
      this.dragStartLatLng = { lat: latLng.lat, lng: latLng.lng };
      this.dragOriginalCoords = [...originalCoords];
      this.dragCurrentCoords = null;
      try {
        this.mapRef.setDraggable(false);
      } catch (e) {
        log("[drag] map.setDraggable(false) threw:", e);
      }
      const dragMoveLogger = [];
      this.dragMoveHandler = (evt) => {
        if (!this.mapRef || !this.overlays || !this.isDragging) return;
        dragMoveLogger.push({ t: Date.now(), x: evt.clientX, y: evt.clientY });
        const container = this.mapRef.getContainer();
        const rect = container.getBoundingClientRect();
        const TMap = window.TMap;
        let latLng2;
        try {
          const point = new TMap.Point(evt.clientX - rect.left, evt.clientY - rect.top);
          const projected = this.mapRef.unprojectFromContainer(point);
          latLng2 = { lat: projected.lat, lng: projected.lng };
        } catch (e) {
          log("[drag] unproject FAILED:", (e == null ? void 0 : e.message) ?? e);
          return;
        }
        this._onDragMove({ latLng: latLng2, _seq: dragMoveLogger.length });
      };
      this.dragUpHandler = () => {
        log("[drag] mouseup — moved:", dragMoveLogger.length, "times");
        this._onDragUp();
      };
      document.addEventListener("mousemove", this.dragMoveHandler);
      document.addEventListener("mouseup", this.dragUpHandler);
      log("[drag] started");
    }
    _onDragMove(evt) {
      if (!this.isDragging || !this.dragStartLatLng || !this.dragOriginalCoords || !this.draggingId || !this.overlays) return;
      const dLat = evt.latLng.lat - this.dragStartLatLng.lat;
      const dLng = evt.latLng.lng - this.dragStartLatLng.lng;
      const newCoords = this.dragOriginalCoords.map((p) => ({ lat: p.lat + dLat, lng: p.lng + dLng }));
      this.dragCurrentCoords = newCoords;
      this.overlays.updatePolygonPath(this.draggingId, newCoords);
    }
    _onDragUp() {
      if (!this.isDragging || !this.dragOriginalCoords || !this.draggingId || !this.overlays || !this.mapRef) return;
      const finalCoords = this.dragCurrentCoords ?? [...this.dragOriginalCoords];
      const id = this.draggingId;
      this.polygonCoords.set(id, finalCoords);
      this.overlays.addPolygon(
        id,
        finalCoords,
        (clickedId) => this._onPolygonClick(clickedId),
        (clickedId, latLng) => this._onPolygonMousedown(clickedId, latLng)
      );
      this.overlays.setPolygonHighlight(id);
      const { area, perimeter } = this._tryComputeGeometry(finalCoords);
      sendToPanel({ type: HookEvent.LAYER_SELECTED, payload: { id, data: { kind: "polygon", coords: finalCoords, area, perimeter } } });
      if (area === null) this._sendGeometryInfo(id, finalCoords);
      this._cleanupDrag();
      try {
        this.mapRef.setDraggable(true);
      } catch {
      }
      this._justFinishedDrag = true;
      setTimeout(() => {
        this._justFinishedDrag = false;
      }, 100);
      log("polygon drag end:", id);
    }
    _cleanupDrag() {
      if (this.dragMoveHandler) {
        document.removeEventListener("mousemove", this.dragMoveHandler);
        this.dragMoveHandler = null;
      }
      if (this.dragUpHandler) {
        document.removeEventListener("mouseup", this.dragUpHandler);
        this.dragUpHandler = null;
      }
      this.isDragging = false;
      this.draggingId = null;
      this.dragStartLatLng = null;
      this.dragOriginalCoords = null;
      this.dragCurrentCoords = null;
    }
    // ── Polygon editing ───────────────────────────────────────────────────────
    /** 进入顶点编辑模式，使用 TMap.tools.GeometryEditor 在隔离图层上编辑指定多边形。 */
    startEditById(id) {
      var _a;
      if (!this.ctx) return;
      const TMap = window.TMap;
      if (!((_a = TMap == null ? void 0 : TMap.tools) == null ? void 0 : _a.GeometryEditor)) {
        log("startEditById: TMap.tools.GeometryEditor not available");
        return;
      }
      if (this.editingId !== null) {
        this._cancelEditInternal();
      }
      if (this.mode === "drawing") {
        this._cleanupDrawingState();
        sendToPanel({ type: HookEvent.POLYGON_MODE_CHANGED, payload: { mode: "idle", drawingPointCount: 0 } });
      }
      const originalCoords = this.polygonCoords.get(id);
      if (!originalCoords) return;
      this.editOriginalCoords = [...originalCoords];
      this.editCurrentCoords = null;
      this.editingId = id;
      this.ctx.overlays.setPolygonVisible(id, false);
      const closedPath = [...originalCoords];
      if (closedPath.length > 0) {
        const first = closedPath[0];
        const last = closedPath[closedPath.length - 1];
        if (first.lat !== last.lat || first.lng !== last.lng) closedPath.push(first);
      }
      const tmapPath = closedPath.map((p) => new TMap.LatLng(p.lat, p.lng));
      this.editLayer = new TMap.MultiPolygon({
        map: this.ctx.map,
        styles: {
          default: new TMap.PolygonStyle({
            color: "rgba(74, 144, 217, 0.12)",
            borderColor: "#4A90D9",
            borderWidth: 2
          }),
          highlight: new TMap.PolygonStyle({
            color: "rgba(74, 144, 217, 0.3)",
            borderColor: "#2B6CB0",
            borderWidth: 3
          })
        },
        geometries: [{ id, styleId: "default", paths: [tmapPath] }]
      });
      this.editor = new TMap.tools.GeometryEditor({
        map: this.ctx.map,
        overlayList: [{ overlay: this.editLayer, id: "edit-layer", selectedStyleId: "highlight" }],
        actionMode: TMap.tools.constants.EDITOR_ACTION.INTERACT,
        activeOverlayId: "edit-layer",
        selectable: true,
        snappable: true
      });
      this.editor.on("adjust_complete", (result) => {
        var _a2;
        log("adjust_complete fired, result keys:", result ? Object.keys(result).join(",") : "null");
        this._syncEditCoords(result);
        log("after adjust_complete sync, editCurrentCoords count:", ((_a2 = this.editCurrentCoords) == null ? void 0 : _a2.length) ?? "null");
      });
      this.editor.on("delete_complete", (result) => {
        log("delete_complete fired");
        this._syncEditCoords(result);
      });
      try {
        this.editor.select([id]);
      } catch (e) {
        log("startEditById: auto-select failed:", e);
      }
      this._unregisterIdleClick();
      sendToPanel({ type: HookEvent.LAYER_EDIT_STARTED, payload: { id, kind: "polygon" } });
      log("startEditById:", id);
    }
    /** 提交编辑：用最终坐标更新主层，销毁编辑器。 */
    finishEdit() {
      if (!this.ctx || this.editingId === null) return;
      this._syncEditCoords();
      const id = this.editingId;
      log("finishEdit:", id, "- editCurrentCoords:", this.editCurrentCoords ? this.editCurrentCoords.length + " pts" : "null — falling back to original");
      const finalCoords = this.editCurrentCoords ?? this.editOriginalCoords;
      this._destroyEditor();
      this.polygonCoords.set(id, finalCoords);
      this.ctx.overlays.addPolygon(
        id,
        finalCoords,
        (clickedId) => this._onPolygonClick(clickedId),
        (clickedId, latLng) => this._onPolygonMousedown(clickedId, latLng)
      );
      this.ctx.overlays.setPolygonVisible(id, true);
      this.editingId = null;
      this._registerIdleClick();
      sendToPanel({ type: HookEvent.LAYER_EDIT_COMMITTED, payload: { id, kind: "polygon" } });
      sendToPanel({ type: HookEvent.LAYER_DRAWN, payload: { id, kind: "polygon", data: { kind: "polygon", coords: finalCoords, area: null, perimeter: null } } });
      this._sendGeometryInfo(id, finalCoords);
      log("finishEdit:", id);
    }
    /** 取消编辑：恢复原始多边形，销毁编辑器。 */
    cancelEdit() {
      if (this.editingId === null) return;
      const id = this.editingId;
      this._cancelEditInternal();
      sendToPanel({ type: HookEvent.LAYER_EDIT_CANCELLED, payload: { id, kind: "polygon" } });
      log("cancelEdit:", id);
    }
    /** 内部取消逻辑（不发送 CANCELLED 事件，供 deactivate/reset 等场景调用）。 */
    _cancelEditInternal() {
      if (this.editingId === null) return;
      const id = this.editingId;
      this._destroyEditor();
      if (this.ctx) {
        this.ctx.overlays.setPolygonVisible(id, true);
      }
      this.editingId = null;
      if (this.ctx) {
        this._registerIdleClick();
      }
    }
    _destroyEditor() {
      var _a, _b, _c, _d, _e, _f;
      try {
        (_b = (_a = this.editor) == null ? void 0 : _a.setMap) == null ? void 0 : _b.call(_a, null);
      } catch {
      }
      try {
        (_d = (_c = this.editor) == null ? void 0 : _c.destroy) == null ? void 0 : _d.call(_c);
      } catch {
      }
      try {
        (_f = (_e = this.editLayer) == null ? void 0 : _e.setMap) == null ? void 0 : _f.call(_e, null);
      } catch {
      }
      this.editor = null;
      this.editLayer = null;
      this.editOriginalCoords = null;
      this.editCurrentCoords = null;
    }
    /**
     * 从编辑器事件结果或 editLayer 中读取最新坐标并缓存。
     * 优先使用事件结果中的 geometry.paths（adjust_complete 直接携带最新数据），
     * 若缺失则回落到 editLayer.getGeometries()。
     */
    _syncEditCoords(result) {
      var _a, _b, _c;
      if (result == null ? void 0 : result.paths) {
        const paths2 = result.paths;
        const rawPts2 = Array.isArray(paths2[0]) ? paths2[0] : paths2;
        if (rawPts2.length > 0) {
          log("_syncEditCoords: using result.geometry.paths, pts:", rawPts2.length);
          this.editCurrentCoords = this._normalizeEditCoords(rawPts2);
          return;
        }
      }
      if (!this.editLayer) {
        log("_syncEditCoords: no editLayer");
        return;
      }
      const geos = (_b = (_a = this.editLayer).getGeometries) == null ? void 0 : _b.call(_a);
      log("_syncEditCoords: getGeometries returned", geos ? geos.length + " geos" : "null");
      if (!geos || geos.length === 0) return;
      const paths = (_c = geos[0]) == null ? void 0 : _c.paths;
      log("_syncEditCoords: paths type:", Array.isArray(paths) ? "array len=" + paths.length : typeof paths);
      if (!paths || paths.length === 0) return;
      const rawPts = Array.isArray(paths[0]) ? paths[0] : paths;
      log("_syncEditCoords: rawPts len:", rawPts.length, "first item type:", rawPts[0] ? typeof rawPts[0] : "empty");
      if (rawPts.length === 0) return;
      this.editCurrentCoords = this._normalizeEditCoords(rawPts);
      log("_syncEditCoords: normalized to", this.editCurrentCoords.length, "pts");
    }
    _normalizeEditCoords(pts) {
      let coords = pts.map((p) => ({
        lat: typeof p.getLat === "function" ? p.getLat() : p.lat,
        lng: typeof p.getLng === "function" ? p.getLng() : p.lng
      }));
      if (coords.length > 1) {
        const first = coords[0];
        const last = coords[coords.length - 1];
        if (first.lat === last.lat && first.lng === last.lng) coords = coords.slice(0, -1);
      }
      return coords;
    }
    // ── Helpers ───────────────────────────────────────────────────────────────
    _panToCenter(coords) {
      if (!this.ctx) return;
      const lats = coords.map((p) => p.lat);
      const lngs = coords.map((p) => p.lng);
      const centerLat = (Math.min(...lats) + Math.max(...lats)) / 2;
      const centerLng = (Math.min(...lngs) + Math.max(...lngs)) / 2;
      const TMap = window.TMap;
      const center = new TMap.LatLng(centerLat, centerLng);
      if (typeof this.ctx.map.panTo === "function") {
        this.ctx.map.panTo(center);
      } else {
        this.ctx.map.setCenter(center);
      }
    }
    _popLastDrawingPoint() {
      var _a;
      if (this.drawingPoints.length === 0) return;
      const lastIdx = this.drawingPoints.length - 1;
      (_a = this.ctx) == null ? void 0 : _a.overlays.removeMarker(`poly-drawing-${lastIdx}`);
      this.drawingPoints.pop();
    }
    _clearDrawingMarkers() {
      if (!this.ctx) return;
      for (let i = 0; i < this.drawingPoints.length; i++) {
        this.ctx.overlays.removeMarker(`poly-drawing-${i}`);
      }
    }
    /** 计算多边形面积和周长，并通过协议发送给 panel。 */
    _sendGeometryInfo(id, coords) {
      if (!this.ctx || coords.length < 3) return;
      const TMap = window.TMap;
      if (!(TMap == null ? void 0 : TMap.geometry)) return;
      try {
        const path = coords.map((p) => new TMap.LatLng(p.lat, p.lng));
        const closedPath = [...path, path[0]];
        const perimeter = TMap.geometry.computeDistance(closedPath);
        const area = TMap.geometry.computeArea(closedPath);
        sendToPanel({
          type: HookEvent.POLYGON_GEOMETRY,
          payload: { id, area, perimeter }
        });
        log("_sendGeometryInfo:", id, "area:", area, "perimeter:", perimeter);
      } catch (e) {
        log("_sendGeometryInfo failed:", e);
      }
    }
    /**
     * 同步计算多边形面积和周长，失败时返回 null。
     * 供 _onDragUp / finishEdit 等需要在同一消息里携带几何数据的场景使用，
     * 避免先发 null 再补发 POLYGON_GEOMETRY 产生的时序依赖。
     */
    _tryComputeGeometry(coords) {
      if (coords.length < 3) return { area: null, perimeter: null };
      const TMap = window.TMap;
      if (!(TMap == null ? void 0 : TMap.geometry)) return { area: null, perimeter: null };
      try {
        const path = coords.map((p) => new TMap.LatLng(p.lat, p.lng));
        const closedPath = [...path, path[0]];
        const perimeter = TMap.geometry.computeDistance(closedPath);
        const area = TMap.geometry.computeArea(closedPath);
        return { area, perimeter };
      } catch (e) {
        log("_tryComputeGeometry failed:", e);
        return { area: null, perimeter: null };
      }
    }
  };
  _PolygonTool.RUBBER_BAND_ID = "poly-rubber-band";
  _PolygonTool.PREVIEW_POLY_ID = "poly-preview";
  let PolygonTool = _PolygonTool;
  class PointMarkerTool {
    constructor() {
      this.id = TOOL_IDS.POINT_MARKER;
      this.ctx = null;
      this.points = /* @__PURE__ */ new Map();
      this.pointNames = /* @__PURE__ */ new Map();
      this.idCounter = 0;
      this.selectedId = null;
      this.clickHandler = null;
    }
    // ── ITool interface ───────────────────────────────────────────────────────
    activate(ctx) {
      this.ctx = ctx;
      this.clickHandler = (evt) => this.onMapClick(evt);
      ctx.map.on("click", this.clickHandler);
      log("PointMarkerTool activated");
    }
    deactivate() {
      if (this.ctx && this.clickHandler) {
        this.ctx.map.off("click", this.clickHandler);
      }
      this.clickHandler = null;
      this.ctx = null;
      log("PointMarkerTool deactivated");
    }
    reset() {
      if (this.ctx) {
        for (const id of this.points.keys()) {
          this.ctx.overlays.removePointMarker(id);
        }
      }
      this.points.clear();
      this.pointNames.clear();
      this.selectedId = null;
      this.idCounter = 0;
      log("PointMarkerTool reset — all points cleared");
    }
    // ── Map event handler ─────────────────────────────────────────────────────
    onMapClick(evt) {
      if (!this.ctx) return;
      const latlng = { lat: evt.latLng.lat, lng: evt.latLng.lng };
      const id = `pm-${++this.idCounter}`;
      const name = `点位 ${this.idCounter}`;
      this._addPoint(id, latlng, name);
      log("PointMarkerTool point added:", id, latlng);
    }
    // ── Public commands ───────────────────────────────────────────────────────
    deleteById(id) {
      if (!this.ctx || !this.points.has(id)) return;
      this.ctx.overlays.removePointMarker(id);
      this.points.delete(id);
      this.pointNames.delete(id);
      if (this.selectedId === id) this.selectedId = null;
      sendToPanel({ type: HookEvent.LAYER_DELETED, payload: { id } });
      log("PointMarkerTool point deleted:", id);
    }
    selectById(id, panToLocation = false) {
      var _a;
      if (this.selectedId === id) return;
      this.selectedId = id;
      (_a = this.ctx) == null ? void 0 : _a.overlays.setPointMarkerHighlight(id);
      if (panToLocation && this.ctx) {
        const latlng2 = this.points.get(id);
        if (latlng2) {
          const TMap = window.TMap;
          const pos = new TMap.LatLng(latlng2.lat, latlng2.lng);
          if (typeof this.ctx.map.panTo === "function") {
            this.ctx.map.panTo(pos);
          } else {
            this.ctx.map.setCenter(pos);
          }
        }
      }
      log("PointMarkerTool point selected:", id);
      const latlng = this.points.get(id);
      sendToPanel({ type: HookEvent.LAYER_SELECTED, payload: { id, data: latlng ? { kind: "point-marker", lat: latlng.lat, lng: latlng.lng } : void 0 } });
    }
    setVisible(id, visible) {
      var _a;
      (_a = this.ctx) == null ? void 0 : _a.overlays.setPointMarkerVisible(id, visible);
    }
    renameById(id, name) {
      var _a;
      if (!this.points.has(id)) return;
      this.pointNames.set(id, name);
      (_a = this.ctx) == null ? void 0 : _a.overlays.updatePointMarkerName(id, name);
      log("PointMarkerTool point renamed:", id, "->", name);
    }
    importFromInput(input) {
      if (!this.ctx) return;
      const coords = parsePointCoords(input);
      if (!coords || coords.length === 0) {
        log("PointMarkerTool importFromInput: failed to parse:", input);
        return;
      }
      for (const latlng of coords) {
        const id = `pm-${++this.idCounter}`;
        const name = `点位 ${this.idCounter}`;
        this._addPoint(id, latlng, name);
      }
      log("PointMarkerTool imported", coords.length, "points");
    }
    // ── Helpers ───────────────────────────────────────────────────────────────
    _addPoint(id, latlng, name) {
      if (!this.ctx) return;
      this.ctx.overlays.addPointMarker(id, latlng, name);
      this.points.set(id, latlng);
      this.pointNames.set(id, name);
      sendToPanel({ type: HookEvent.LAYER_DRAWN, payload: { id, kind: "point-marker", data: { kind: "point-marker", lat: latlng.lat, lng: latlng.lng } } });
    }
  }
  class ToolManager {
    constructor() {
      this.tools = /* @__PURE__ */ new Map();
      this.activeTool = null;
      this.map = null;
      this.TMap = null;
      this.overlays = null;
      this.heartbeatTimer = null;
      this.pendingSnapshot = null;
      this.mouseMoveTimer = null;
      this.mouseMoveHandler = null;
      this.register(new MultiPointTool());
      this.register(new CircleTool());
      this.register(new PolygonTool());
      this.register(new PointMarkerTool());
    }
    register(tool) {
      this.tools.set(tool.id, tool);
    }
    onMapReady(map, TMap) {
      var _a, _b, _c;
      if (this.map === map) return;
      log("ToolManager.onMapReady — new map instance captured", map);
      const isReconnect = this.map !== null;
      if (this.overlays) {
        const snap = this.overlays.snapshot();
        const circleTool = this.tools.get(TOOL_IDS.CIRCLE);
        const circleItems = (circleTool == null ? void 0 : circleTool.getAllCircles()) ?? [];
        snap.circles = circleItems.map((c) => {
          var _a2;
          return {
            ...c,
            visible: ((_a2 = snap.polygons.find((p) => p.id === c.id)) == null ? void 0 : _a2.visible) ?? true
          };
        });
        snap.polygons = snap.polygons.filter((p) => !p.id.startsWith("circle-"));
        this.pendingSnapshot = snap;
        this.overlays.detachFromMap();
        log("snapshot saved:", snap.polygons.length, "polygons,", snap.pointMarkers.length, "point markers,", snap.circles.length, "circles");
      }
      const prevToolId = ((_a = this.activeTool) == null ? void 0 : _a.id) ?? null;
      if (this.activeTool) {
        this.activeTool.deactivate();
        this.activeTool = null;
      }
      this.map = map;
      this.TMap = TMap;
      this.overlays = new OverlayManager(map, TMap);
      let restoredPoly = 0;
      let restoredPm = 0;
      if (this.pendingSnapshot) {
        const snap = this.pendingSnapshot;
        const polygonTool = this.tools.get(TOOL_IDS.POLYGON);
        const clickCb = (polygonTool == null ? void 0 : polygonTool.getClickHandler()) ?? (() => {
        });
        const mdCb = polygonTool == null ? void 0 : polygonTool.getMousedownHandler();
        restoredPoly = snap.polygons.length;
        restoredPm = snap.pointMarkers.length;
        let restoredMeasures = ((_b = snap.measures) == null ? void 0 : _b.length) ?? 0;
        const restoredCircles = ((_c = snap.circles) == null ? void 0 : _c.length) ?? 0;
        this.pendingSnapshot = null;
        setTimeout(() => {
          this.overlays.restore(snap, clickCb, mdCb, (id) => {
            sendToPanel({ type: HookEvent.LAYER_SELECTED, payload: { id } });
          });
          if (restoredPoly > 0) {
            polygonTool == null ? void 0 : polygonTool.registerFromRestore(snap.polygons);
          }
          if (restoredCircles > 0) {
            const ct = this.tools.get(TOOL_IDS.CIRCLE);
            if (ct && this.map && this.overlays) {
              const ctx = { map: this.map, overlays: this.overlays };
              ct.registerFromSnapshot(snap.circles, ctx);
            }
          }
          log("snapshot restored:", restoredPoly, "polygons,", restoredPm, "point markers,", restoredMeasures, "measures,", restoredCircles, "circles");
        }, 0);
      }
      if (prevToolId) {
        setTimeout(() => {
          this.setTool(prevToolId);
        }, 0);
      }
      this.startHeartbeat();
      this.startMouseTracking();
      if (isReconnect) {
        sendToPanel({ type: HookEvent.MAP_RESTORED, payload: { polygonCount: restoredPoly, pointMarkerCount: restoredPm } });
      }
      sendToPanel({ type: HookEvent.MAP_READY });
      log("MAP_READY sent to panel" + (isReconnect ? " (reconnect)" : ""));
    }
    /** 心跳检测到地图实例已销毁时调用。 */
    onMapLost() {
      log("ToolManager.onMapLost — map instance gone");
      this.stopHeartbeat();
      this.stopMouseTracking();
      if (this.overlays && !this.pendingSnapshot) {
        const snap = this.overlays.snapshot();
        const circleTool = this.tools.get(TOOL_IDS.CIRCLE);
        const circleItems = (circleTool == null ? void 0 : circleTool.getAllCircles()) ?? [];
        snap.circles = circleItems.map((c) => {
          var _a;
          return {
            ...c,
            visible: ((_a = snap.polygons.find((p) => p.id === c.id)) == null ? void 0 : _a.visible) ?? true
          };
        });
        snap.polygons = snap.polygons.filter((p) => !p.id.startsWith("circle-"));
        this.pendingSnapshot = snap;
        log("snapshot saved on map lost:", snap.polygons.length, "polygons,", snap.circles.length, "circles");
      }
      if (this.overlays) {
        this.overlays.detachFromMap();
      }
      if (this.activeTool) {
        this.activeTool.deactivate();
        this.activeTool = null;
      }
      sendToPanel({ type: HookEvent.MAP_LOST });
      log("MAP_LOST sent to panel");
    }
    startHeartbeat() {
      this.stopHeartbeat();
      this.heartbeatTimer = setInterval(() => {
        var _a;
        try {
          (_a = this.map) == null ? void 0 : _a.getCenter();
        } catch {
          log("heartbeat: map.getCenter() threw, assuming destroyed");
          this.onMapLost();
        }
      }, 3e3);
    }
    stopHeartbeat() {
      if (this.heartbeatTimer !== null) {
        clearInterval(this.heartbeatTimer);
        this.heartbeatTimer = null;
      }
    }
    /** 供 map-bridge 的 wrapper 判断实例是否已被捕获，避免重复触发。 */
    isMapCaptured(instance) {
      return this.map === instance && this.map !== null;
    }
    replayMapReady() {
      log("replayMapReady — map exists?", !!this.map);
      if (this.map) sendToPanel({ type: HookEvent.MAP_READY });
    }
    setTool(toolId) {
      if (!this.map || !this.overlays) return;
      if (this.activeTool && this.activeTool.id === toolId) return;
      if (this.activeTool) {
        this.activeTool.deactivate();
        const persistentTools = /* @__PURE__ */ new Set([TOOL_IDS.POLYGON, TOOL_IDS.POINT_MARKER, TOOL_IDS.CIRCLE]);
        if (!persistentTools.has(this.activeTool.id)) {
          this.overlays.clearMeasurement();
        }
      }
      if (toolId === "") {
        if (this.activeTool) {
          this.activeTool.deactivate();
          this.activeTool = null;
        }
        return;
      }
      const tool = this.tools.get(toolId);
      if (!tool) return;
      const ctx = {
        map: this.map,
        overlays: this.overlays
      };
      this.activeTool = tool;
      tool.activate(ctx);
      log("setTool:", toolId);
    }
    // ── Tool accessors ─────────────────────────────────────────────────────────
    _polygon() {
      return this.activeTool instanceof PolygonTool ? this.activeTool : null;
    }
    _pointMarker() {
      return this.activeTool instanceof PointMarkerTool ? this.activeTool : null;
    }
    _circle() {
      return this.activeTool instanceof CircleTool ? this.activeTool : null;
    }
    // ── Unified layer dispatch ─────────────────────────────────────────────────
    /**
     * 统一处理 Panel 发起的图层级操作（select / delete / toggle / rename / edit）。
     *
     * Panel 端已不再发送旧的类型专用命令（SELECT_POLYGON、DELETE_POINT_MARKER 等），
     * 全部改用 LAYER_SELECT / LAYER_DELETE / LAYER_TOGGLE / LAYER_RENAME / LAYER_EDIT，
     * 通过 kind 字段路由到正确的工具或 overlay 方法。
     */
    dispatchLayerCommand(cmd, payload) {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o;
      const { id, kind } = payload;
      switch (cmd) {
        case PanelCmd.LAYER_SELECT:
          switch (kind) {
            case "polygon":
              (_a = this._polygon()) == null ? void 0 : _a.selectById(id, true);
              break;
            case "circle":
              (_b = this.overlays) == null ? void 0 : _b.setPolygonHighlight(id);
              {
                const info = (_c = this._circle()) == null ? void 0 : _c.getCircleInfo(id);
                if (info) this._panTo(info.center.lat, info.center.lng);
              }
              break;
            case "point-marker":
              (_d = this._pointMarker()) == null ? void 0 : _d.selectById(id, true);
              break;
            case "measure":
              (_e = this.overlays) == null ? void 0 : _e.setMeasureHighlight(id);
              break;
          }
          break;
        case PanelCmd.LAYER_DELETE:
          switch (kind) {
            case "polygon":
              (_f = this._polygon()) == null ? void 0 : _f.deleteById(id);
              break;
            case "circle":
              (_g = this.overlays) == null ? void 0 : _g.removePolygon(id);
              sendToPanel({ type: HookEvent.LAYER_DELETED, payload: { id } });
              break;
            case "point-marker":
              (_h = this._pointMarker()) == null ? void 0 : _h.deleteById(id);
              break;
            case "measure":
              (_i = this.overlays) == null ? void 0 : _i.removeMeasure(id);
              sendToPanel({ type: HookEvent.LAYER_DELETED, payload: { id } });
              break;
          }
          break;
        case PanelCmd.LAYER_TOGGLE:
          switch (kind) {
            case "polygon":
              (_j = this._polygon()) == null ? void 0 : _j.setVisible(id, payload.visible);
              break;
            case "circle":
              (_k = this.overlays) == null ? void 0 : _k.setPolygonVisible(id, payload.visible);
              break;
            case "point-marker":
              (_l = this._pointMarker()) == null ? void 0 : _l.setVisible(id, payload.visible);
              break;
            case "measure":
              (_m = this.overlays) == null ? void 0 : _m.setMeasureVisible(id, payload.visible);
              break;
          }
          break;
        case PanelCmd.LAYER_RENAME:
          switch (kind) {
            case "polygon":
              break;
            case "circle":
              break;
            case "point-marker":
              (_n = this._pointMarker()) == null ? void 0 : _n.renameById(id, payload.name);
              break;
          }
          break;
        case PanelCmd.LAYER_EDIT:
          switch (kind) {
            case "polygon":
              (_o = this._polygon()) == null ? void 0 : _o.startEditById(id);
              break;
            case "circle":
              {
                const ct = this.tools.get(TOOL_IDS.CIRCLE);
                if (!ct || !this.map || !this.overlays) break;
                if (this.activeTool !== ct) {
                  if (this.activeTool) this.activeTool.deactivate();
                  const ctx = { map: this.map, overlays: this.overlays };
                  ct.activate(ctx);
                  this.activeTool = ct;
                }
                ct.startEditCircle(id);
                sendToPanel({ type: HookEvent.LAYER_EDIT_STARTED, payload: { id, kind: "circle" } });
              }
              break;
            case "point-marker":
              break;
            case "measure":
              this.startEditMeasure(
                id,
                payload.name ?? "",
                payload.points ?? [],
                payload.segmentDistances ?? []
              );
              break;
          }
          break;
      }
    }
    /** 将地图视野平移到指定经纬度。 */
    _panTo(lat, lng) {
      if (!this.map || !this.TMap) return;
      const center = new this.TMap.LatLng(lat, lng);
      if (typeof this.map.panTo === "function") {
        this.map.panTo(center);
      } else {
        this.map.setCenter(center);
      }
    }
    // ── Polygon drawing commands (tool-specific) ───────────────────────────────
    startDrawingPolygon() {
      var _a;
      (_a = this._polygon()) == null ? void 0 : _a.enterDrawingMode();
    }
    finishDrawingPolygon() {
      var _a;
      (_a = this._polygon()) == null ? void 0 : _a.finishDrawing();
    }
    cancelDrawingPolygon() {
      var _a;
      (_a = this._polygon()) == null ? void 0 : _a.cancelDrawing();
    }
    undoPolygonPoint() {
      var _a;
      (_a = this._polygon()) == null ? void 0 : _a.undoDrawingPoint();
    }
    drawPolygon(input) {
      var _a;
      (_a = this._polygon()) == null ? void 0 : _a.drawFromInput(input);
    }
    finishEditPolygon() {
      var _a;
      (_a = this._polygon()) == null ? void 0 : _a.finishEdit();
    }
    cancelEditPolygon() {
      var _a;
      (_a = this._polygon()) == null ? void 0 : _a.cancelEdit();
    }
    // ── Point marker commands (tool-specific) ──────────────────────────────────
    importPointMarkers(input) {
      var _a;
      (_a = this._pointMarker()) == null ? void 0 : _a.importFromInput(input);
    }
    // ── Circle tool commands (tool-specific) ──────────────────────────────────
    updateCircle(id, radius, nPoints) {
      var _a;
      (_a = this._circle()) == null ? void 0 : _a.updateCircle(id, radius, nPoints);
    }
    finishCircle() {
      var _a;
      (_a = this._circle()) == null ? void 0 : _a.finishCircle();
    }
    startDrawingCircle() {
      var _a;
      (_a = this._circle()) == null ? void 0 : _a.startDrawing();
    }
    cancelDrawingCircle() {
      var _a;
      (_a = this._circle()) == null ? void 0 : _a.cancelDrawing();
    }
    commitEditCircle() {
      var _a;
      (_a = this._circle()) == null ? void 0 : _a.commitEditCircle();
    }
    cancelEditCircle() {
      var _a;
      (_a = this._circle()) == null ? void 0 : _a.cancelEditCircle();
    }
    updateEditCircle(id, radius, nPoints) {
      var _a;
      (_a = this._circle()) == null ? void 0 : _a.updateEditCircle(void 0, radius, nPoints);
    }
    // ── Measure layer commands (persistent, work without active tool) ──────────
    /** 开始编辑测距：切换到多点工具并加载已有数据。 */
    startEditMeasure(id, name, points, segDists) {
      const tool = this.tools.get(TOOL_IDS.MULTI_POINT);
      if (!tool || !this.map || !this.overlays) return;
      if (this.activeTool && this.activeTool !== tool) {
        this.activeTool.deactivate();
      }
      const ctx = { map: this.map, overlays: this.overlays };
      tool.loadForEdit(ctx, id, name, points, segDists);
      this.activeTool = tool;
    }
    /** 提交测距编辑：触发 finish 重建持久图层。 */
    commitEditMeasure() {
      var _a, _b;
      (_b = (_a = this.activeTool) == null ? void 0 : _a.finish) == null ? void 0 : _b.call(_a);
    }
    /** 取消测距编辑：MultiPointTool 内部 onKeydown(Escape) 自行恢复。 */
    cancelEditMeasure() {
    }
    // ── General tool commands ─────────────────────────────────────────────────
    finish() {
      var _a, _b;
      (_b = (_a = this.activeTool) == null ? void 0 : _a.finish) == null ? void 0 : _b.call(_a);
    }
    undo() {
      var _a, _b;
      (_b = (_a = this.activeTool) == null ? void 0 : _a.undo) == null ? void 0 : _b.call(_a);
    }
    clear() {
      var _a;
      if (this.activeTool) {
        this.activeTool.reset();
      } else {
        (_a = this.overlays) == null ? void 0 : _a.clearAll();
      }
    }
    // ── Mouse coordinate tracking ─────────────────────────────────────────────
    startMouseTracking() {
      this.stopMouseTracking();
      this.mouseMoveHandler = (evt) => {
        if (this.mouseMoveTimer) return;
        this.mouseMoveTimer = setTimeout(() => {
          this.mouseMoveTimer = null;
          try {
            sendToPanel({
              type: HookEvent.MOUSE_MOVE,
              payload: { lat: evt.latLng.lat, lng: evt.latLng.lng }
            });
          } catch {
          }
        }, 50);
      };
      this.map.on("mousemove", this.mouseMoveHandler);
      log("mouse tracking started");
    }
    stopMouseTracking() {
      if (this.mouseMoveHandler && this.map) {
        this.map.off("mousemove", this.mouseMoveHandler);
      }
      this.mouseMoveHandler = null;
      if (this.mouseMoveTimer) {
        clearTimeout(this.mouseMoveTimer);
        this.mouseMoveTimer = null;
      }
    }
  }
  const CAPTURE_METHODS = ["getCenter", "setCenter", "on", "off", "setZoom", "getZoom", "fitBounds"];
  const ALREADY_PATCHED = "__tmapHookerPatched";
  function installMapBridge(toolManager2) {
    log("installMapBridge called, document.readyState =", document.readyState);
    log("window.TMap at install time =", window.TMap);
    trySetterTrap(toolManager2);
    setInterval(() => {
      const TMap = window.TMap;
      if (TMap) {
        tryPrototypePatch(TMap, toolManager2);
      }
    }, 200);
  }
  function trySetterTrap(toolManager2) {
    if (window.TMap) {
      log("TMap already exists, patching directly");
      tryPrototypePatch(window.TMap, toolManager2);
      return;
    }
    try {
      Object.defineProperty(window, "TMap", {
        configurable: true,
        enumerable: true,
        set(value) {
          log("window.TMap setter triggered, value =", value);
          Object.defineProperty(window, "TMap", {
            value,
            writable: true,
            configurable: true,
            enumerable: true
          });
          tryPrototypePatch(value, toolManager2);
        }
      });
      log("window.TMap setter trap installed");
    } catch (e) {
      log("failed to install setter trap:", e);
    }
  }
  function tryPrototypePatch(TMap, toolManager2) {
    var _a;
    if (!TMap) return false;
    if (!((_a = TMap == null ? void 0 : TMap.Map) == null ? void 0 : _a.prototype)) {
      log("TMap.Map.prototype not found, keys on TMap:", Object.keys(TMap));
      return false;
    }
    const proto = TMap.Map.prototype;
    if (proto[ALREADY_PATCHED]) return true;
    log("patching TMap.Map.prototype, methods to hook:", CAPTURE_METHODS);
    let hookedCount = 0;
    for (const method of CAPTURE_METHODS) {
      if (typeof proto[method] !== "function") {
        log(`skip ${method} (not a function)`);
        continue;
      }
      const orig = proto[method];
      proto[method] = function(...args) {
        if (!toolManager2.isMapCaptured(this)) {
          log(`map.${method}() — new instance detected, capturing`);
          toolManager2.onMapReady(this, TMap);
        }
        return orig.apply(this, args);
      };
      hookedCount++;
      log(`hooked ${method}`);
    }
    proto[ALREADY_PATCHED] = true;
    log(`prototype patch complete, hooked ${hookedCount} methods`);
    return true;
  }
  initLogger();
  log("hook.iife.js loaded, document.readyState =", document.readyState);
  document.addEventListener("DOMContentLoaded", () => {
    const crosshairStyle = document.createElement("style");
    crosshairStyle.textContent = ".__tmh-crosshair { cursor: crosshair !important; }";
    document.head.appendChild(crosshairStyle);
  });
  const toolManager = new ToolManager();
  installMapBridge(toolManager);
  window.addEventListener("message", (event) => {
    const msg = event.data;
    if (!msg || msg.source !== PANEL_SOURCE) return;
    log("received panel message:", msg.type);
    switch (msg.type) {
      case PanelCmd.PANEL_READY:
        toolManager.replayMapReady();
        break;
      case PanelCmd.SET_TOOL:
        toolManager.setTool(msg.payload.toolId);
        break;
      case PanelCmd.FINISH:
        toolManager.finish();
        break;
      case PanelCmd.UNDO:
        toolManager.undo();
        break;
      case PanelCmd.CLEAR:
        toolManager.clear();
        break;
      case PanelCmd.SET_DEBUG:
        setDebug(msg.payload.enabled);
        log("debug mode set to:", msg.payload.enabled);
        break;
      case PanelCmd.LAYER_SELECT:
        toolManager.dispatchLayerCommand(PanelCmd.LAYER_SELECT, msg.payload);
        break;
      case PanelCmd.LAYER_DELETE:
        toolManager.dispatchLayerCommand(PanelCmd.LAYER_DELETE, msg.payload);
        break;
      case PanelCmd.LAYER_TOGGLE:
        toolManager.dispatchLayerCommand(PanelCmd.LAYER_TOGGLE, msg.payload);
        break;
      case PanelCmd.LAYER_RENAME:
        toolManager.dispatchLayerCommand(PanelCmd.LAYER_RENAME, msg.payload);
        break;
      case PanelCmd.LAYER_EDIT:
        toolManager.dispatchLayerCommand(PanelCmd.LAYER_EDIT, msg.payload);
        break;
      case PanelCmd.DRAW_POLYGON:
        toolManager.drawPolygon(msg.payload.input);
        break;
      case PanelCmd.START_DRAWING_POLYGON:
        toolManager.startDrawingPolygon();
        break;
      case PanelCmd.FINISH_DRAWING_POLYGON:
        toolManager.finishDrawingPolygon();
        break;
      case PanelCmd.CANCEL_DRAWING_POLYGON:
        toolManager.cancelDrawingPolygon();
        break;
      case PanelCmd.UNDO_POLYGON_POINT:
        toolManager.undoPolygonPoint();
        break;
      case PanelCmd.FINISH_EDIT_POLYGON:
        toolManager.finishEditPolygon();
        break;
      case PanelCmd.CANCEL_EDIT_POLYGON:
        toolManager.cancelEditPolygon();
        break;
      case PanelCmd.UPDATE_CIRCLE:
        toolManager.updateCircle(msg.payload.id, msg.payload.radius, msg.payload.nPoints);
        break;
      case PanelCmd.FINISH_CIRCLE:
        toolManager.finishCircle();
        break;
      case PanelCmd.START_DRAWING_CIRCLE:
        toolManager.startDrawingCircle();
        break;
      case PanelCmd.CANCEL_DRAWING_CIRCLE:
        toolManager.cancelDrawingCircle();
        break;
      case PanelCmd.COMMIT_EDIT_CIRCLE:
        toolManager.commitEditCircle();
        break;
      case PanelCmd.CANCEL_EDIT_CIRCLE:
        toolManager.cancelEditCircle();
        break;
      case PanelCmd.COMMIT_EDIT_MEASURE:
        toolManager.commitEditMeasure();
        break;
      case PanelCmd.CANCEL_EDIT_MEASURE:
      case PanelCmd.UPDATE_MEASURE_VERTEX:
        break;
      case PanelCmd.IMPORT_POINT_MARKERS:
        toolManager.importPointMarkers(msg.payload.input);
        break;
    }
  });
})();
